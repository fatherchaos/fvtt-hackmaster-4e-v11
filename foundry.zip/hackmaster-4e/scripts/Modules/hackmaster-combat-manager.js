import { HackmasterActor } from '../Modules/hackmaster-actor.js';
import { HackmasterCrits } from '../Modules/hackmaster-crits.js';
import { HackmasterFumbles } from '../Modules/hackmaster-fumbles.js';
import { HackmasterItem } from '../Modules/hackmaster-item.js';
import { Utilities } from '../utilities.js'

export class HackmasterCombatManager{

    static getAdditionalInitiativeModifiers(combatant){
        let hmActor = new HackmasterActor(combatant.actor);

        let modifiers = [];
        if (hmActor.isInDishonor()){
            modifiers.push({desc: 'dishonor', value: 1});
        }
        else if (hmActor.isInGreatHonor()){
            modifiers.push({desc: 'honor', value: -1});
        }
        return modifiers;
    }

	/* Soak armor damage */
    static async applyArmorSoak(result){
        if (!result.isDamage){
            return result;
        }

        let hasUnsoakableDamageTypes = Utilities.intersection(["pyschic", "poison"], result.damagetype).length > 0;

		if (!hasUnsoakableDamageTypes && result.target?.actor){
            let target = new HackmasterActor(result.target.actor);
            let armors = target.getEquippedArmors();

            if (armors.length > 0){

                let armor = armors[0]; // TODO: What to do if there's more than one? Right now we're just grabbing the first.                
				let soakPerDie = armor.soakPerDie;

				let sumOfDice = 0;
				let sumOfDicePenetration = 0;
				
				for (const die of result.roll.dice)
				{
					sumOfDice += die.number;
					sumOfDicePenetration += die.results.length - die.number;
				}
				sumOfDice += sumOfDicePenetration;
				
				let amountToSoak = Math.min(result.totalDamage, armor.hpRemaining, sumOfDice * soakPerDie);
				
				let hasOnlyStandardDamageTypes = ["bludgeoning", "slashing", "piercing"].includes(result.damagetype);
				if (amountToSoak > 0){
                    result.totalAbsorbed += amountToSoak;
                    result.totalDamage -= amountToSoak;
                    let armorDamageAmount = amountToSoak;

					
					// If it's bludgeoning, piercing, or slashing damage and the armor is magic, it should only be hurt by penetrations.
					if (armor.isMagic && hasOnlyStandardDamageTypes){                        
                        armorDamageAmount = Math.min(sumOfDicePenetration, armor.hpRemaining);
                    }

					await armor.damageArmor(armorDamageAmount);
					let armorDamageCard = await HackmasterCombatManager.createArmorDamageCard(armor, amountToSoak, armorDamageAmount); 
                    Utilities.displayChatMessage(armorDamageCard);

                } 
            }
            
        }
        return result; 
    }

    static async createArmorDamageCard(armor, amountSoaked, amountDamaged){

        let card = Utilities.loadCachedTemplate("modules/hackmaster-4e/templates/armor-damage-card.hbs", {
            armorName: armor.aliasedName,
            hpRemaining: armor.hpRemaining - amountSoaked, // armor.hpamount is not updated until after chatcard is rendered. Fix to display correct remaining armor hp.
            amountSoaked: amountSoaked,
            amountDamaged: amountDamaged
        });
        return card;
    }

    static async reRollInitiative(combatTracker) {
        let slowCombatants = [];
        combatTracker.combatants.forEach(combatant =>{
            if (combatant.initiative > 10){
                slowCombatants.push({combatant: combatant, oldInitiative: combatant.initiative})
            }          
        });
        await combatTracker.resetAll();
        await combatTracker.update({ turn: null });

        await Promise.all(
            slowCombatants.map(s => s.combatant.update({initiative: s.oldInitiative - 10}))
        );
    }

    static handleCritCheck(roll, dd, targetToken){
        if (!roll)
		{
            return;
		}
            
		let source = new HackmasterActor(dd.source);
		let target = new HackmasterActor(targetToken?.actor);
        let nTargetAc = target.getArmorClass(dd.ac);
        let nAttackBonus = roll.total - roll.dice[0].results[0].result;
        let damageSource = dd.item ? dd.item : dd.action;
        let aDamageTypes = [];
        let sCalledShotLocation = undefined; // TODO
        let damageType = damageSource?.system?.damage?.type;
        if (damageType){
            aDamageTypes.push(damageType);
        }     

		
		if (roll.criticaled){
			let crit = HackmasterCrits.generateRandomCrit(source, target, nTargetAc, nAttackBonus, aDamageTypes, sCalledShotLocation);
			let card = HackmasterCrits.createCritCard(crit);
			Utilities.displayChatMessage(card, source);
		}
        else if (roll.fumbled){
            let fumble = HackmasterFumbles.handleFumble();
            let card = HackmasterFumbles.createFumbleCard(fumble);
            Utilities.displayChatMessage(card);
        }
	}

    static applyHonorToAttackRoll(dd, bonusFormula, additionalRollData){
		let hmActor = new HackmasterActor(dd.source);
		let isGreatHonor = hmActor.isInGreatHonor();
		let isDishonor = hmActor.isInDishonor();

		if (isGreatHonor || isDishonor){
			bonusFormula.push('@hon');
			additionalRollData.hon = isGreatHonor ? 1 : -1;
		}
	}

	/* Adds honor die to damage rolls */
	static applyHonorToDamageRoll(dd){
		let hmActor = new HackmasterActor(dd.actor);
		let isGreatHonor = hmActor.isInGreatHonor();
		let isDishonor = hmActor.isInDishonor();
		let honoradj = 0;
		let operatorSign = '';
		if (isGreatHonor || isDishonor){
			for(let i = 0; i < dd.dice.length; i++){
				//for(let t = 0; t < dd.dice[i].results.length; t++){
					honoradj += dd.dice[i].results.length ?? 0;
					//let numDiceRolled = dd.dice[i].results.length ?? 0;
					
				//}
			}
			operatorSign = isGreatHonor ? '+' : '-';

			dd._formula += ` ${operatorSign} ${honoradj}`;
			dd.rawformula += ` ${operatorSign} @hon`;
			dd.terms.push(new OperatorTerm({operator:operatorSign}));
			dd.terms.push(new NumericTerm({number:honoradj}));
			//dd.result += ` ${operatorSign} ${honoradj}`;
			//dd.total += honoradj;

			if (isGreatHonor) {
				dd._total += honoradj;
				/* dd.data.dmgDone[i].dmg += numDiceRolled;
				dd.data.rolled.totalValues += numDiceRolled; */
			}
			else if (isDishonor) {
				dd._total -= honoradj;
				/* dd.data.dmgDone[i].dmg -= numDiceRolled;
				dd.data.rolled.totalValues -= numDiceRolled */
			}
		}
		return dd;
	}

    static async recordDamageForThresholdOfPain(targetToken, damageDone){
        if (targetToken && targetToken.actor && damageDone > 0){
            let actor = new HackmasterActor(targetToken.actor);
            await actor.recordDamageTaken(damageDone);
            if (actor.needsThresholdOfPainCheck){
                let card = await HackmasterCombatManager.createTopCheckCard(actor);
                Utilities.displayChatMessage(card, actor);
            }
        }
    }

    static async createTopCheckCard(actor){
        let card = Utilities.loadCachedTemplate("modules/hackmaster-4e/templates/top-check-card.hbs", {
            actorName: actor.name,
            thresholdOfPain: actor.thresholdOfPain,
            recentDamageTaken: actor.recentDamageTaken,
            actorId: actor.actorId,
            tokenId: actor.tokenId
        });
        return card;
    }

    static replaceDamageForCorrectSize(dd, targetToken){
        if (!targetToken?.actor){
            return;
        }

          if (dd.isWeapon && dd.weapon && dd?.weapon?.system?.damage){
			if( dd.weapon?.system?.attack?.type !== 'ranged'){
				let weapon = new HackmasterItem(dd.weapon);
                let target = new HackmasterActor(targetToken.actor);
                let correctDamage = weapon.getDamageForSizeCategory(target.sizeCategory);
				return correctDamage;
			}
		 }
		 return;

    }
}
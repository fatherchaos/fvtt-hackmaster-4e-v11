export class HackmasterItemSheet{
    static addArmorDamageFields(){
        let armorDamage = {
           progression: "",
           damageTaken: 0,
           soak: 1
        };
		
		const fieldsx = foundry.data.fields;
		Object.assign(CONFIG.Item.dataModels.armor._schema.fields.protection.fields, {
    // The keys are the types defined in our template.json
				armorDamage: new fieldsx.SchemaField({
					   progression: new fieldsx.StringField({ default: '' }),
					   damageTaken: new fieldsx.NumberField({ default: 0 }),
					   soak: new fieldsx.NumberField({ default: 1 }),
				}),
  });
  
		Object.assign(CONFIG.Item.dataModels.weapon._schema.fields.damage.fields, {
    // The keys are the types defined in our template.json
						tiny: new fieldsx.StringField({ default: '' }),
						small: new fieldsx.StringField({ default: '' }),
					   huge: new fieldsx.StringField({ default: '' }),
					   gargantuan: new fieldsx.StringField({ default: '' }),
				});
  
        //game.system.model.Item.armor.protection.armorDamage = armorDamage;
		//CONFIG.Item.dataModels.armor._schema.fields.protection.fields.armorDamage = armorDamage;
    }
    
	
	
  
    static initialize(){
        this.addArmorDamageFields();

        Hooks.on('renderARSItemSheet', async (sheet) => {
            let hmSheet = new HackmasterItemSheet(sheet);
            if (hmSheet.itemType == 'weapon'){
                await hmSheet.insertWeaponDamageSizes();
                hmSheet.restoreScrollPosition();
            }
		});

        Hooks.on('renderItemSheet', async (sheet) => {
			await this.insertArmorDamageFields(sheet);
		});
    }

    constructor(sheet) {
		this._sheet = sheet;
	}

    getRawDamageData(){
        return this._sheet?.item?.system?.damage ?? {};
    }

    get itemType(){
        return this._sheet?.item?.type ?? '';
    }

    findElement(selector){
		return this._sheet._element.find(selector);
	}

    async insertWeaponDamageSizes(){
        let normalDamageInput = this.findElement("input[name='system.damage.normal']");
        if (normalDamageInput){
            let normalDamageDiv = normalDamageInput.closest('div');
            let section = await this.buildWeaponDamageSection();
            $(section).insertAfter(normalDamageDiv);
        }
    }

    async buildWeaponDamageSection(){
        let data = this.getRawDamageData();
		return await renderTemplate("modules/hackmaster-4e/templates/weapon-damage-section.hbs", data);
	}

    restoreScrollPosition(){
		if (this._sheet.itemSheetScrollY){
			$('.item .window-content').scrollTop(this._sheet.itemSheetScrollY);
		}
	}

	saveScrollPosition(){
		this._sheet.itemSheetScrollY = $('.item .window-content').scrollTop();
	}

    static async buildArmorDamageFields(armorDamageInfo){
        return await renderTemplate('modules/hackmaster-4e/templates/item-armor-damage-fields.hbs', armorDamageInfo);
    }

    static async insertArmorDamageFields(sheet) {
        let itemType = sheet.object.type;
        if (itemType === "armor"){
            let armorsList = sheet._element.find(".armors-list");
            if (armorsList){
                let armorDamageInfo = sheet.object.system.protection.armorDamage;
                let fieldHtml = await this.buildArmorDamageFields(armorDamageInfo);
                $(fieldHtml).insertAfter(armorsList);
            }
        }
	}
}
import { HackmasterActor } from '../Modules/hackmaster-actor.js';
import { HackmasterCrits } from '../Modules/hackmaster-crits.js';
import { HackmasterFumbles } from '../Modules/hackmaster-fumbles.js';
import { HackmasterItem } from '../Modules/hackmaster-item.js';
import { HackmasterCombatManager } from '../Modules/hackmaster-combat-manager.js';
import { libWrapper } from '../shim.js';
//import * from '../dice/dice.js'

export class ARSCombatOverrides {
    static initialize(){
        ARSCombatOverrides.overrideDamageRoll();
		ARSCombatOverrides.overrideAttackRoll();
		ARSCombatOverrides.updateHonorDiceAdjustment();
		ARSCombatOverrides.overrideApplyDamageAdjustments();
		ARSCombatOverrides.overrideSendHealthAdjustChatCard();
		ARSCombatOverrides.overrideGetDamageFormulas();
		ARSCombatOverrides.addHonorToSaveRoll();
	}
	
	/* Gets correct weapon damage size formula */
	static overrideGetDamageFormulas(){
		libWrapper.register(CONFIG.Hackmaster.MODULE_ID, 'game.ars.ARSRollDamage.prototype._getWeaponDamageFormula', function(wrapped, ...args) {
			let formula = wrapped(...args);	 
			let targetToken = this.target;
			let dd = this;
			let newformula = HackmasterCombatManager.replaceDamageForCorrectSize(dd, targetToken);
			if (newformula){
				formula[0].formula = newformula;
				return formula;
			}
			else{ return formula;}

		}, 'WRAPPER');
	}

	static overrideSendHealthAdjustChatCard(){
		libWrapper.register(CONFIG.Hackmaster.MODULE_ID, 'game.ars.ARSDamage.prototype.sendDamageChatCard', async function(wrapped, ...args) {
			await wrapped(...args);

			let targetToken = args[1];
			let bDamage = args[2];
			let totalDamageDone = args[4];
			if (bDamage){
				await HackmasterCombatManager.recordDamageForThresholdOfPain(targetToken, totalDamageDone);
			}

		}, 'WRAPPER');
	}
	
	/* Updates die adj value whenever the Honor.value is updated. Does not refresh for temp adjustment */
	static updateHonorDiceAdjustment(){
		
		Hooks.on("updateActor", (...args) => {
			if('honor' in args[1].system)
			{
				
				if(args[1].system.honor.value)
				{
					let hmActor = new HackmasterActor(args[0]);
					let MIN = -1;
					let MAX = 1;
					let dieadj = 0;
					let VALUE = hmActor.getHonorState();
					 if (VALUE > 1 )
					{
						dieadj = 0;
						}
					else {
						dieadj = VALUE;
						} 
					args[0].update({"system.honor.dieadj": dieadj});
				}
		}
		});
	
	}
	
	/* Adds honor to saving throw */
	static addHonorToSaveRoll(){
		
		/* if (bonusFormula.length) return { formula: bonusFormula, rollData };
        else return undefined; */
		
		libWrapper.register(CONFIG.Hackmaster.MODULE_ID, 'game.ars.ARSRollSave.prototype._getSaveEffectFormula', function(wrapped, ...args) {

			let formula = wrapped(...args);
			let hmActor = null;
			let savebonus = null;
			if(this.targetActor){ // handle NPC target case
				hmActor = new HackmasterActor(this.targetActor);
			}
			else{ // handle use case from PC
				hmActor = new HackmasterActor(this.actor);
				}
			
			if(this.actor)
			{
				
				if(hmActor.isNpc)
				{
					savebonus = '@honorState';
				}
				else
				{
					savebonus = '@honor.dieadj';
				}
			}

			if (formula == undefined){
				let bonusFormula = [],
					rollData;
				bonusFormula.push(savebonus);
				const bonusSaveEffectFormulas = [];
				const formulaName = 'Honor';
				const formulaValue = savebonus;
				bonusSaveEffectFormulas[formulaName] = formulaValue;
				rollData = {
					...bonusSaveEffectFormulas,
				};
				return { formula: bonusFormula, rollData };
			}
			else{
				const bonusSaveEffectFormulas = [];
				const formulaName = 'Honor';
				const formulaValue = savebonus;
				bonusSaveEffectFormulas[formulaName] = formulaValue;
				formula.formula.push(savebonus);
				formula.rollData = { ...formula.rollData,bonusSaveEffectFormulas};
				return formula;
			}			
		}, 'WRAPPER');
	}
	
	/* Adds honor to attack roll as needed */
	static overrideAttackRoll(){
		 Hooks.on("getAttackMods", (dd, targetToken, bonusFormula, additionalRollData) =>{
			HackmasterCombatManager.applyHonorToAttackRoll(dd, bonusFormula, additionalRollData);
		}); 

		// _getAttackModsFormula
		libWrapper.register(CONFIG.Hackmaster.MODULE_ID, 'game.ars.ARSRollAttack.prototype._getAttackModsFormula', function(wrapped, ...args) {

			// _getAttackModsFormula
			let attackbonus = wrapped(...args);
			let hmActor = null;
			if(attackbonus == undefined){ attackbonus = [];}
			if(this.actor)
			{
				hmActor = new HackmasterActor(this.actor);
				if(hmActor.isNpc)
				{
					attackbonus.push('@honorState');
				}
				else
				{
					attackbonus.push('@honor.dieadj');
				}
			}	
			return attackbonus;
		}, 'WRAPPER');
	}

	/* Adds great honor/dishonor adjustment to each die rolled for damage */
    static overrideDamageRoll(){
		libWrapper.register(CONFIG.Hackmaster.MODULE_ID, 'game.ars.ARSRollDamage.prototype.rollDamage', async function(wrapped, ...args) {
			let dd = await wrapped(...args);
			let ddr = await HackmasterCombatManager.applyHonorToDamageRoll(dd);
			return ddr;
		}, 'WRAPPER');
	}

	static overrideApplyDamageAdjustments(){
		libWrapper.register(CONFIG.Hackmaster.MODULE_ID, 'game.ars.ARSDamage.prototype.applyDamageAdjustments', async function(wrapped, ...args) {
			let result = await wrapped(...args);
			return await HackmasterCombatManager.applyArmorSoak(result);	
			//return result;
			
		}, 'WRAPPER');
	}
}
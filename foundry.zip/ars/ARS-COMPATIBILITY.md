Notice of Compatibility: Advanced Roleplay System

The Advanced Roleplay System (hereinafter "ARS") is a virtual tabletop ruleset designed and developed for compatibility with Advanced Dungeons & Dragons First Edition (hereinafter "AD&D 1E") © and Advanced Dungeons & Dragons Second Edition (hereinafter "AD&D 2E") ©, both intellectual properties owned by Wizards of the Coast LLC (hereinafter "WotC").

Advanced Dungeons & Dragons © and any related trademarks, copyrights, or other intellectual property rights are the exclusive property of WotC. The ARS and its creators do not claim any ownership or interest in the aforementioned trademarks or copyrights and expressly acknowledge the rights of WotC in these properties.

This Notice of Compatibility is provided to inform users that the ARS is designed to be used in conjunction with AD&D 1E and AD&D 2E and to clarify that the ARS does not infringe upon the intellectual property rights of WotC. The ARS and its creators are not affiliated with, endorsed by, or sponsored by WotC, and any references to AD&D 1E, AD&D 2E, or other WotC properties are for the purpose of compatibility and fair use only.

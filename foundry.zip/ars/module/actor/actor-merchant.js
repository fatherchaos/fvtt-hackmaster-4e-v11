export class ARSActorMerchant extends ARSActor {
    // // give pcs limited view if the npc is lootable
    // get permission() {
    //     // console.log("actor.js permission", super.permission, Math.max(super.permission, 1), this.isLootable)
    //     if (game.user.isGM) {
    //         return super.permission;
    //     }
    //     return Math.max(super.permission, CONST.DOCUMENT_OWNERSHIP_LEVELS.LIMITED);
    // }

    // testUserPermission(user, permission, options) {
    //     if (game.user.isGM) {
    //         return super.testUserPermission(user, permission, options);
    //     }
    //     if ([CONST.DOCUMENT_OWNERSHIP_LEVELS.LIMITED, 'LIMITED'].includes(permission) && !options) {
    //         return this.permission >= CONST.DOCUMENT_OWNERSHIP_LEVELS.LIMITED;
    //     }
    //     return super.testUserPermission(user, permission, options);
    // }
}

import * as utilitiesManager from './utilities.js';

export const ARS = {};

ARS.settings = {};

// ARS.icons.general = {
//     combat = {
//         "cast": "systems/ars/icons/general/RangedColor.png",
//         "damage": "systems/ars/icons/general/DamageColor.png",
//         "heal": "systems/ars/icons/general/HealColor.png",
//         "effect": "systems/ars/icons/general/EffectColor.png",
//         "item-activate": "systems/ars/icons/general/EffectColor.png",
//         "castmelee": "systems/ars/icons/general/MeleeColor.png",
//         "castrange": "systems/ars/icons/general/RangedColor.png",
//         "range": "systems/ars/icons/general/RangedColor.png",
//         "melee": "systems/ars/icons/general/MeleeColor.png",
//         "thrown": "systems/ars/icons/general/RangedColor.png",
//     },
// }

ARS.icons = {
    general: {
        actors: {
            lootable: 'icons/containers/chest/chest-reinforced-steel-brown.webp',
            merchant: 'systems/ars/assets/tokens/merchant_token_default.webp',
            default: 'icons/svg/d20-highlight.svg',
        },
        actions: {
            default: 'icons/vtt-512.png',
        },
        combat: {
            cast: 'icons/weapons/staves/staff-ornate-red.webp',
            castmelee: 'icons/weapons/swords/sword-winged-pink.webp',
            castranged: 'icons/weapons/wands/wand-gem-purple.webp',
            damage: 'icons/skills/wounds/blood-drip-droplet-red.webp',
            effect: 'icons/magic/time/hourglass-yellow-green.webp',
            effects: {
                defeated: 'systems/ars/icons/general/rip.png',
            },
            heal: 'icons/magic/holy/prayer-hands-glowing-yellow-white.webp',
            melee: 'icons/weapons/swords/sword-guard-steel-green.webp',
            ranged: 'icons/skills/ranged/target-bullseye-arrow-glowing.webp',
            save: 'icons/magic/defensive/illusion-evasion-echo-purple.webp',
            thrown: 'icons/weapons/thrown/bomb-fuse-red-black.webp',
        },
        currency: {
            cp: 'icons/commodities/currency/coin-engraved-waves-copper.webp',
            ep: 'icons/commodities/currency/coin-engraved-oval-steel.webp',
            gp: 'icons/commodities/currency/coin-plain-portal-gold.webp',
            pp: 'icons/commodities/currency/coin-inset-lightning-silver.webp',
            sp: 'icons/commodities/currency/coin-embossed-unicorn-silver.webp',
        },
        items: {
            ability: 'icons/skills/social/wave-halt-stop.webp',
            armor: 'icons/equipment/chest/breastplate-banded-steel.webp',
            background: 'icons/environment/settlement/house-farmland-small.webp',
            bundle: 'icons/containers/chest/chest-worn-oak-tan.webp',
            class: 'icons/skills/trades/academics-merchant-scribe.webp',
            container: 'icons/containers/bags/case-simple-brown.webp',
            currency: 'icons/commodities/currency/coins-assorted-mix-copper-silver-gold.webp',
            encounter: 'icons/creatures/eyes/lizard-single-slit-green.webp',
            item: 'icons/commodities/leather/leather-bolt-brown.webp',
            potion: 'icons/consumables/potions/bottle-round-corked-pink.webp',
            proficiency: 'icons/weapons/swords/sword-guard-bronze.webp',
            race: 'icons/environment/people/group.webp',
            skill: 'icons/tools/hand/hammer-and-nail.webp',
            spell: 'icons/sundries/scrolls/scroll-bound-sealed-red.webp',
            power: 'icons/magic/perception/third-eye-blue-red.webp',
            weapon: 'icons/weapons/hammers/hammer-war-rounding.webp',
        },
        move: 'systems/ars/icons/general/leather-boot.webp',
    },
};

/**
 * When we insert help links in a html doc we can reference this so that it's in a central locale to change
 */
ARS.HELP = {
    ruleset: {
        general: {
            pack: 'ars.ruleset-documentation',
            hash: '',
            uuid: 'Compendium.ars.ruleset-documentation.JournalEntry.kzvNpONYJCTf5kXR',
            id: 'kzvNpONYJCTf5kX',
            type: 'JournalEntryPage',
            icon: 'fa fa-question-circle',
        },
    },
    actor: {
        importtools: {
            pack: 'ars.ruleset-documentation',
            hash: 'import-actor-tools',
            uuid: 'Compendium.ars.ruleset-documentation.JournalEntry.kzvNpONYJCTf5kXR.JournalEntryPage.uBCmQMYzQrS7W86L',
            id: 'uBCmQMYzQrS7W86L',
            type: 'JournalEntryPage',
            icon: 'fa fa-question-circle',
        },
        character: {
            pack: 'ars.ruleset-documentation',
            hash: '',
            uuid: 'Compendium.ars.ruleset-documentation.JournalEntry.kzvNpONYJCTf5kXR.JournalEntryPage.EUVFTxQ30N0yfGrW',
            id: 'EUVFTxQ30N0yfGrW',
            type: 'JournalEntryPage',
            icon: 'fa fa-question-circle',
        },
        npc: {
            pack: 'ars.ruleset-documentation',
            hash: '',
            uuid: 'Compendium.ars.ruleset-documentation.JournalEntry.kzvNpONYJCTf5kXR.JournalEntryPage.LqDmdyNqIbpO5v8T',
            id: 'LqDmdyNqIbpO5v8T',
            type: 'JournalEntryPage',
            icon: 'fa fa-question-circle',
        },
    },
    action: {
        general: {
            pack: 'ars.ruleset-documentation',
            hash: '',
            uuid: 'Compendium.ars.ruleset-documentation.JournalEntry.kzvNpONYJCTf5kXR.JournalEntryPage.fLx3E4PhLICALwCG',
            id: 'fLx3E4PhLICALwCG',
            type: 'JournalEntryPage',
            icon: 'fa fa-question-circle',
        },
        resources: {
            pack: 'ars.ruleset-documentation',
            hash: 'resources',
            uuid: 'Compendium.ars.ruleset-documentation.JournalEntry.kzvNpONYJCTf5kXR.JournalEntryPage.fLx3E4PhLICALwCG',
            id: 'fLx3E4PhLICALwCG',
            type: 'JournalEntryPage',
            icon: 'fa fa-question-circle',
        },
    },
};

/**
 * during import we'll look for these words and highlight them in descriptions
 */
ARS.markupPhrases = [
    // "acid",
    'at will',
    'at-will',
    'damage dice',
    'drain energy',
    'drains energy',
    'can employ',
    // "fire",
    'half damage',
    'harmed by magical',
    'immune',
    'immunity',
    'innate',
    'not affect',
    'not effect',
    'only be hit by',
    'only hit by',
    'of damage',
    'paralyze',
    'per day',
    'perform the following',
    'poison',
    'points of',
    'regenerate',
    'resistant',
    'resistance to',
    'save vs',
    'save vrs',
    'save versus',
    'saving throw',
    'savingthrow',
    'spell-like',
    'stun',
    'surprise',
    'vision',
    'vulnerable',
    'weapons of less than',
    '\\d+ attack',
    '\\d+ on attack',
    'attack \\d+',
    '\\d+ damage',
    'damage \\d+',
];

// CONFIG.ARS.sounds.combat['special-displacement']
ARS.sounds = {
    combat: {
        death: 'systems/ars/sounds/combat/death-wilhelm.wav',
        unconscious: 'systems/ars/sounds/combat/body_falldown_01.wav',
        'melee-hit': 'systems/ars/sounds/combat/sword-hit.wav',
        'melee-hit-crit': 'systems/ars/sounds/combat/sword-hit-crit.wav',
        'melee-miss': 'systems/ars/sounds/combat/sword-miss.mp3',
        'missile-hit': 'systems/ars/sounds/combat/arrow-hit.wav',
        'missile-hit-crit': 'systems/ars/sounds/combat/sword-hit-crit.wav',
        'missile-miss': 'systems/ars/sounds/combat/arrow-miss.WAV',
        'cast-spell': 'systems/ars/sounds/magic/magic-shot.mp3',
        'special-cast-interrupt': 'systems/ars/sounds/magic/spell-waves.mp3',
        'special-mirror-image': 'systems/ars/sounds/magic/glitter.mp3',
        'special-stone-skin': 'systems/ars/sounds/combat/blade-hit-stone01.mp3',
        'special-displacement': 'systems/ars/sounds/magic/decline-woosh.mp3',
    },
    initiative: {
        start: 'systems/ars/sounds/init/alert1.wav',
        turn: 'systems/ars/sounds/init/alert2.wav',
        startCombatSound: 'systems/ars/sounds/init/alert4.wav',
    },
    save: {
        failure: 'systems/ars/sounds/checks/failure_slide.mp3',
        success: 'systems/ars/sounds/checks/success-fanfare-trumpets.mp3',
    },
};

ARS.chargedActions = ['cast', 'castmelee', 'castranged', 'ranged', 'melee', 'thrown', 'use'];

ARS.ammoAttacks = ['ranged', 'thrown'];

ARS.weaponAttackTypes = ['melee', 'ranged', 'thrown'];

ARS.itemProtectionTypes = ['armor', 'shield', 'ring', 'cloak', 'warding', 'other'];

ARS.itemGearTypes = ['item', 'container'];

ARS.notLargeCreature = ['tiny', 'small', 'medium'];

ARS.inventoryTypes = [
    'item',
    'armor',
    'potion',
    'spell',
    'weapon',
    'currency',
    // "container",
];

ARS.tradeableInventoryTypes = ['item', 'armor', 'potion', 'spell', 'weapon', 'container', 'currency'];

ARS.lootableItemTypes = [
    'spell',
    'item',
    // "container",
];

ARS.academicTypes = [
    'proficiency',
    'ability',
    // "skill",
];

ARS.detailsItemTypes = ['race', 'background'];

ARS.nonInventoryTypes = ['class', 'race', 'background', 'proficiency', 'ability', 'skill', 'power'];

ARS.classSubItemTypes = ['ability', 'skill', 'proficiency'];

// These items do not get their subItems copied and are applied
// via the reconfigureAcademics code because they can be based on level
ARS.levelBasedSubitemTypes = ['class', 'race', 'background'];

ARS.skillGroupNames = ['warrior', 'priest', 'rogue', 'mage', 'other', 'none'];

ARS.attackLocations = {
    normal: 'ARS.defensestyle.normal',
    rear: 'ARS.defensestyle.rear',
    shieldless: 'ARS.defensestyle.shieldless',
    nodex: 'ARS.defensestyle.nodex',
    touch: 'ARS.defensestyle.touch',
};

ARS.auraPermissisions = {
    all: 'ARS.aura.permissions.all',
    limited: 'ARS.aura.permissions.limited',
    observer: 'ARS.aura.permissions.observer',
    owner: 'ARS.aura.permissions.owner',
    gm: 'ARS.aura.permissions.gm',
    none: 'ARS.aura.permissions.none',
};

ARS.damageStyles = {
    normal: 'ARS.damageAdjustments.normal',
    half: 'ARS.damageAdjustments.half',
    max: 'ARS.damageAdjustments.max',
    x2: 'ARS.damageAdjustments.x2',
    x3: 'ARS.damageAdjustments.x3',
    x4: 'ARS.damageAdjustments.x4',
    x5: 'ARS.damageAdjustments.x5',
    x6: 'ARS.damageAdjustments.x6',
    double: 'ARS.damageAdjustments.double',
};

ARS.inventoryTypeMaps = {
    ability: 'abilityList',
    armor: 'armors',
    background: 'backgrounds',
    class: 'classes',
    container: 'containers',
    // "item": "gear",
    item: 'inventory',
    potion: 'potions',
    proficiency: 'proficiencies',
    race: 'races',
    skill: 'skills',
    spell: 'spells',
    weapon: 'weapons',
};

ARS.abilities = {
    str: 'ARS.abilityTypes.str',
    dex: 'ARS.abilityTypes.dex',
    con: 'ARS.abilityTypes.con',
    int: 'ARS.abilityTypes.int',
    wis: 'ARS.abilityTypes.wis',
    cha: 'ARS.abilityTypes.cha',
};
ARS.abilityTypes = {
    none: 'ARS.abilityTypes.none',
    str: 'ARS.abilityTypes.str',
    dex: 'ARS.abilityTypes.dex',
    con: 'ARS.abilityTypes.con',
    int: 'ARS.abilityTypes.int',
    wis: 'ARS.abilityTypes.wis',
    cha: 'ARS.abilityTypes.cha',
};

ARS.abilitiesShort = {
    str: 'ARS.abilityTypes.strabbr',
    dex: 'ARS.abilityTypes.dexabbr',
    con: 'ARS.abilityTypes.conabbr',
    int: 'ARS.abilityTypes.intabbr',
    wis: 'ARS.abilityTypes.wisabbr',
    cha: 'ARS.abilityTypes.chaabbr',
};
ARS.armorTypes = {
    armor: 'ARS.armorTypes.armor',
    shield: 'ARS.armorTypes.shield',
    warding: 'ARS.armorTypes.warding',
    ring: 'ARS.armorTypes.ring',
    cloak: 'ARS.armorTypes.cloak',
    other: 'ARS.armorTypes.other',
};
ARS.armorBulk = {
    none: 'ARS.armorBulk.none',
    fairly: 'ARS.armorBulk.fairly',
    bulky: 'ARS.armorBulk.bulky',
    heavy: 'ARS.armorBulk.heavy',
};
ARS.saves = {
    paralyzation: 'ARS.saveTypes.paralyzation',
    poison: 'ARS.saveTypes.poison',
    death: 'ARS.saveTypes.death',
    rod: 'ARS.saveTypes.rod',
    staff: 'ARS.saveTypes.staff',
    wand: 'ARS.saveTypes.wand',
    petrification: 'ARS.saveTypes.petrification',
    polymorph: 'ARS.saveTypes.polymorph',
    breath: 'ARS.saveTypes.breath',
    spell: 'ARS.saveTypes.spell',
};

ARS.targeting = {
    any: 'ARS.targeting.target',
    single: 'ARS.targeting.single',
    self: 'ARS.targeting.self',
};
ARS.successAction = {
    none: 'ARS.successAction.none',
    halve: 'ARS.successAction.halve',
    remove: 'ARS.successAction.remove',
    self: 'ARS.successAction.self',
};
ARS.targetShapeSelection = {
    all: 'ARS.targetShapeSelection.all',
    none: 'ARS.targetShapeSelection.none', // Added to support spells such as "wall of force"
    self: 'ARS.targetShapeSelection.self',
    hostile: 'ARS.targetShapeSelection.hostile',
    friendly: 'ARS.targetShapeSelection.friendly',
};
ARS.targetShape = {
    none: 'ARS.targetShape.none', // added for later support of "Number of Targets"
    cone: 'ARS.targetShape.cone',
    circle: 'ARS.targetShape.circle',
    ray: 'ARS.targetShape.ray',
    ray2: 'ARS.targetShape.ray2',
    rectangle: 'ARS.targetShape.rectangle',
};

ARS.targetShapeConeType = {
    angle: 'ARS.targetShapeConeType.angle',
    ratio: 'ARS.targetShapeConeType.ratio',
};
ARS.resources = {
    none: 'ARS.resources.none',
    charged: 'ARS.resources.charged',
    item: 'ARS.resources.item',
    powered: 'ARS.resources.powered',
};
ARS.consumed = {
    item: 'ARS.consumed.item',
    charged: 'ARS.consumed.charged',
};
ARS.reusetime = {
    none: 'ARS.reusetime.none',
    daily: 'ARS.reusetime.daily',
    weekly: 'ARS.reusetime.weekly',
    monthly: 'ARS.reusetime.monthly',
};
ARS.saveTypes = {
    paralyzation: 'ARS.saveTypes.paralyzation',
    poison: 'ARS.saveTypes.poison',
    death: 'ARS.saveTypes.death',
    rod: 'ARS.saveTypes.rod',
    staff: 'ARS.saveTypes.staff',
    wand: 'ARS.saveTypes.wand',
    petrification: 'ARS.saveTypes.petrification',
    polymorph: 'ARS.saveTypes.polymorph',
    spell: 'ARS.saveTypes.spell',
    breath: 'ARS.saveTypes.breath',
    none: 'ARS.actions.abilityTypes.none',
};
ARS.currency = {
    pp: 'ARS.currency.pp',
    ep: 'ARS.currency.ep',
    gp: 'ARS.currency.gp',
    sp: 'ARS.currency.sp',
    cp: 'ARS.currency.cp',
};
ARS.currencyAbbrv = {
    pp: 'ARS.currency.abbr.pp',
    ep: 'ARS.currency.abbr.ep',
    gp: 'ARS.currency.abbr.gp',
    sp: 'ARS.currency.abbr.sp',
    cp: 'ARS.currency.abbr.cp',
};
ARS.ArmorClass = 'ARS.ArmorClass';
ARS.ArmorClassShort = 'ARS.ArmorClassShort';
ARS.HitPoints = 'ARS.HitPoints';
ARS.BaseHitPoints = 'ARS.BaseHitPoints';
ARS.hpbase = 'ARS.hpbase';
ARS.HitPointsShort = 'ARS.HitPointsShort';

ARS.spellTypes = {
    arcane: 'ARS.spellTypes.arcane',
    divine: 'ARS.spellTypes.divine',
};

ARS.weaponTypes = {
    melee: 'ARS.weaponTypes.melee',
    ranged: 'ARS.weaponTypes.ranged',
    thrown: 'ARS.weaponTypes.thrown',
};
ARS.weaponDamageTypes = {
    slashing: 'ARS.damageTypes.slashing',
    piercing: 'ARS.damageTypes.piercing',
    bludgeoning: 'ARS.damageTypes.bludgeoning',
    bleeding: 'ARS.damageTypes.bleeding',
    acid: 'ARS.damageTypes.acid',
    cold: 'ARS.damageTypes.cold',
    fire: 'ARS.damageTypes.fire',
    force: 'ARS.damageTypes.force',
    gas: 'ARS.damageTypes.gas',
    lightning: 'ARS.damageTypes.lightning',
    necrotic: 'ARS.damageTypes.necrotic',
    poison: 'ARS.damageTypes.poison',
    psionic: 'ARS.damageTypes.psionic', // #psionic
    psp: 'ARS.damageTypes.psp',
    pspattack: 'ARS.damageTypes.pspattack',
    pspdefense: 'ARS.damageTypes.pspdefense',
    radiant: 'ARS.damageTypes.radiant',
    none: 'ARS.damageTypes.none',
};

ARS.dmgTypeIcons = {
    fire: 'icons/svg/fire.svg',
    lightning: '/icons/svg/lightning.svg',
};

ARS.resistTypes = {
    resist: 'ARS.resistTypes.resist',
    immune: 'ARS.resistTypes.immune',
    vulnerable: 'ARS.resistTypes.vulnerable',
    magicpotency: 'ARS.resistTypes.magicpotency',
    perdice: 'ARS.resistTypes.perdice',
};

ARS.metalprotections = {
    halve: 'ARS.metalprotections.halve',
    full: 'ARS.metalprotections.full',
};

ARS.alignmentTypes = {
    n: 'ARS.alignmentTypes.n',
    ng: 'ARS.alignmentTypes.ng',
    ne: 'ARS.alignmentTypes.ne',
    cn: 'ARS.alignmentTypes.cn',
    cg: 'ARS.alignmentTypes.cg',
    ce: 'ARS.alignmentTypes.ce',
    ln: 'ARS.alignmentTypes.ln',
    lg: 'ARS.alignmentTypes.lg',
    le: 'ARS.alignmentTypes.le',
};

ARS.alignmentLongNameMap = {
    n: 'neutral',
    ng: 'neutralgood',
    ne: 'neutralevil',
    cn: 'chaoticevil',
    cg: 'chaoticgood',
    ce: 'chaotieneutral',
    ln: 'lawfulneutral',
    lg: 'lawfulgood',
    le: 'lawfulevil',
};

ARS.sizeTypes = {
    tiny: 'ARS.sizeTypes.tiny',
    small: 'ARS.sizeTypes.small',
    medium: 'ARS.sizeTypes.medium',
    large: 'ARS.sizeTypes.large',
    huge: 'ARS.sizeTypes.huge',
    gargantuan: 'ARS.sizeTypes.gargantuan',
};
ARS.tokenSizeMapping = {
    tiny: 0.25,
    small: 0.5,
    medium: 1,
    large: 1,
    huge: 2,
    gargantuan: 4,
};
ARS.skillTypes = {
    ascending: 'ARS.skillTypes.ascending',
    decending: 'ARS.skillTypes.decending',
};

ARS.actions = {};
ARS.actions.abilityTypes = {
    str: 'ARS.actions.abilityTypes.str',
    dex: 'ARS.actions.abilityTypes.dex',
    none: 'ARS.actions.abilityTypes.none',
};
ARS.actions.types = {
    cast: 'ARS.actions.type.cast',
    castshape: 'ARS.actions.type.castshape',
    damage: 'ARS.actions.type.damage',
    heal: 'ARS.actions.type.heal',
    effect: 'ARS.actions.type.effect',
    'item-effect': 'ARS.actions.type.item-effect',
    use: 'ARS.actions.type.use',
    // "castmelee": "ARS.actions.type.castmelee",
    // "castranged": "ARS.actions.type.castranged",
    melee: 'ARS.actions.type.melee',
    thrown: 'ARS.actions.type.thrown',
    ranged: 'ARS.actions.type.ranged',
    macro: 'ARS.actions.type.macro',
};
ARS.actions.durationTypes = {
    round: 'ARS.actions.duration.type.round',
    turn: 'ARS.actions.duration.type.turn',
    hour: 'ARS.actions.duration.type.hour',
    day: 'ARS.actions.duration.type.day',
};
ARS.actions.effect_modes = {
    0: 'ARS.actions.effect_modes.custom',
    1: 'ARS.actions.effect_modes.multiply',
    2: 'ARS.actions.effect_modes.add',
    3: 'ARS.actions.effect_modes.downgrade',
    4: 'ARS.actions.effect_modes.upgrade',
    5: 'ARS.actions.effect_modes.override',
};

ARS.actions.effect_visibility = {
    default: 'ARS.actions.effect_visibility.default',
    always: 'ARS.actions.effect_visibility.always',
    owner: 'ARS.actions.effect_visibility.owner',
    gmonly: 'ARS.actions.effect_visibility.gmonly',
};
ARS.locationStates = {
    carried: 'ARS.locationStates.carried',
    nocarried: 'ARS.locationStates.nocarried',
    equipped: 'ARS.locationStates.equipped',
};
ARS.locationStates.images = {
    carried: 'icons/svg/chest.svg',
    nocarried: 'icons/svg/cancel.svg',
    equipped: 'icons/svg/combat.svg',
};

ARS.locationStates.fasicons = {
    carried: 'box',
    nocarried: 'exclamation-circle',
    equipped: 'shield-halved',
};

ARS.gearSearchFilters = {
    none: 'ARS.gearSearchFilters.none',
    weapon: 'ARS.gearSearchFilters.weapon',
    armor: 'ARS.gearSearchFilters.armor',
    gear: 'ARS.gearSearchFilters.gear',
    container: 'ARS.gearSearchFilters.container',
    magic: 'ARS.gearSearchFilters.magic',
    indentified: 'ARS.gearSearchFilters.identified',
    unidentified: 'ARS.gearSearchFilters.unidentified',
    equipped: 'ARS.gearSearchFilters.equipped',
    carried: 'ARS.gearSearchFilters.carried',
};

/**
 *
 * Drop down list of effect keys, sample values and mode included.
 *
 * actionOnly is for status, it requires flags to make Foundry work. Can't be applied as effect manually.
 *
 * MODES
 * {
    "CUSTOM": 0,
    "MULTIPLY": 1,
    "ADD": 2,
    "DOWNGRADE": 3,
    "UPGRADE": 4,
    "OVERRIDE": 5
 * }
 */
ARS.selectEffectKeys = [
    { name: 'system.abilities.cha.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.abilities.con.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.abilities.dex.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.abilities.int.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.abilities.str.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.abilities.wis.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },

    { name: 'system.abilities.cha.percent', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.abilities.con.percent', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.abilities.dex.percent', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.abilities.int.percent', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.abilities.str.percent', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.abilities.wis.percent', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },

    {
        name: 'special.absorb',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"amount":10, "damageType":"fire"}',
    },
    {
        name: 'special.aura',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"distance": 10, "color": "red", "faction": "friendly", "permission": "gm", "opacity": "0.50", "shape": "round"}',
    },
    {
        name: 'special.light',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"color":"#FFFFFF", "dim": 10, "bright": 5, "angle": 360, "animation": "torch", "alpha": 0.25, "luminosity": 0.1}',
    },
    { name: 'special.mirrorimage', mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM, value: 5 },
    {
        name: 'special.ongoing',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"type":"heal", "rate":"1", "cycle": "round", "dmgType": "", "formula": "1d4"}',
    },
    // {
    //     name: 'special.ongoingproperty',
    //     mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
    //     value: '{"type":"heal", "rate":"1", "cycle": "round", "dmgType": "", "formula": "1d4", "property": "", "mode": "", "effectLabel": "", "itemId": "", "actorId": ""}',
    // },
    // { name: "special.status", actionOnly: true, mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM, value: 'blind' },
    { name: 'special.status', mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM, value: 'blind' },
    { name: 'special.statusimmune', mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM, value: 'sleep,charm,hold' },
    { name: 'special.stoneskin', mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM, value: 5 },
    { name: 'special.displacement', mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM, value: '' },
    {
        name: 'special.vision',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"range": 0, "angle": 360, "mode": "basic"}',
    },

    { name: 'system.attributes.hp.base', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '5' },
    { name: 'system.attributes.movement.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '6' },

    // #psionic
    { name: 'system.psionics.psp.base', mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE, value: '1' },
    { name: 'system.psionics.psp.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.psionics.pspattack.base', mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE, value: '1' },
    { name: 'system.psionics.pspattack.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.psionics.pspdefense.base', mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE, value: '1' },
    { name: 'system.psionics.pspdefense.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.psionics.closedMind', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '3' },

    { name: 'system.mods.ac.base', mode: CONST.ACTIVE_EFFECT_MODES.DOWNGRADE, value: '8' },
    { name: 'system.mods.ac.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.ac.front.base', mode: CONST.ACTIVE_EFFECT_MODES.DOWNGRADE, value: '1' },
    { name: 'system.mods.ac.front.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.ac.rear.base', mode: CONST.ACTIVE_EFFECT_MODES.DOWNGRADE, value: '8' },
    { name: 'system.mods.ac.rear.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },

    { name: 'system.mods.ac.ranged.base', mode: CONST.ACTIVE_EFFECT_MODES.DOWNGRADE, value: '8' },
    { name: 'system.mods.ac.ranged.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.ac.ranged.front.base', mode: CONST.ACTIVE_EFFECT_MODES.DOWNGRADE, value: '8' },
    { name: 'system.mods.ac.ranged.front.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.ac.ranged.rear.base', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.ac.ranged.rear.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },

    { name: 'system.mods.acstatus', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: 'nodex noshield' },

    { name: 'system.mods.attack.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.attack.melee', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.attack.ranged', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.magicpotency', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },

    {
        name: 'system.mods.check.formula',
        mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
        value: '(floor(@rank.levels.max)+1)',
    },
    { name: 'system.mods.check.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },

    { name: 'system.mods.damage.value', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.damage.melee', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.damage.ranged', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.damage.multiplier.value', mode: CONST.ACTIVE_EFFECT_MODES.UPGRADE, value: '2' },
    { name: 'system.mods.damage.multiplier.melee', mode: CONST.ACTIVE_EFFECT_MODES.UPGRADE, value: '2' },

    { name: 'system.mods.damage.multiplier.ranged', mode: CONST.ACTIVE_EFFECT_MODES.UPGRADE, value: '2' },
    { name: 'system.mods.damage.multiplier.thrown', mode: CONST.ACTIVE_EFFECT_MODES.UPGRADE, value: '2' },

    // this doesnt work because derived values do not exist during this stage
    // {
    //     name: 'system.mods.formula.ac.dex',
    //     mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
    //     value: '@abilities.dex.defensive*2',
    // },
    {
        name: 'system.mods.formula.ac.value',
        mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
        value: '(floor(@rank.levels.max/2)+1)',
    },
    {
        name: 'system.mods.formula.ac.front.value',
        mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
        value: '(floor(@rank.levels.max/2)+1)',
    },
    {
        name: 'system.mods.formula.ac.rear.value',
        mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
        value: '(floor(@rank.levels.max/2)+1)',
    },
    // { name: "system.mods.formula.ac.melee.front.value", mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE, value: "(floor(@rank.levels.max/2)+1)" },
    // { name: "system.mods.formula.ac.melee.rear.value", mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE, value: "(floor(@rank.levels.max/2)+1)" },
    {
        name: 'system.mods.formula.ac.ranged.front.value',
        mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
        value: '(floor(@rank.levels.max/2)+1)',
    },
    {
        name: 'system.mods.formula.ac.ranged.rear.value',
        mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
        value: '(floor(@rank.levels.max/2)+1)',
    },
    {
        name: 'system.mods.formula.potency.resist',
        mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
        value: 'floor(@rank.levels.max/4)',
    },
    {
        name: 'system.mods.formula.potency.attack',
        mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
        value: 'floor(@rank.levels.max/4)',
    },
    { name: 'system.mods.initiative', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },

    { name: 'system.mods.levels.arcane', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.levels.divine', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },

    { name: 'system.mods.resist', mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM, value: 'fire' },
    { name: 'system.mods.immune', mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM, value: 'cold' },
    { name: 'system.mods.vuln', mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM, value: 'lightning' },

    { name: 'system.mods.magic.resist', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.mods.resists.magicpotency', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.resists.perdice.lightning', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.resists.perdice.fire', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.resists.perdice.cold', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.mods.resists.perdice.all', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },

    // { name: "system.mods.saves.all", mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: "1" },
    {
        name: 'system.mods.saves.all',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"formula": "1", "properties": ""}',
    },

    {
        name: 'system.mods.saves.paralyzation',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"formula": "1", "properties": ""}',
    },
    {
        name: 'system.mods.saves.poison',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"formula": "1", "properties": ""}',
    },
    {
        name: 'system.mods.saves.death',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"formula": "1", "properties": ""}',
    },
    {
        name: 'system.mods.saves.rod',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"formula": "1", "properties": ""}',
    },
    {
        name: 'system.mods.saves.staff',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"formula": "1", "properties": ""}',
    },
    {
        name: 'system.mods.saves.wand',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"formula": "1", "properties": ""}',
    },
    {
        name: 'system.mods.saves.petrification',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"formula": "1", "properties": ""}',
    },
    {
        name: 'system.mods.saves.polymorph',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"formula": "1", "properties": ""}',
    },
    {
        name: 'system.mods.saves.breath',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"formula": "1", "properties": ""}',
    },
    {
        name: 'system.mods.saves.spell',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"formula": "1", "properties": ""}',
    },

    { name: 'system.mods.skill.pick-pockets', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.mods.skill.open-locks', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.mods.skill.findremove-traps', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.mods.skill.move-silently', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.mods.skill.hide-in-shadows', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.mods.skill.detect-noise', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.mods.skill.climb-walls', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },
    { name: 'system.mods.skill.read-languages', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '10' },

    { name: 'system.spellInfo.slots.arcane.value.0', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.arcane.value.1', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.arcane.value.2', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.arcane.value.3', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.arcane.value.4', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.arcane.value.5', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.arcane.value.6', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.arcane.value.7', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.arcane.value.8', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.arcane.value.9', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },

    { name: 'system.spellInfo.slots.divine.value.0', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.divine.value.1', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.divine.value.2', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.divine.value.3', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.divine.value.4', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.divine.value.5', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.divine.value.6', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },
    { name: 'system.spellInfo.slots.divine.value.7', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: '1' },

    {
        name: 'target.always',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"properties": "", "type": "attack", "formula": "1d6"}',
    },
    {
        name: 'target.alignment',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"trigger": "ne,ce,le", "properties": "", "type": "attack", "formula": "1d6"}',
    },
    {
        name: 'target.properties_any',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"trigger": "regeneration, cold-using", "properties": "", "type": "attack", "formula": "1d6"}',
    },
    {
        name: 'target.properties_all',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"trigger": "regeneration, cold-using", "properties": "", "type": "attack", "formula": "1d6"}',
    },
    {
        name: 'target.size',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"trigger": "small,medium", "properties": "", "type": "attack", "formula": "1d6"}',
    },
    {
        name: 'target.type',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"trigger": "ogre,troll", "properties": "", "type": "attack", "formula": "1d6"}',
    },
    {
        name: 'target.distance',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"trigger": "0,20", "properties": "", "type": "attack", "formula": "1d6"}',
    },

    {
        name: 'attacker.always',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"properties": "", "type": "attack", "formula": "1d6"}',
    },
    {
        name: 'attacker.alignment',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"trigger": "ne,ce,le", "properties": "", "type": "attack", "formula": "1d6"}',
    },
    {
        name: 'attacker.properties_any',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"trigger": "regeneration, cold-using", "properties": "", "type": "attack", "formula": "1d6"}',
    },
    {
        name: 'attacker.properties_all',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"trigger": "regeneration, cold-using", "properties": "", "type": "attack", "formula": "1d6"}',
    },
    {
        name: 'attacker.size',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"trigger": "small,medium", "properties": "", "type": "attack", "formula": "1d6"}',
    },
    {
        name: 'attacker.type',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"trigger": "ogre,troll", "properties": "", "type": "attack", "formula": "1d6"}',
    },
    {
        name: 'attacker.distance',
        mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        value: '{"trigger": "0,20", "properties": "", "type": "attack", "formula": "1d6"}',
    },
];
ARS.selectEffectKeys.sort(utilitiesManager.sortByRecordName);

ARS.strengthTable = {};
// Strength[abilityScore]={hit adj, dam adj, weight allow, max press, open doors, bend bars, light enc, moderate enc, heavy enc, severe enc, max enc}
ARS.strengthTable['0'] = {
    0: [
        'ARS.abilityFields.str.hit',
        'ARS.abilityFields.str.dmg',
        'ARS.abilityFields.str.allow',
        'ARS.abilityFields.str.press',
        'ARS.abilityFields.str.open',
        'ARS.abilityFields.str.bendbars',
        'ARS.abilityFields.str.encumbrance.light',
        'ARS.abilityFields.str.encumbrance.moderate',
        'ARS.abilityFields.str.encumbrance.heavy',
        'ARS.abilityFields.str.encumbrance.severe',
        'ARS.abilityFields.str.encumbrance.max',
    ],
    1: [-3, -1, -35, 0, ['1d6', 1, '1d6', 0], 0, 1, 36, 71, 115],
    2: [-3, -1, -35, 0, ['1d6', 1, '1d6', 0], 0, 1, 36, 71, 115],
    3: [-3, -1, -35, 0, ['1d6', 1, '1d6', 0], 0, 1, 36, 71, 115],
    4: [-2, -1, -25, 0, ['1d6', 1, '1d6', 0], 0, 11, 46, 81, 125],
    5: [-2, -1, -25, 0, ['1d6', 1, '1d6', 0], 0, 11, 46, 81, 125],
    6: [-1, 0, -15, 0, ['1d6', 1, '1d6', 0], 0, 21, 56, 91, 135],
    7: [-1, 0, -15, 0, ['1d6', 1, '1d6', 0], 0, 21, 56, 91, 135],
    8: [0, 0, 0, 0, ['1d6', 2, '1d6', 0], 1, 36, 71, 106, 150],
    9: [0, 0, 0, 0, ['1d6', 2, '1d6', 0], 1, 36, 71, 106, 150],
    10: [0, 0, 0, 0, ['1d6', 2, '1d6', 0], 2, 36, 71, 106, 150],
    11: [0, 0, 0, 0, ['1d6', 2, '1d6', 0], 2, 36, 71, 106, 150],
    12: [0, 0, 10, 0, ['1d6', 2, '1d6', 0], 4, 46, 81, 116, 160],
    13: [0, 0, 10, 0, ['1d6', 2, '1d6', 0], 4, 46, 81, 116, 160],
    14: [0, 0, 20, 0, ['1d6', 2, '1d6', 0], 7, 56, 91, 126, 170],
    15: [0, 0, 20, 0, ['1d6', 2, '1d6', 0], 7, 56, 91, 126, 170],
    16: [0, 1, 35, 0, ['1d6', 3, '1d6', 0], 10, 71, 106, 141, 185],
    17: [1, 1, 50, 0, ['1d6', 3, '1d6', 0], 13, 86, 121, 156, 200],
    18: [1, 2, 75, 0, ['1d6', 3, '1d6', 0], 16, 111, 146, 181, 225],
    19: [3, 6, 300, 0, ['1d8', 7, '1d6', 3], 40, 336, 371, 406, 450],
    20: [3, 8, 535, 700, ['1d8', 7, '1d6', 3], 60, 536, 580, 610, 670, 700],
    21: [4, 9, 635, 810, ['1d10', 9, '1d6', 4], 70, 636, 680, 720, 790, 810],
    22: [4, 10, 785, 970, ['1d12', 11, '1d6', 4], 80, 786, 830, 870, 900, 970],
    23: [5, 11, 935, 1130, ['1d12', 11, '1d6', 5], 90, 936, 960, 1000, 1090, 1130],
    24: [6, 12, 1235, 1440, ['1d20', 19, '1d8', 7], 95, 1236, 1290, 1300, 1380, 1440],
    25: [7, 14, 1535, 1750, ['1d24', 23, '1d10', 9], 99, 1536, 1590, 1600, 1680, 1750],
    // Deal with 18 01-100 strength
    50: [1, 3, 100, 0, ['1d6', 3, '1d6', 0], 20, 136, 171, 206, 250],
    75: [2, 3, 125, 0, ['1d6', 3, '1d6', 0], 25, 161, 196, 231, 275],
    90: [2, 4, 150, 0, ['1d6', 4, '1d6', 0], 30, 186, 221, 256, 300],
    99: [2, 5, 200, 0, ['1d6', 4, '1d6', 1], 35, 236, 271, 306, 350],
    100: [3, 6, 300, 0, ['1d6', 5, '1d6', 2], 40, 336, 371, 406, 450],
};
// Strength[abilityScore]={hit adj, dam adj, weight allow, max press, open doors, bend bars, light enc, moderate enc, heavy enc, severe enc, max enc}
ARS.strengthTable['1'] = {
    0: [
        'ARS.abilityFields.str.hit',
        'ARS.abilityFields.str.dmg',
        'ARS.abilityFields.str.allow',
        'ARS.abilityFields.str.press',
        'ARS.abilityFields.str.open',
        'ARS.abilityFields.str.bendbars',
        'ARS.abilityFields.str.encumbrance.light',
        'ARS.abilityFields.str.encumbrance.moderate',
        'ARS.abilityFields.str.encumbrance.heavy',
        'ARS.abilityFields.str.encumbrance.severe',
        'ARS.abilityFields.str.encumbrance.max',
    ],
    1: [-3, -1, -35, 0, ['1d6', 1, '1d6', 0], 0, 0, 0, 0, 0, 0],
    2: [-3, -1, -35, 0, ['1d6', 1, '1d6', 0], 0, 0, 0, 0, 0, 0],
    3: [-3, -1, -35, 0, ['1d6', 1, '1d6', 0], 0, 0, 0, 0, 0, 0],
    4: [-2, -1, -25, 0, ['1d6', 1, '1d6', 0], 0, 0, 0, 0, 0, 0],
    5: [-2, -1, -25, 0, ['1d6', 1, '1d6', 0], 0, 0, 0, 0, 0, 0],
    6: [-1, 0, -15, 0, ['1d6', 1, '1d6', 0], 0, 0, 0, 0, 0, 0],
    7: [-1, 0, -15, 0, ['1d6', 1, '1d6', 0], 0, 0, 0, 0, 0, 0],
    8: [0, 0, 0, 0, ['1d6', 2, '1d6', 0], 1, 0, 0, 0, 0, 0],
    9: [0, 0, 0, 0, ['1d6', 2, '1d6', 0], 1, 0, 0, 0, 0, 0],
    10: [0, 0, 0, 0, ['1d6', 2, '1d6', 0], 2, 0, 0, 0, 0, 0],
    11: [0, 0, 0, 0, ['1d6', 2, '1d6', 0], 2, 0, 0, 0, 0, 0],
    12: [0, 0, 10, 0, ['1d6', 2, '1d6', 0], 4, 0, 0, 0, 0, 0],
    13: [0, 0, 10, 0, ['1d6', 2, '1d6', 0], 4, 0, 0, 0, 0, 0],
    14: [0, 0, 20, 0, ['1d6', 2, '1d6', 0], 7, 0, 0, 0, 0, 0],
    15: [0, 0, 20, 0, ['1d6', 2, '1d6', 0], 7, 0, 0, 0, 0, 0],
    16: [0, 1, 35, 0, ['1d6', 3, '1d6', 0], 10, 0, 0, 0, 0, 0],
    17: [1, 1, 50, 0, ['1d6', 3, '1d6', 0], 13, 0, 0, 0, 0, 0],
    18: [1, 2, 75, 0, ['1d6', 3, '1d6', 0], 16, 0, 0, 0, 0, 0],
    19: [3, 6, 300, 0, ['1d8', 7, '1d6', 3], 50, 0, 0, 0, 0, 0],
    20: [3, 8, 535, 700, ['1d8', 7, '1d6', 3], 60, 0, 0, 0, 0, 0],
    21: [4, 9, 635, 810, ['1d10', 9, '1d6', 4], 70, 0, 0, 0, 0, 0],
    22: [4, 10, 785, 970, ['1d12', 11, '1d6', 4], 80, 0, 0, 0, 0, 0],
    23: [5, 11, 935, 1130, ['1d12', 11, '1d6', 5], 90, 0, 0, 0, 0, 0],
    24: [6, 12, 1235, 1440, ['1d20', 19, '1d8', 7], 100, 0, 0, 0, 0, 0],
    25: [7, 14, 1535, 1750, ['1d24', 23, '1d10', 9], 100, 0, 0, 0, 0, 0],
    // Deal with 18 01-100 strength
    50: [1, 3, 100, 0, ['1d6', 3, '1d6', 0], 20, 0, 0, 0, 0, 0],
    75: [2, 3, 125, 0, ['1d6', 3, '1d6', 0], 25, 0, 0, 0, 0, 0],
    90: [2, 4, 150, 0, ['1d6', 4, '1d6', 0], 30, 0, 0, 0, 0, 0],
    99: [2, 5, 200, 0, ['1d6', 4, '1d6', 1], 35, 0, 0, 0, 0, 0],
    100: [3, 6, 300, 0, ['1d6', 5, '1d6', 2], 40, 0, 0, 0, 0, 0],
};

// Strength[abilityScore]={hit adj, dam adj, weight allow, max press, open doors, bend bars, light enc, moderate enc, heavy enc, severe enc, max enc}
ARS.strengthTable['2'] = {
    0: [
        'ARS.abilityFields.str.hit',
        'ARS.abilityFields.str.dmg',
        'ARS.abilityFields.str.allow',
        'ARS.abilityFields.str.press',
        'ARS.abilityFields.str.open',
        'ARS.abilityFields.str.bendbars',
        'ARS.abilityFields.str.encumbrance.unencumbered',
        'ARS.abilityFields.str.encumbrance.light',
        'ARS.abilityFields.str.encumbrance.moderate',
        'ARS.abilityFields.str.encumbrance.heavy',
        'ARS.abilityFields.str.encumbrance.severe',
        'ARS.abilityFields.str.encumbrance.max',
    ],
    1: [-5, -4, 1, 3, [1, 0], 0, 1, 2, 3, 4, 6, 6],
    2: [-3, -2, 1, 5, [1, 0], 0, 1, 2, 3, 4, 6, 6],
    3: [-3, -1, 5, 10, [2, 0], 0, 5, 6, 7, 9, 10, 10],
    4: [-2, -1, 10, 25, [3, 0], 0, 10, 13, 16, 19, 25, 25],
    5: [-2, -1, 10, 25, [3, 0], 0, 10, 13, 16, 19, 25, 25],
    6: [-1, 0, 20, 55, [4, 0], 0, 20, 29, 38, 46, 55, 55],
    7: [-1, 0, 20, 55, [4, 0], 0, 20, 29, 38, 46, 55, 55],
    8: [0, 0, 35, 90, [5, 0], 1, 35, 50, 65, 80, 90, 90],
    9: [0, 0, 35, 90, [5, 0], 1, 35, 50, 65, 80, 90, 90],
    10: [0, 0, 40, 115, [6, 0], 2, 40, 58, 76, 96, 110, 110],
    11: [0, 0, 40, 115, [6, 0], 2, 40, 58, 76, 96, 110, 110],
    12: [0, 0, 45, 140, [7, 0], 4, 45, 69, 93, 117, 140, 140],
    13: [0, 0, 45, 140, [7, 0], 4, 45, 69, 93, 117, 140, 140],
    14: [0, 0, 55, 170, [8, 0], 7, 55, 85, 115, 145, 170, 170],
    15: [0, 0, 55, 170, [8, 0], 7, 55, 85, 115, 145, 170, 170],
    16: [0, 1, 70, 195, [9, 0], 10, 70, 100, 130, 160, 195, 195],
    17: [1, 1, 85, 220, [10, 0], 13, 85, 121, 157, 193, 220, 220],
    18: [1, 2, 110, 255, [11, 0], 16, 110, 149, 188, 227, 255, 255],
    19: [3, 7, 485, 640, [16, 8], 50, 450, 486, 500, 550, 600, 640],
    20: [3, 8, 535, 700, [17, 10], 60, 490, 536, 580, 610, 670, 700],
    21: [4, 9, 635, 810, [17, 12], 70, 590, 636, 680, 720, 790, 810],
    22: [4, 10, 785, 970, [18, 14], 80, 736, 786, 830, 870, 900, 970],
    23: [5, 11, 935, 1130, [18, 16], 90, 876, 936, 960, 1000, 1090, 1130],
    24: [6, 12, 1235, 1440, [19, 17], 95, 1180, 1236, 1290, 1300, 1380, 1440],
    25: [7, 14, 1535, 1750, [19, 18], 99, 1496, 1536, 1590, 1600, 1680, 1750],
    // Deal with 18 01-100 strength
    50: [1, 3, 135, 280, [12, 0], 20, 135, 174, 213, 252, 280, 280],
    75: [2, 3, 160, 305, [13, 0], 25, 160, 199, 238, 277, 305, 305],
    90: [2, 4, 185, 330, [14, 0], 30, 185, 224, 263, 302, 330, 330],
    99: [2, 5, 235, 380, [15, 3], 35, 235, 274, 313, 352, 380, 380],
    100: [3, 6, 335, 480, [16, 6], 40, 336, 374, 413, 452, 480, 480],
};

ARS.dexterityTable = {};
// Dexterity[abilityScore]={reaction, missile, defensive}
ARS.dexterityTable['0'] = {
    0: ['ARS.abilityFields.dex.reaction', 'ARS.abilityFields.dex.missile', 'ARS.abilityFields.dex.defensive'],
    1: [-3, -3, 4],
    2: [-3, -3, 4],
    3: [-3, -3, 4],
    4: [-2, -2, 3],
    5: [-1, -1, 2],
    6: [0, 0, 1],
    7: [0, 0, 0],
    8: [0, 0, 0],
    9: [0, 0, 0],
    10: [0, 0, 0],
    11: [0, 0, 0],
    12: [0, 0, 0],
    13: [0, 0, 0],
    14: [0, 0, 0],
    15: [0, 0, -1],
    16: [1, 1, -2],
    17: [2, 2, -3],
    18: [3, 3, -4],
    19: [3, 3, -4],
    20: [3, 3, -4],
    21: [3, 3, -4],
    22: [3, 3, -4],
    23: [3, 3, -4],
    24: [3, 3, -4],
    25: [3, 3, -4],
};
ARS.dexterityTable['1'] = {
    0: ['ARS.abilityFields.dex.reaction', 'ARS.abilityFields.dex.missile', 'ARS.abilityFields.dex.defensive'],
    1: [-6, -6, 5],
    2: [-4, -4, 5],
    3: [-3, -3, 4],
    4: [-2, -2, 3],
    5: [-1, -1, 2],
    6: [0, 0, 1],
    7: [0, 0, 0],
    8: [0, 0, 0],
    9: [0, 0, 0],
    10: [0, 0, 0],
    11: [0, 0, 0],
    12: [0, 0, 0],
    13: [0, 0, 0],
    14: [0, 0, 0],
    15: [0, 0, -1],
    16: [1, 1, -2],
    17: [2, 2, -3],
    18: [3, 3, -4],
    19: [3, 3, -4],
    20: [3, 3, -4],
    21: [4, 4, -5],
    22: [4, 4, -5],
    23: [4, 4, -5],
    24: [5, 5, -6],
    25: [5, 5, -6],
};
ARS.dexterityTable['2'] = {
    0: ['ARS.abilityFields.dex.reaction', 'ARS.abilityFields.dex.missile', 'ARS.abilityFields.dex.defensive'],
    1: [-6, -6, 5],
    2: [-4, -4, 5],
    3: [-3, -3, 4],
    4: [-2, -2, 3],
    5: [-1, -1, 2],
    6: [0, 0, 1],
    7: [0, 0, 0],
    8: [0, 0, 0],
    9: [0, 0, 0],
    10: [0, 0, 0],
    11: [0, 0, 0],
    12: [0, 0, 0],
    13: [0, 0, 0],
    14: [0, 0, 0],
    15: [0, 0, -1],
    16: [1, 1, -2],
    17: [2, 2, -3],
    18: [2, 2, -4],
    19: [3, 3, -4],
    20: [3, 3, -4],
    21: [4, 4, -5],
    22: [4, 4, -5],
    23: [4, 4, -5],
    24: [5, 5, -6],
    25: [5, 5, -6],
};

ARS.wisdomBonusSlots = {};
// ability score (1-25) : 0,1,2,3,4,5,6,7 (level/slots)
ARS.wisdomBonusSlots['0'] = {
    0: [],
    1: [0, 0, 0, 0, 0, 0, 0, 0],
    2: [0, 0, 0, 0, 0, 0, 0, 0],
    3: [0, 0, 0, 0, 0, 0, 0, 0],
    4: [0, 0, 0, 0, 0, 0, 0, 0],
    5: [0, 0, 0, 0, 0, 0, 0, 0],
    6: [0, 0, 0, 0, 0, 0, 0, 0],
    7: [0, 0, 0, 0, 0, 0, 0, 0],
    8: [0, 0, 0, 0, 0, 0, 0, 0],
    9: [0, 0, 0, 0, 0, 0, 0, 0],
    10: [0, 0, 0, 0, 0, 0, 0, 0],
    11: [0, 0, 0, 0, 0, 0, 0, 0],
    12: [0, 0, 0, 0, 0, 0, 0, 0],
    13: [0, 1, 0, 0, 0, 0, 0, 0],
    14: [0, 2, 0, 0, 0, 0, 0, 0],
    15: [0, 2, 1, 0, 0, 0, 0, 0],
    16: [0, 2, 2, 0, 0, 0, 0, 0],
    17: [0, 2, 2, 1, 0, 0, 0, 0],
    18: [0, 2, 2, 1, 1, 0, 0, 0],
    19: [0, 3, 2, 1, 1, 0, 0, 0],
    20: [0, 3, 2, 1, 1, 0, 0, 0],
    21: [0, 3, 2, 1, 1, 0, 0, 0],
    22: [0, 3, 2, 1, 1, 0, 0, 0],
    23: [0, 3, 2, 1, 1, 0, 0, 0],
    24: [0, 3, 2, 1, 1, 0, 0, 0],
    25: [0, 3, 2, 1, 1, 0, 0, 0],
};
// ability score (1-25) : 0,1,2,3,4,5,6,7 (level/slots)
ARS.wisdomBonusSlots['1'] = {
    0: [],
    1: [0, 0, 0, 0, 0, 0, 0, 0],
    2: [0, 0, 0, 0, 0, 0, 0, 0],
    3: [0, 0, 0, 0, 0, 0, 0, 0],
    4: [0, 0, 0, 0, 0, 0, 0, 0],
    5: [0, 0, 0, 0, 0, 0, 0, 0],
    6: [0, 0, 0, 0, 0, 0, 0, 0],
    7: [0, 0, 0, 0, 0, 0, 0, 0],
    8: [0, 0, 0, 0, 0, 0, 0, 0],
    9: [0, 0, 0, 0, 0, 0, 0, 0],
    10: [0, 0, 0, 0, 0, 0, 0, 0],
    11: [0, 0, 0, 0, 0, 0, 0, 0],
    12: [0, 0, 0, 0, 0, 0, 0, 0],
    13: [0, 1, 0, 0, 0, 0, 0, 0],
    14: [0, 2, 0, 0, 0, 0, 0, 0],
    15: [0, 2, 1, 0, 0, 0, 0, 0],
    16: [0, 2, 2, 0, 0, 0, 0, 0],
    17: [0, 2, 2, 1, 0, 0, 0, 0],
    18: [0, 2, 2, 1, 1, 0, 0, 0],
    19: [0, 3, 2, 2, 1, 0, 0, 0],
    20: [0, 3, 3, 2, 2, 0, 0, 0],
    21: [0, 3, 3, 3, 2, 1, 0, 0],
    22: [0, 3, 3, 3, 3, 2, 0, 0],
    23: [0, 4, 3, 3, 3, 2, 1, 0],
    24: [0, 4, 3, 3, 3, 3, 2, 0],
    25: [0, 4, 3, 3, 3, 3, 3, 1],
};
// ability score (1-25) : 0,1,2,3,4,5,6,7 (level/slots)
ARS.wisdomBonusSlots['2'] = {
    0: [],
    1: [0, 0, 0, 0, 0, 0, 0, 0],
    2: [0, 0, 0, 0, 0, 0, 0, 0],
    3: [0, 0, 0, 0, 0, 0, 0, 0],
    4: [0, 0, 0, 0, 0, 0, 0, 0],
    5: [0, 0, 0, 0, 0, 0, 0, 0],
    6: [0, 0, 0, 0, 0, 0, 0, 0],
    7: [0, 0, 0, 0, 0, 0, 0, 0],
    8: [0, 0, 0, 0, 0, 0, 0, 0],
    9: [0, 0, 0, 0, 0, 0, 0, 0],
    10: [0, 0, 0, 0, 0, 0, 0, 0],
    11: [0, 0, 0, 0, 0, 0, 0, 0],
    12: [0, 0, 0, 0, 0, 0, 0, 0],
    13: [0, 1, 0, 0, 0, 0, 0, 0],
    14: [0, 2, 0, 0, 0, 0, 0, 0],
    15: [0, 2, 1, 0, 0, 0, 0, 0],
    16: [0, 2, 2, 0, 0, 0, 0, 0],
    17: [0, 2, 2, 1, 0, 0, 0, 0],
    18: [0, 2, 2, 1, 1, 0, 0, 0],
    19: [0, 3, 2, 2, 1, 0, 0, 0],
    20: [0, 3, 3, 2, 2, 0, 0, 0],
    21: [0, 3, 3, 3, 2, 1, 0, 0],
    22: [0, 3, 3, 3, 3, 2, 0, 0],
    23: [0, 4, 3, 3, 3, 2, 1, 0],
    24: [0, 4, 3, 3, 3, 3, 2, 0],
    25: [0, 4, 3, 3, 3, 3, 3, 1],
};
ARS.wisdomTable = {};
// Wisdom[abilityScore]={magic adj, spell bonuses, spell failure, spell imm., MAC base, PSP bonus }
ARS.wisdomTable['0'] = {
    0: [
        'ARS.abilityFields.wis.magic',
        'ARS.abilityFields.wis.bonus',
        'ARS.abilityFields.wis.failure',
        'ARS.abilityFields.wis.imm',
    ],
    1: [-3, 'None', 0, 0, 0, 0],
    2: [-3, 'None', 0, 0, 0, 0],
    3: [-3, 'None', 0, 0, 0, 0],
    4: [-2, 'None', 0, 0, 0, 0],
    5: [-1, 'None', 0, 0, 0, 0],
    6: [-1, 'None', 0, 0, 0, 0],
    7: [-1, 'None', 0, 0, 0, 0],
    8: [0, 'None', 0, 0, 0, 0],
    9: [0, 'None', 0, 0, 0, 0],
    10: [0, 'None', 0, 0, 0, 0],
    11: [0, 'None', 0, 0, 0, 0],
    12: [0, 'None', 0, 0, 0, 0],
    13: [0, '1x1st', 0, 0, 0, 0],
    14: [0, '2x1st', 0, 0, 0, 0],
    15: [1, '2x1st,1x2nd', 0, 0, 0, 0],
    16: [2, '2x1st,2x2nd', 0, 0, 0, 0],
    17: [3, 'Various', 0, 0, 0, 0],
    18: [4, 'Various', 0, 0, 0, 0],
    19: [5, 'Various', 0, 0, 0, 0],
    20: [5, 'Various', 0, 0, 0, 0],
    21: [5, 'Various', 0, 0, 0, 0],
    22: [5, 'Various', 0, 0, 0, 0],
    23: [5, 'Various', 0, 0, 0, 0],
    24: [5, 'Various', 0, 0, 0, 0],
    25: [5, 'Various', 0, 0, 0, 0],
    //-- deal with long string bonus for tooltip
    117: [3, 'Bonus Spells: 2x1st, 2x2nd, 1x3rd', 0, 0],
    118: [4, 'Bonus Spells: 2x1st, 2x2nd, 1x3rd, 1x4th', 0, 0],
    119: [5, 'Bonus Spells: 3x1st, 2x2nd, 1x3rd, 1x4th', 0, 0],
    120: [5, 'Bonus Spells: 3x1st, 2x2nd, 1x3rd, 1x4th', 0, 0],
    121: [5, 'Bonus Spells: 3x1st, 2x2nd, 1x3rd, 1x4th', 0, 0],
    122: [5, 'Bonus Spells: 3x1st, 2x2nd, 1x3rd, 1x4th', 0, 0],
    123: [5, 'Bonus Spells: 3x1st, 2x2nd, 1x3rd, 1x4th', 0, 0],
    124: [5, 'Bonus Spells: 3x1st, 2x2nd, 1x3rd, 1x4th', 0, 0],
    125: [5, 'Bonus Spells: 3x1st, 2x2nd, 1x3rd, 1x4th', 0, 0],
};
ARS.wisdomTable['1'] = {
    0: [
        'ARS.abilityFields.wis.magic',
        'ARS.abilityFields.wis.bonus',
        'ARS.abilityFields.wis.failure',
        'ARS.abilityFields.wis.imm',
    ],
    1: [-3, 'None', 50, 'None', 0, 0],
    2: [-3, 'None', 50, 'None', 0, 0],
    3: [-3, 'None', 50, 'None', 0, 0],
    4: [-2, 'None', 45, 'None', 0, 0],
    5: [-1, 'None', 40, 'None', 0, 0],
    6: [-1, 'None', 35, 'None', 0, 0],
    7: [-1, 'None', 30, 'None', 0, 0],
    8: [0, 'None', 25, 'None', 0, 0],
    9: [0, 'None', 20, 'None', 0, 0],
    10: [0, 'None', 15, 'None', 0, 0],
    11: [0, 'None', 10, 'None', 0, 0],
    12: [0, 'None', 5, 'None', 0, 0],
    13: [0, '1x1st', 0, 'None', 0, 0],
    14: [0, '2x1st', 0, 'None', 0, 0],
    15: [1, '2x1st,1x2nd', 0, 'None', 0, 0],
    16: [2, '2x1st,2x2nd', 0, 'None', 0, 0],
    17: [3, 'Various', 0, 'None', 0, 0],
    18: [4, 'Various', 0, 'None', 0, 0],
    19: [4, 'Various', 0, 'Various', 0, 0],
    20: [4, 'Various', 0, 'Various', 0, 0],
    21: [4, 'Various', 0, 'Various', 0, 0],
    22: [4, 'Various', 0, 'Various', 0, 0],
    23: [4, 'Various', 0, 'Various', 0, 0],
    24: [4, 'Various', 0, 'Various', 0, 0],
    25: [4, 'Various', 0, 'Various', 0, 0],
    //-- deal with long string bonus for tooltip
    117: [3, 'Bonus Spells: 2x1st, 2x2nd, 1x3rd', 0, 'None'],
    118: [4, 'Bonus Spells: 2x1st, 2x2nd, 1x3rd, 1x4th', 0, 'None'],
    119: [4, 'Bonus Spells: 3x1st, 2x2nd, 2x3rd, 1x4th', 0, 'Spells: cause fear,charm person, command, friends, hypnotism'],
    120: [
        4,
        'Bonus Spells: 3x1st, 3x2nd, 2x3rd, 2x4th',
        0,
        'Spells: cause fear,charm person, command, friends, hypnotism, forget, hold person, enfeeble, scare',
    ],
    121: [
        4,
        'Bonus Spells: 3x1st, 3x2nd, 3x3rd, 2x4th, 5th',
        0,
        'Spells: cause fear,charm person, command, friends, hypnotism, forget, hold person, enfeeble, scare, fear',
    ],
    122: [
        4,
        'Bonus Spells: 3x1st, 3x2nd, 3x3rd, 3x4th, 2x5th',
        0,
        'Spells: cause fear,charm person, command, friends, hypnotism, forget, hold person, enfeeble, scare, fear, charm monster, confusion, emotion, fumble, suggestion',
    ],
    123: [
        4,
        'Bonus Spells: 4x1st, 3x2nd, 3x3rd, 3x4th, 2x5th, 1x6th',
        0,
        'Spells: cause fear,charm person, command, friends, hypnotism, forget, hold person, enfeeble, scare, fear, charm monster, confusion, emotion, fumble, suggestion, chaos, feeblemind, hold monster,magic jar,quest',
    ],
    124: [
        4,
        'Bonus Spells: 4x1st, 3x2nd, 3x3rd, 3x4th, 3x5th, 2x6th',
        0,
        'Spells: cause fear,charm person, command, friends, hypnotism, forget, hold person, enfeeble, scare, fear, charm monster, confusion, emotion, fumble, suggestion, chaos, feeblemind, hold monster,magic jar,quest, geas, mass suggestion, rod of ruleship',
    ],
    125: [
        4,
        'Bonus Spells: 4x1st, 3x2nd, 3x3rd, 3x4th, 3x5th, 3x6th,1x7th',
        0,
        'Spells: cause fear,charm person, command, friends, hypnotism, forget, hold person, enfeeble, scare, fear, charm monster, confusion, emotion, fumble, suggestion, chaos, feeblemind, hold monster,magic jar,quest, geas, mass suggestion, rod of ruleship, antipathy/sympath, death spell,mass charm',
    ],
};
ARS.wisdomTable['2'] = {
    0: [
        'ARS.abilityFields.wis.magic',
        'ARS.abilityFields.wis.bonus',
        'ARS.abilityFields.wis.failure',
        'ARS.abilityFields.wis.imm',
        //MAC base?,
        //PSP bonus?,
    ],
    1: [-6, 'None', 80, 'None', 10, 0],
    2: [-4, 'None', 60, 'None', 10, 0],
    3: [-3, 'None', 50, 'None', 10, 0],
    4: [-2, 'None', 45, 'None', 10, 0],
    5: [-1, 'None', 40, 'None', 10, 0],
    6: [-1, 'None', 35, 'None', 10, 0],
    7: [-1, 'None', 30, 'None', 10, 0],
    8: [0, 'None', 25, 'None', 10, 0],
    9: [0, 'None', 20, 'None', 10, 0],
    10: [0, 'None', 15, 'None', 10, 0],
    11: [0, 'None', 10, 'None', 10, 0],
    12: [0, 'None', 5, 'None', 10, 0],
    13: [0, '1x1st', 0, 'None', 10, 0],
    14: [0, '2x1st', 0, 'None', 10, 0],
    15: [1, '2x1st,1x2nd', 0, 'None', 10, 0],
    16: [2, '2x1st,2x2nd', 0, 'None', 9, 1],
    17: [3, 'Various', 0, 'None', 8, 2],
    18: [4, 'Various', 0, 'None', 7, 3],
    19: [4, 'Various', 0, 'Various', 6, 4],
    20: [4, 'Various', 0, 'Various', 5, 5],
    21: [4, 'Various', 0, 'Various', 4, 6],
    22: [4, 'Various', 0, 'Various', 3, 7],
    23: [4, 'Various', 0, 'Various', 2, 8],
    24: [4, 'Various', 0, 'Various', 1, 9],
    25: [4, 'Various', 0, 'Various', 0, 10],
    //-- deal with long string bonus for tooltip
    117: [3, 'Bonus Spells: 2x1st, 2x2nd, 1x3rd', 0, 'None'],
    118: [4, 'Bonus Spells: 2x1st, 2x2nd, 1x3rd, 1x4th', 0, 'None'],
    119: [4, 'Bonus Spells: 3x1st, 2x2nd, 2x3rd, 1x4th', 0, 'Spells: cause fear,charm person, command, friends, hypnotism'],
    120: [
        4,
        'Bonus Spells: 3x1st, 3x2nd, 2x3rd, 2x4th',
        0,
        'Spells: cause fear,charm person, command, friends, hypnotism, forget, hold person, enfeeble, scare',
    ],
    121: [
        4,
        'Bonus Spells: 3x1st, 3x2nd, 3x3rd, 2x4th, 5th',
        0,
        'Spells: cause fear,charm person, command, friends, hypnotism, forget, hold person, enfeeble, scare, fear',
    ],
    122: [
        4,
        'Bonus Spells: 3x1st, 3x2nd, 3x3rd, 3x4th, 2x5th',
        0,
        'Spells: cause fear,charm person, command, friends, hypnotism, forget, hold person, enfeeble, scare, fear, charm monster, confusion, emotion, fumble, suggestion',
    ],
    123: [
        4,
        'Bonus Spells: 4x1st, 3x2nd, 3x3rd, 3x4th, 2x5th, 1x6th',
        0,
        'Spells: cause fear,charm person, command, friends, hypnotism, forget, hold person, enfeeble, scare, fear, charm monster, confusion, emotion, fumble, suggestion, chaos, feeblemind, hold monster,magic jar,quest',
    ],
    124: [
        4,
        'Bonus Spells: 4x1st, 3x2nd, 3x3rd, 3x4th, 3x5th, 2x6th',
        0,
        'Spells: cause fear,charm person, command, friends, hypnotism, forget, hold person, enfeeble, scare, fear, charm monster, confusion, emotion, fumble, suggestion, chaos, feeblemind, hold monster,magic jar,quest, geas, mass suggestion, rod of ruleship',
    ],
    125: [
        4,
        'Bonus Spells: 4x1st, 3x2nd, 3x3rd, 3x4th, 3x5th, 3x6th,1x7th',
        0,
        'Spells: cause fear,charm person, command, friends, hypnotism, forget, hold person, enfeeble, scare, fear, charm monster, confusion, emotion, fumble, suggestion, chaos, feeblemind, hold monster,magic jar,quest, geas, mass suggestion, rod of ruleship, antipathy/sympath, death spell,mass charm',
    ],
};
ARS.constitutionTable = {};
// Constitution[abilityScore]={hp, system shock, resurrection survivial, poison save, regeneration, psp bonus}
ARS.constitutionTable['0'] = {
    0: [
        'ARS.abilityFields.con.hp',
        'ARS.abilityFields.con.shock',
        'ARS.abilityFields.con.survival',
        'ARS.abilityFields.con.poison',
        'ARS.abilityFields.con.regen',
    ],
    1: [[-2], 35, 40, 0, 0, 0],
    2: [[-2], 35, 40, 0, 0, 0],
    3: [[-2], 35, 40, 0, 0, 0],
    4: [[-1], 40, 45, 0, 0, 0],
    5: [[-1], 45, 50, 0, 0, 0],
    6: [[-1], 50, 55, 0, 0, 0],
    7: [[0], 55, 60, 0, 0, 0],
    8: [[0], 60, 65, 0, 0, 0],
    9: [[0], 65, 70, 0, 0, 0],
    10: [[0], 70, 75, 0, 0, 0],
    11: [[0], 75, 80, 0, 0, 0],
    12: [[0], 80, 85, 0, 0, 0],
    13: [[0], 85, 90, 0, 0, 0],
    14: [[0], 88, 92, 0, 0, 0],
    15: [[1], 91, 94, 0, 0, 0],
    16: [[2], 95, 96, 0, 0, 1],
    17: [[2, 3], 97, 98, 0, 0, 0],
    18: [[2, 4], 99, 100, 0, 0, 0],
    19: [[2, 5], 99, 100, 0, 0, 0],
    20: [[2, 5], 99, 100, 0, 0, 0],
    21: [[2, 5], 99, 100, 0, 0, 0],
    22: [[2, 5], 99, 100, 0, 0, 0],
    23: [[2, 5], 99, 100, 0, 0, 0],
    24: [[2, 5], 99, 100, 0, 0, 0],
    25: [[2, 5], 99, 100, 0, 0, 0],
};
// Constitution[abilityScore]={hp, system shock, resurrection survivial, poison save, regeneration, psp bonus}
ARS.constitutionTable['1'] = {
    0: [
        'ARS.abilityFields.con.hp',
        'ARS.abilityFields.con.shock',
        'ARS.abilityFields.con.survival',
        'ARS.abilityFields.con.poison',
        'ARS.abilityFields.con.regen',
    ],
    1: [[-2], 35, 40, 0, 'None', 0],
    2: [[-2], 35, 40, 0, 'None', 0],
    3: [[-2], 35, 40, 0, 'None', 0],
    4: [[-1], 40, 45, 0, 'None', 0],
    5: [[-1], 45, 50, 0, 'None', 0],
    6: [[-1], 50, 55, 0, 'None', 0],
    7: [[0], 55, 60, 0, 'None', 0],
    8: [[0], 60, 65, 0, 'None', 0],
    9: [[0], 65, 70, 0, 'None', 0],
    10: [[0], 70, 75, 0, 'None', 0],
    11: [[0], 75, 80, 0, 'None', 0],
    12: [[0], 80, 85, 0, 'None', 0],
    13: [[0], 85, 90, 0, 'None', 0],
    14: [[0], 88, 92, 0, 'None', 0],
    15: [[1], 91, 94, 0, 'None', 0],
    16: [[2], 95, 96, 0, 'None', 0],
    17: [[2, 3], 97, 98, 0, 'None', 0],
    18: [[2, 4], 99, 100, 0, 'None', 0],
    19: [[2, 5], 99, 100, 1, 'None', 0],
    20: [[2, 5], 99, 100, 1, '1/6 turns', 0],
    21: [[2, 6], 99, 100, 2, '1/5 turns', 0],
    22: [[2, 6], 99, 100, 2, '1/4 turns', 0],
    23: [[2, 6], 99, 100, 3, '1/3 turns', 0],
    24: [[2, 7], 99, 100, 3, '1/2', 0],
    25: [[2, 7], 100, 100, 4, '1 turn', 0],
};
// Constitution[abilityScore]={hp, system shock, resurrection survivial, poison save, regeneration, psp bonus}
ARS.constitutionTable['2'] = {
    0: [
        'ARS.abilityFields.con.hp',
        'ARS.abilityFields.con.shock',
        'ARS.abilityFields.con.survival',
        'ARS.abilityFields.con.poison',
        'ARS.abilityFields.con.regen',
    ],
    1: [[-3], 25, 30, -2, 'None', 0],
    2: [[-2], 30, 35, -1, 'None', 0],
    3: [[-2], 35, 40, 0, 'None', 0],
    4: [[-1], 40, 45, 0, 'None', 0],
    5: [[-1], 45, 50, 0, 'None', 0],
    6: [[-1], 50, 55, 0, 'None', 0],
    7: [[0], 55, 60, 0, 'None', 0],
    8: [[0], 60, 65, 0, 'None', 0],
    9: [[0], 65, 70, 0, 'None', 0],
    10: [[0], 70, 75, 0, 'None', 0],
    11: [[0], 75, 80, 0, 'None', 0],
    12: [[0], 80, 85, 0, 'None', 0],
    13: [[0], 85, 90, 0, 'None', 0],
    14: [[0], 88, 92, 0, 'None', 0],
    15: [[1], 90, 94, 0, 'None', 0],
    16: [[2], 95, 96, 0, 'None', 1],
    17: [[2, 3], 97, 98, 0, 'None', 2],
    18: [[2, 4], 99, 100, 0, 'None', 3],
    19: [[2, 5], 99, 100, 1, 'None', 4],
    20: [[2, 5], 99, 100, 1, '1/6 turns', 5],
    21: [[2, 6], 99, 100, 2, '1/5 turns', 6],
    22: [[2, 6], 99, 100, 2, '1/4 turns', 7],
    23: [[2, 6], 99, 100, 3, '1/3 turns', 8],
    24: [[2, 7], 99, 100, 3, '1/2', 9],
    25: [[2, 7], 100, 100, 4, '1 turn', 10],
};
ARS.charismaTable = {};
// Charisma[abilityScore]={max hench,loyalty base, reaction adj}
ARS.charismaTable['0'] = {
    0: ['ARS.abilityFields.cha.max', 'ARS.abilityFields.cha.loyalty', 'ARS.abilityFields.cha.reaction'],
    1: [1, -30, -25],
    2: [1, -30, -25],
    3: [1, -30, -25],
    4: [1, -25, -20],
    5: [2, -20, -15],
    6: [2, -15, -10],
    7: [3, -10, -5],
    8: [3, -5, 0],
    9: [4, 0, 0],
    10: [4, 0, 0],
    11: [4, 0, 0],
    12: [5, 0, 0],
    13: [5, 0, 5],
    14: [6, 5, 10],
    15: [7, 15, 15],
    16: [8, 20, 25],
    17: [10, 30, 30],
    18: [15, 40, 35],
    19: [20, 50, 40],
    20: [20, 50, 40],
    21: [20, 50, 40],
    22: [20, 50, 40],
    23: [20, 50, 40],
    24: [20, 50, 40],
    25: [20, 50, 40],
};

ARS.charismaTable['1'] = {
    0: ['ARS.abilityFields.cha.max', 'ARS.abilityFields.cha.loyalty', 'ARS.abilityFields.cha.reaction'],
    1: [1, -30, -25],
    2: [1, -30, -25],
    3: [1, -30, -25],
    4: [1, -25, -20],
    5: [2, -20, -15],
    6: [2, -15, -10],
    7: [3, -10, -5],
    8: [3, -5, 0],
    9: [4, 0, 0],
    10: [4, 0, 0],
    11: [4, 0, 0],
    12: [5, 0, 0],
    13: [5, 0, 5],
    14: [6, 5, 10],
    15: [7, 15, 15],
    16: [8, 20, 25],
    17: [10, 30, 30],
    18: [15, 40, 35],
    19: [20, 50, 40],
    20: [20, 50, 40],
    21: [20, 50, 40],
    22: [20, 50, 40],
    23: [20, 50, 40],
    24: [20, 50, 40],
    25: [20, 50, 40],
};

ARS.charismaTable['2'] = {
    0: ['ARS.abilityFields.cha.max', 'ARS.abilityFields.cha.loyalty', 'ARS.abilityFields.cha.reaction'],
    1: [0, -8, -7],
    2: [1, -7, -6],
    3: [1, -6, -5],
    4: [1, -5, -4],
    5: [2, -4, -3],
    6: [2, -3, -2],
    7: [3, -2, -1],
    8: [3, -1, 0],
    9: [4, 0, 0],
    10: [4, 0, 0],
    11: [4, 0, 0],
    12: [5, 0, 0],
    13: [5, 0, 1],
    14: [6, 1, 2],
    15: [7, 3, 3],
    16: [8, 4, 5],
    17: [10, 6, 6],
    18: [15, 8, 7],
    19: [20, 10, 8],
    20: [25, 12, 9],
    21: [30, 14, 10],
    22: [35, 16, 1],
    23: [40, 18, 12],
    24: [45, 20, 13],
    25: [50, 20, 14],
};

ARS.intelligenceTable = {};
// Intelligence[abilityScore]={# languages, spelllevel, learn spell, max spells, illusion immunity, MAC mod, PSP Bonus,MTHACO bonus}
ARS.intelligenceTable['0'] = {
    0: [
        'ARS.abilityFields.int.languages',
        'ARS.abilityFields.int.level',
        'ARS.abilityFields.int.chance',
        'ARS.abilityFields.int.max',
        'ARS.abilityFields.int.imm',
    ],
    1: [0, 0, 0, 0, 0, 0, 0, 0],
    2: [0, 0, 0, 0, 0, 0, 0, 0],
    3: [0, 0, 0, 0, 0, 0, 0, 0],
    4: [0, 0, 0, 0, 0, 0, 0, 0],
    5: [0, 0, 0, 0, 0, 0, 0, 0],
    6: [0, 0, 0, 0, 0, 0, 0, 0],
    7: [0, 0, 0, 0, 0, 0, 0, 0],
    8: [1, 0, 0, 0, 0, 0, 0, 0],
    9: [1, 0, 35, 6, 0, 0, 0, 0],
    10: [2, 0, 45, 7, 0, 0, 0, 0],
    11: [2, 0, 45, 7, 0, 0, 0, 0],
    12: [3, 0, 45, 7, 0, 0, 0, 0],
    13: [3, 0, 55, 9, 0, 0, 0, 0],
    14: [4, 0, 55, 9, 0, 0, 0, 0],
    15: [4, 0, 65, 11, 0, 0, 0, 0],
    16: [5, 0, 65, 11, 0, 0, 0, 0],
    17: [6, 0, 75, 14, 0, 0, 0, 0],
    18: [7, 0, 85, 18, 0, 0, 0, 0],
    19: [8, 0, 90, 22, 0, 0, 0, 0],
    20: [8, 0, 90, 22, 0, 0, 0, 0],
    21: [8, 0, 90, 22, 0, 0, 0, 0],
    22: [8, 0, 90, 22, 0, 0, 0, 0],
    23: [8, 0, 90, 22, 0, 0, 0, 0],
    24: [8, 0, 90, 22, 0, 0, 0, 0],
    25: [8, 0, 90, 22, 0, 0, 0, 0],
    //-- these have such long values we stuff them into tooltips instead
    119: [0, 0, 0, '', ''],
    120: [0, 0, 0, '', ''],
    121: [0, 0, 0, '', ''],
    122: [0, 0, 0, '', ''],
    123: [0, 0, 0, '', ''],
    124: [0, 0, 0, '', ''],
    125: [0, 0, 0, '', ''],
};
// Intelligence[abilityScore]={# languages, spelllevel, learn spell, max spells, illusion immunity, MAC mod, PSP Bonus,MTHACO bonus}
ARS.intelligenceTable['1'] = {
    0: [
        'ARS.abilityFields.int.languages',
        'ARS.abilityFields.int.level',
        'ARS.abilityFields.int.chance',
        'ARS.abilityFields.int.max',
        'ARS.abilityFields.int.imm',
    ],
    1: [0, 0, 0, 0, 'None', 0, 0, 0],
    2: [1, 0, 0, 0, 'None', 0, 0, 0],
    3: [1, 0, 0, 0, 'None', 0, 0, 0],
    4: [1, 0, 0, 0, 'None', 0, 0, 0],
    5: [1, 0, 0, 0, 'None', 0, 0, 0],
    6: [1, 0, 0, 0, 'None', 0, 0, 0],
    7: [1, 0, 0, 0, 'None', 0, 0, 0],
    8: [1, 0, 0, 0, 'None', 0, 0, 0],
    9: [1, 4, 35, 6, 'None', 0, 0, 0],
    10: [2, 5, 40, 7, 'None', 0, 0, 0],
    11: [2, 5, 45, 7, 'None', 0, 0, 0],
    12: [3, 6, 50, 7, 'None', 0, 0, 0],
    13: [3, 6, 55, 9, 'None', 0, 0, 0],
    14: [4, 7, 60, 9, 'None', 0, 0, 0],
    15: [4, 7, 65, 11, 'None', 0, 0, 0],
    16: [5, 8, 70, 11, 'None', 0, 0, 0],
    17: [6, 8, 75, 14, 'None', 0, 0, 0],
    18: [7, 9, 85, 18, 'None', 0, 0, 0],
    19: [8, 9, 95, 'All', '1st', 0, 0, 0],
    20: [9, 9, 96, 'All', '1,2', 0, 0, 0],
    21: [10, 9, 97, 'All', '1,2,3', 0, 0, 0],
    22: [11, 9, 98, 'All', '1,2,3,4', 0, 0, 0],
    23: [12, 9, 99, 'All', '1,2,3,4,5', 0, 0, 0],
    24: [15, 9, 100, 'All', '1,2,3,4,5,6', 0, 0, 0],
    25: [20, 9, 100, 'All', '1,2,3,4,5,6,7', 0, 0, 0],
    //-- these have such long values we stuff them into tooltips instead
    119: [8, 9, 95, 'All', 'Level: 1st'],
    120: [9, 9, 96, 'All', 'Level: 1st, 2nd'],
    121: [10, 9, 97, 'All', 'Level: 1st, 2nd, 3rd'],
    122: [11, 9, 98, 'All', 'Level: 1st, 2nd, 3rd, 4th'],
    123: [12, 9, 99, 'All', 'Level: 1st, 2nd, 3rd, 4th, 5th'],
    124: [15, 9, 100, 'All', 'Level: 1st, 2nd, 3rd, 4th, 5th, 6th'],
    125: [20, 9, 100, 'All', 'Level: 1st, 2nd, 3rd, 4th, 5th, 6th, 7th'],
};
// Intelligence[abilityScore]={# languages, spelllevel, learn spell, max spells, illusion immunity, MAC mod, PSP Bonus,MTHACO bonus}
ARS.intelligenceTable['2'] = {
    0: [
        'ARS.abilityFields.int.languages',
        'ARS.abilityFields.int.level',
        'ARS.abilityFields.int.chance',
        'ARS.abilityFields.int.max',
        'ARS.abilityFields.int.imm',
    ],
    1: [0, 0, 0, 0, 'None', 0, 0, 0],
    2: [1, 0, 0, 0, 'None', 0, 0, 0],
    3: [1, 0, 0, 0, 'None', 0, 0, 0],
    4: [1, 0, 0, 0, 'None', 0, 0, 0],
    5: [1, 0, 0, 0, 'None', 0, 0, 0],
    6: [1, 0, 0, 0, 'None', 0, 0, 0],
    7: [1, 0, 0, 0, 'None', 0, 0, 0],
    8: [1, 0, 0, 0, 'None', 0, 0, 0],
    9: [2, 4, 35, 6, 'None', 0, 0, 0],
    10: [2, 5, 40, 7, 'None', 0, 0, 0],
    11: [2, 5, 45, 7, 'None', 0, 0, 0],
    12: [3, 6, 50, 7, 'None', 0, 0, 0],
    13: [3, 6, 55, 9, 'None', 0, 0, 0],
    14: [4, 7, 60, 9, 'None', 0, 0, 0],
    15: [4, 7, 65, 11, 'None', 0, 0, 0],
    16: [5, 8, 70, 11, 'None', 1, 1, 1],
    17: [6, 8, 75, 14, 'None', 1, 2, 1],
    18: [7, 9, 85, 18, 'None', 2, 3, 2],
    19: [8, 9, 95, 'All', '1st', 2, 4, 2],
    20: [9, 9, 96, 'All', '1,2', 3, 5, 3],
    21: [10, 9, 97, 'All', '1,2,3', 3, 6, 3],
    22: [11, 9, 98, 'All', '1,2,3,4', 3, 7, 3],
    23: [12, 9, 99, 'All', '1,2,3,4,5', 4, 8, 4],
    24: [15, 9, 100, 'All', '1,2,3,4,5,6', 4, 9, 4],
    25: [20, 9, 100, 'All', '1,2,3,4,5,6,7', 4, 10, 4],
    //-- these have such long values we stuff them into tooltips instead
    119: [8, 9, 95, 'All', 'Level: 1st'],
    120: [9, 9, 96, 'All', 'Level: 1st, 2nd'],
    121: [10, 9, 97, 'All', 'Level: 1st, 2nd, 3rd'],
    122: [11, 9, 98, 'All', 'Level: 1st, 2nd, 3rd, 4th'],
    123: [12, 9, 99, 'All', 'Level: 1st, 2nd, 3rd, 4th, 5th'],
    124: [15, 9, 100, 'All', 'Level: 1st, 2nd, 3rd, 4th, 5th, 6th'],
    125: [20, 9, 100, 'All', 'Level: 1st, 2nd, 3rd, 4th, 5th, 6th, 7th'],
};

ARS.saveArrayMap = {
    paralyzation: 0,
    poison: 0,
    death: 0,

    rod: 1,
    staff: 1,
    wand: 1,

    petrification: 2,
    polymorph: 2,

    breath: 3,
    spell: 4,
};
/**
 * Check a action/spell properties and if it has any of the listed comma delimited 'property'
 * values then we include the formula in the save test
 *
 * only works with automated saves, not manual saves
 */
ARS.saveProperties = {
    mental: {
        property: 'mental',
        formula: '(@abilities.wis.magic)',
    },
    dodge: {
        property: 'dodge',
        formula: '(-(@abilities.dex.defensive))',
    },
};
// para/poison/Death, Rod/staff/wand, petri/Poly, Breath, Spell
ARS.npcSaveTable = {
    // ARS
    0: {
        0: [16, 18, 17, 20, 19],
        1: [14, 16, 15, 17, 17],
        2: [14, 16, 15, 17, 17],
        3: [13, 15, 14, 16, 16],
        4: [13, 15, 14, 16, 16],
        5: [11, 13, 12, 13, 14],
        6: [11, 13, 12, 13, 14],
        7: [10, 12, 11, 12, 13],
        8: [10, 12, 11, 12, 13],
        9: [8, 10, 9, 9, 11],
        10: [8, 10, 9, 9, 11],
        11: [7, 9, 8, 8, 10],
        12: [7, 9, 8, 8, 10],
        13: [5, 7, 6, 5, 8],
        14: [5, 7, 6, 5, 8],
        15: [4, 6, 5, 4, 7],
        16: [4, 6, 5, 4, 7],
        17: [3, 5, 4, 4, 6],
        18: [3, 5, 4, 4, 6],
        19: [2, 4, 3, 3, 5],
        20: [2, 4, 3, 3, 5],
        21: [2, 4, 3, 3, 5],
    },
    // variant 1
    1: {
        0: [16, 18, 17, 20, 19],
        1: [14, 16, 15, 17, 17],
        2: [14, 16, 15, 17, 17],
        3: [13, 15, 14, 16, 16],
        4: [13, 15, 14, 16, 16],
        5: [11, 13, 12, 13, 14],
        6: [11, 13, 12, 13, 14],
        7: [10, 12, 11, 12, 13],
        8: [10, 12, 11, 12, 13],
        9: [8, 10, 9, 9, 11],
        10: [8, 10, 9, 9, 11],
        11: [7, 9, 8, 8, 10],
        12: [7, 9, 8, 8, 10],
        13: [5, 7, 6, 5, 8],
        14: [5, 7, 6, 5, 8],
        15: [4, 6, 5, 4, 7],
        16: [4, 6, 5, 4, 7],
        17: [3, 5, 4, 4, 6],
        18: [3, 5, 4, 4, 6],
        19: [3, 5, 4, 4, 6],
        20: [3, 5, 4, 4, 6],
        21: [3, 5, 4, 4, 6],
    },
    // variant 2
    2: {
        0: [16, 18, 17, 20, 19],
        1: [14, 16, 15, 17, 17],
        2: [14, 16, 15, 17, 17],
        3: [13, 15, 14, 16, 16],
        4: [13, 15, 14, 16, 16],
        5: [11, 13, 12, 13, 14],
        6: [11, 13, 12, 13, 14],
        7: [10, 12, 11, 12, 13],
        8: [10, 12, 11, 12, 13],
        9: [8, 10, 9, 9, 11],
        10: [8, 10, 9, 9, 11],
        11: [7, 9, 8, 8, 10],
        12: [7, 9, 8, 8, 10],
        13: [5, 7, 6, 5, 8],
        14: [5, 7, 6, 5, 8],
        15: [4, 6, 5, 4, 7],
        16: [4, 6, 5, 4, 7],
        17: [3, 5, 4, 4, 6],
        18: [3, 5, 4, 4, 6],
        19: [3, 5, 4, 4, 6],
        20: [3, 5, 4, 4, 6],
        21: [3, 5, 4, 4, 6],
    },
};

/**
 * Index of items in itemSaves table 0-10
 */
ARS.itemSaveTypes = {
    0: [
        'Acid',
        'Blow, Crushing',
        'Blow, Normal',
        'Disintegration',
        'Fall',
        'Fireball (or breath)',
        'Fire, magical',
        'Fire, normal (oil)',
        'Frost, Magical',
        'Lightning Bolt',
        'Electrical Discharge/Current',
    ],
    1: [
        'Acid',
        'Blow, Crushing',
        'Blow, Normal',
        'Disintegration',
        'Fall',
        'Fireball (or breath)',
        'Fire, magical',
        'Fire, normal (oil)',
        'Frost, Magical',
        'Lightning Bolt',
        'Electrical Discharge/Current',
    ],
    2: ['Acid', 'Crushing, Blow', 'Disintegration', 'Fall', 'Magical Fire', 'Normal Fire', 'Cold', 'Lightning', 'Electricity'],
};

/**
 * Saves for specific item material, referenced by itemSaveTypes index
 */
ARS.itemSaveChoices = {
    bone_ivory: 'Bone or Ivory',
    pottery_ceramic: 'Ceramic or Pottery',
    cloth: 'Cloth',
    crystal_vial: 'Crystal or Vial',
    glass: 'Glass',
    mirror: 'Mirror',

    leather_book: 'Leather or Book',
    oils: 'Oils',
    potions: 'Potions or Liquid',

    // metal: [13, 7, 17, 3, 6, 2, 2, 12, 2],
    metal: 'Metal',
    metal_soft: 'Metal, Soft',

    paper: 'Paper or Parchment',
    rock_gem: 'Stone, Rock or Gem',

    rope: 'Rope',
    wood_thick: 'Wood, Thick',
    wood_thin: 'Wood, Thin',
};

ARS.itemSaves = {
    0: {
        // [acid, blow-crushing, blow-normal, disintegrate, fall, fireball, fire-magical, fire-normal, frost, lightning, electricity]
        bone_ivory: [11, 16, 10, 20, 6, 17, 9, 3, 2, 8, 1],
        pottery_ceramic: [4, 18, 12, 19, 11, 5, 3, 2, 4, 2, 1],
        cloth: [12, 6, 3, 20, 2, 20, 16, 13, 1, 18, 1],
        crystal_vial: [6, 19, 14, 20, 13, 10, 6, 3, 7, 15, 5],
        glass: [5, 20, 15, 20, 14, 11, 7, 4, 6, 17, 1],
        mirror: [12, 20, 15, 20, 13, 14, 9, 5, 6, 18, 1],

        leather_book: [10, 4, 2, 20, 1, 13, 6, 4, 3, 13, 1],
        // liquid: [15, 0, 0, 20, 0, 15, 14, 13, 12, 18, 15],
        oils: [15, 0, 0, 20, 0, 15, 14, 13, 12, 18, 15],
        potions: [15, 0, 0, 20, 0, 15, 14, 13, 12, 18, 15],

        metal: [7, 6, 2, 17, 2, 6, 2, 1, 1, 11, 1],
        metal_soft: [13, 14, 9, 19, 4, 18, 13, 5, 1, 16, 1],

        paper: [16, 11, 6, 20, 0, 25, 21, 18, 2, 20, 1],
        rock_gem: [3, 17, 7, 18, 4, 7, 3, 2, 1, 14, 2],

        rope: [8, 10, 3, 19, 1, 11, 7, 5, 1, 12, 1],
        wood_thin: [9, 13, 6, 20, 2, 15, 11, 9, 1, 10, 1],
        wood_thick: [8, 10, 3, 19, 1, 11, 7, 5, 1, 12, 1],
    },
    1: {
        // [acid, blow-crushing, blow-normal, disintegrate, fall, fireball, fire-magical, fire-normal, frost, lightning, electricity]
        bone_ivory: [11, 16, 10, 20, 6, 17, 9, 3, 2, 8, 1],
        pottery_ceramic: [4, 18, 12, 19, 11, 5, 3, 2, 4, 2, 1],
        cloth: [12, 6, 3, 20, 2, 20, 16, 13, 1, 18, 1],
        crystal_vial: [6, 19, 14, 20, 13, 10, 6, 3, 7, 15, 5],
        glass: [5, 20, 15, 20, 14, 11, 7, 4, 6, 17, 1],
        mirror: [12, 20, 15, 20, 13, 14, 9, 5, 6, 18, 1],

        leather_book: [10, 4, 2, 20, 1, 13, 6, 4, 3, 13, 1],
        // liquid: [15, 0, 0, 20, 0, 15, 14, 13, 12, 18, 15],
        oils: [15, 0, 0, 20, 0, 15, 14, 13, 12, 18, 15],
        potions: [15, 0, 0, 20, 0, 15, 14, 13, 12, 18, 15],

        metal: [7, 6, 2, 17, 2, 6, 2, 1, 1, 11, 1],
        metal_soft: [13, 14, 9, 19, 4, 18, 13, 5, 1, 16, 1],

        paper: [16, 11, 6, 20, 0, 25, 21, 18, 2, 20, 1],
        rock_gem: [3, 17, 7, 18, 4, 7, 3, 2, 1, 14, 2],

        rope: [8, 10, 3, 19, 1, 11, 7, 5, 1, 12, 1],
        wood_thin: [9, 13, 6, 20, 2, 15, 11, 9, 1, 10, 1],
        wood_thick: [8, 10, 3, 19, 1, 11, 7, 5, 1, 12, 1],

        // pottery: [4, 18, 12, 19, 11, 5, 3, 2, 4, 2, 1],
        // potions: [],
        // oils: [],
    },

    2: {
        // [Acid, Crushing Blow, Disintegration, Fall, Fire-Magical, Fire-Normal, Cold, Lightning, Electricity]
        //
        bone_ivory: [11, 16, 19, 6, 9, 3, 2, 8, 2],
        pottery_ceramic: [4, 18, 19, 11, 3, 2, 4, 2, 2],
        cloth: [12, 0, 19, 0, 16, 13, 2, 18, 2],
        crystal_vial: [3, 17, 18, 8, 3, 2, 2, 14, 2],
        glass: [5, 20, 19, 14, 7, 4, 6, 17, 2],
        mirror: [5, 20, 19, 14, 7, 4, 6, 17, 2],

        leather_book: [10, 3, 19, 2, 6, 4, 3, 13, 2],
        oils: [16, 0, 19, 0, 19, 17, 5, 19, 16],
        potions: [15, 0, 19, 0, 17, 4, 13, 18, 15],

        // metal: [13, 7, 17, 3, 6, 2, 2, 12, 2],
        metal: [13, 7, 17, 3, 6, 2, 2, 12, 2],
        metal_soft: [13, 7, 17, 3, 6, 2, 2, 12, 2],

        paper: [16, 7, 19, 0, 19, 19, 2, 19, 2],
        rock_gem: [3, 17, 18, 8, 3, 2, 2, 14, 2],

        rope: [12, 2, 19, 0, 10, 6, 2, 12, 2],
        wood_thick: [8, 10, 19, 2, 7, 5, 2, 9, 2],
        wood_thin: [9, 13, 19, 2, 11, 9, 2, 10, 2],
    },
};

// v2 thaco table
ARS.thaco = {
    monster: {
        0: 20,
        1: 19,
        2: 19,
        3: 17,
        4: 17,
        5: 15,
        6: 15,
        7: 13,
        8: 13,
        9: 11,
        10: 11,
        11: 9,
        12: 9,
        13: 7,
        14: 7,
        15: 5,
        16: 5,
        17: 3,
        18: 3,
        19: 1,
        20: 1,
        21: 1,
    },
};

//To hit matrix
ARS.matrix = {
    // OSRIC
    0: {
        fighter: {
            //                             AC Hit
            //level [-10,-9,-8.-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10]
            0: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            1: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            2: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            3: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            4: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            5: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            6: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            7: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            8: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            9: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            10: [20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
            11: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            12: [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
            13: [18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2],
            14: [17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3],
            15: [16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4],
            16: [15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5],
            17: [14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6],
            18: [13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7],
            19: [12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8],
            20: [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9],
        },
        assassin: {
            0: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            1: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            2: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            3: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            4: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            5: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            6: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            7: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            8: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            9: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            10: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            11: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            12: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            13: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            14: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            15: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            16: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            17: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            18: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            19: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            20: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
        },
        cleric: {
            0: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            1: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            2: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            3: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            4: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            5: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            6: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            7: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            8: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            9: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            10: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            11: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            12: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            13: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            14: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            15: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            16: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            17: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            18: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            19: [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
            20: [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
        },
        druid: {
            0: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            1: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            2: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            3: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            4: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            5: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            6: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            7: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            8: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            9: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            10: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            11: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            12: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            13: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            14: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            15: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            16: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            17: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            18: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            19: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            20: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
        },
        illusionist: {
            0: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            1: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            2: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            3: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            4: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            5: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            6: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            7: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            8: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            9: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            10: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            11: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            12: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            13: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            14: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            15: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            16: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            17: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            18: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            19: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            20: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            21: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
        },
        'magic-user': {
            0: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            1: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            2: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            3: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            4: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            5: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            6: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            7: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            8: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            9: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            10: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            11: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            12: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            13: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            14: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            15: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            16: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            17: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            18: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            19: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            20: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            21: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
        },
        paladin: {
            0: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            1: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            2: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            3: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            4: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            5: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            6: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            7: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            8: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            9: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            10: [20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
            11: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            12: [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
            13: [18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2],
            14: [17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3],
            15: [16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4],
            16: [15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5],
            17: [14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6],
            18: [13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7],
            19: [12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8],
            20: [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9],
        },
        ranger: {
            0: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            1: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            2: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            3: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            4: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            5: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            6: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            7: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            8: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            9: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            10: [20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
            11: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            12: [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
            13: [18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2],
            14: [17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3],
            15: [16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4],
            16: [15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5],
            17: [14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6],
            18: [13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7],
            19: [12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8],
            20: [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9],
        },
        thief: {
            0: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            1: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            2: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            3: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            4: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            5: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            6: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            7: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            8: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            9: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            10: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            11: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            12: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            13: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            14: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            15: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            16: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            17: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            18: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            19: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            20: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            21: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
        },
    },
    1: {
        monster: {
            //                             AC Hit
            //level [-10,-9,-8.-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10]
            0: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            // 1-1: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            1: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            // 1+: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            2: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            3: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            4: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            5: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            6: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            7: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            8: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            9: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            10: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            11: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            12: [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
            13: [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
            14: [18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2],
            15: [18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2],
            16: [17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3],
            17: [17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3],
            18: [15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5],
            19: [15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5],
            20: [14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6],
            21: [14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6],
            22: [13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7],
            23: [13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7],
            24: [12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8],
            25: [12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8],
            26: [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9],
        },
        fighter: {
            //                             AC Hit
            //level [-10,-9,-8.-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10]
            0: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            1: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            2: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            3: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            4: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            5: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            6: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            7: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            8: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            9: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            10: [20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
            11: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            12: [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
            13: [18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2],
            14: [17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3],
            15: [16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4],
            16: [15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5],
            17: [14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6],
            18: [13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7],
            19: [12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8],
            20: [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9],
        },
        assassin: {
            0: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            1: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            2: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            3: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            4: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            5: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            6: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            7: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            8: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            9: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            10: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            11: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            12: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            13: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            14: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            15: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            16: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            17: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            18: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            19: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            20: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
        },
        cleric: {
            0: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            1: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            2: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            3: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            4: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            5: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            6: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            7: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            8: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            9: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            10: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            11: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            12: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            13: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            14: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            15: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            16: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            17: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            18: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            19: [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
            20: [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
        },
        druid: {
            0: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            1: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            2: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            3: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            4: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            5: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            6: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            7: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            8: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            9: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            10: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            11: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            12: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            13: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            14: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            15: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            16: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            17: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            18: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            19: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            20: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
        },
        illusionist: {
            0: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            1: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            2: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            3: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            4: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            5: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            6: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            7: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            8: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            9: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            10: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            11: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            12: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            13: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            14: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            15: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            16: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            17: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            18: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            19: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            20: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            21: [20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
        },
        'magic-user': {
            0: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            1: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            2: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            3: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            4: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            5: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            6: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            7: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            8: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            9: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            10: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            11: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            12: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            13: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            14: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            15: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            16: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            17: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            18: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            19: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            20: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            21: [20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
        },

        paladin: {
            0: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            1: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            2: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            3: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            4: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            5: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            6: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            7: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            8: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            9: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            10: [20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
            11: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            12: [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
            13: [18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2],
            14: [17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3],
            15: [16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4],
            16: [15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5],
            17: [14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6],
            18: [13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7],
            19: [12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8],
            20: [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9],
        },
        ranger: {
            0: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            1: [25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10],
            2: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            3: [23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8],
            4: [22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7],
            5: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            6: [20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5],
            7: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            8: [20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3],
            9: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            10: [20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
            11: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
            12: [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
            13: [18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2],
            14: [17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3],
            15: [16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4],
            16: [15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5],
            17: [14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6],
            18: [13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7],
            19: [12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8],
            20: [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9],
        },
        thief: {
            0: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            1: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            2: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            3: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            4: [26, 25, 24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11],
            5: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            6: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            7: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            8: [24, 23, 22, 21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9],
            9: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            10: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            11: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            12: [21, 20, 20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6],
            13: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            14: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            15: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            16: [20, 20, 20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4],
            17: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            18: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            19: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            20: [20, 20, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
            21: [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
        },
    },
};

ARS.matrixIds = {
    0: {
        fighter: 'fighter',
        assassin: 'assassin',
        cleric: 'cleric',
        druid: 'druid',
        illusionist: 'illusionist',
        'magic-user': 'magic-user',
        paladin: 'paladin',
        ranger: 'ranger',
        thief: 'thief',
    },
    1: {
        monster: 'monster',
        fighter: 'fighter',
        assassin: 'assassin',
        cleric: 'cleric',
        druid: 'druid',
        illusionist: 'illusionist',
        'magic-user': 'magic-user',
        paladin: 'paladin',
        ranger: 'ranger',
        thief: 'thief',
    },
};
ARS.currencyType = ['cp', 'sp', 'ep', 'gp', 'pp'];

// These values are a copper base value.
// // game.ars.config.settings.systemVariant
ARS.currencyValue = {
    0: {
        cp: 1,
        sp: 10,
        ep: 50,
        gp: 100,
        pp: 500,
    },
    1: {
        cp: 1,
        sp: 10,
        ep: 100,
        gp: 200,
        pp: 1000,
    },
    2: {
        cp: 1,
        sp: 10,
        ep: 50,
        gp: 100,
        pp: 500,
    },
};
ARS.currencyNames = {
    cp: 'copper',
    sp: 'silver',
    ep: 'electrum',
    gp: 'gold',
    pp: 'platinum',
};

ARS.currencyWeight = {
    0: 10,
    1: 10,
    2: 50,
};
// ARS.itemTypes = [
//     'Alchemical',
//     'Ammunition',
//     'Animal',
//     'Art',
//     'Clothing',
//     'Daily Food and Lodging',
//     'Equipment Packs',
//     'Gear',
//     'Gem',
//     'Jewelry',
//     'Provisions',
//     'Scroll',
//     'Service',
//     'Herb or Spice',
//     'Tack and Harness',
//     'Tool',
//     'Transport',
//     'Other',
//     'No-Drop',
// ];
ARS.itemTypes = {
    Alchemical: 'Alchemical',
    Ammunition: 'Ammunition',
    Animal: 'Animal',
    Art: 'Art',
    Bracer: 'Bracer',
    Cloak: 'Cloak',
    Clothing: 'Clothing',
    'Daily Food and Lodging': 'Daily Food and Lodging',
    'Equipment Packs': 'Equipment Packs',
    Gear: 'Gear',
    Gem: 'Gem',
    Jewelry: 'Jewelry',
    Provisions: 'Provisions',
    Ring: 'Ring',
    Scroll: 'Scroll',
    Service: 'Service',
    'Herb or Spice': 'Herb or Spice',
    'Tack and Harness': 'Tack and Harness',
    Tool: 'Tool',
    Transport: 'Transport',
    Other: 'Other',
    'No-Drop': 'No-Drop',
};

// ARS.itemRarityTypes = ['Common', 'Uncommon', 'Rare', 'Very Rare', 'Unique', 'Other'];
ARS.itemRarityTypes = {
    Common: 'Common',
    Uncommon: 'Uncommon',
    Rare: 'Rare',
    'Very Rare': 'Very Rare',
    Unique: 'Unique',
    Other: 'Other',
};
// Modifiers to be applied when distance is > medium/long
ARS.rangeModifiers = {
    short: 0,
    medium: -2,
    long: -5,
};

ARS.htmlBasicColors = {
    red: '#FF0000',
    green: '#008000',
    gold: '#FEB500',
    blue: '#0000FF',
    yellow: '#FFFF00',
    cyan: '#00FFFF',
    magenta: '#FF00FF',
    pink: '#F300FE',
    purple: '#582AEA',
    black: '#000000',
    white: '#FFFFFF',
    gray: '#808080',
    orange: '#FFA500',
};

ARS.variant1 = {
    // AC [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    weaponVarmor: {
        // melee weapons
        aklys: [-7, -6, -5, -4, -3, -2, -1, -1, 0, 0, 1],
        atlatl: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'axe, battle': [-5, -4, -3, -2, -1, -1, 0, 0, 1, 1, 2],
        'axe, hand': [-5, -4, -3, -2, -2, -1, 0, 0, 1, 1, 1],
        bardiche: [-3, -2, -2, -1, 0, 0, 1, 1, 2, 2, 3],
        'bec de corbin': [2, 2, 2, 2, 2, 0, 0, 0, 0, 0, -1],
        'bill-guisarme': [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
        blowgun: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'bo stick': [-13, -11, -9, -7, -5, -3, -1, 0, 1, 0, 3],
        caltrop: [-8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2],
        club: [-7, -6, -5, -4, -3, -2, -1, -1, 0, 0, 1],
        dagger: [-4, -4, -3, -3, -2, -2, 0, 0, 1, 1, 3],
        fauchard: [-3, -3, -2, -2, -1, -1, 0, 0, 0, -1, -1],
        'fauchard-fork': [-2, -2, -1, -1, -1, 0, 0, 0, 1, 0, 1],
        'fist or open hand': [-9, -8, -7, -5, -3, -1, 0, 0, 2, 0, 4],
        'flail, footman’s': [3, 3, 2, 2, 1, 2, 1, 1, 1, 1, -1],
        'flail, horseman’s': [0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0],
        'fork, military': [-3, -3, -2, -2, -1, 0, 0, 1, 1, 0, 1],
        garrot: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        glaive: [-2, -2, -1, -1, 0, 0, 0, 0, 0, 0, 0],
        'glaive-guisarme': [-2, -2, -1, -1, 0, 0, 0, 0, 0, 0, 0],
        guisarme: [-3, -3, -2, -2, -1, -1, 0, 0, 0, -1, -1],
        'guisarme-voulge': [-2, -2, -1, -1, 0, 1, 1, 1, 0, 0, 0],
        halberd: [0, 1, 1, 1, 1, 2, 2, 2, 1, 1, 0],
        harpoon: [-3, -2, -2, -1, -1, -1, 0, 0, 0, 0, 0],
        'hammer, lucern': [0, 1, 1, 1, 2, 2, 2, 1, 1, 0, 0],
        hammer: [0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0],
        'hook fauchard': [-3, -3, -2, -2, -1, -1, 0, 0, 0, 0, -1],
        'jo stick': [-10, -9, -8, -6, -4, -2, -1, 0, 1, 0, 2],
        knife: [-6, -5, -5, -4, -3, -2, -1, 0, 1, 1, 3],
        'lance (light horse)': [-3, -3, -2, -2, -1, 0, 0, 0, 0, 0, 0],
        'lance (medium horse)': [-1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0],
        'lance (heavy horse)': [4, 4, 3, 3, 2, 2, 2, 1, 1, 0, 0],
        lasso: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'mace, footman’s': [2, 2, 1, 1, 0, 0, 0, 0, 0, 1, -1],
        'mace, horseman’s': [2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0],
        'man catcher': [0, 0, 0, 0, 0, 0, 0, 0, -1, -2, -3],
        'morning star': [0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2],
        partisan: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'pick, military, footman’s': [3, 3, 2, 2, 1, 1, 0, -1, -1, -1, -2],
        'pick, military, horseman’s': [2, 2, 1, 1, 1, 1, 0, 0, -1, -1, -1],
        'pike, awl': [-1, -1, -1, 0, 0, 0, 0, 0, 0, -1, -2],
        ranseur: [-3, -3, -2, -1, -1, 0, 0, 0, 0, 0, 1],
        sap: [-14, -13, -12, -10, -8, -6, -5, -4, -3, -2, 0],
        scimitar: [-4, -3, -3, -2, -2, -1, 0, 0, 1, 1, 3],
        spear: [-2, -2, -2, -1, -1, -1, 0, 0, 0, 0, 0],
        spetum: [-2, -2, -2, -1, 0, 0, 0, 0, 0, 1, 2],
        'spiked buckler': [-7, -6, -5, -4, -3, -2, -1, 0, 0, 0, 2],
        'staff, quarter': [-9, -8, -7, -5, -3, -1, 0, 0, 1, 1, 1],
        'staff sling': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'sword, bastard': [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0],
        'sword, broad': [-5, -4, -3, -2, -1, 0, 0, 1, 1, 1, 2],
        'sword, falchion': [-3, -2, -2, -1, 0, 1, 1, 1, 1, 0, 0],
        'sword, khopesh': [-7, -6, -5, -4, -2, -1, 0, 0, 1, 1, 2],
        'sword, long': [-4, -3, -2, -1, 0, 0, 0, 0, 0, 1, 2],
        'sword, short': [-5, -4, -3, -2, -1, 0, 0, 0, 1, 0, 2],
        'sword, two-handed': [2, 2, 2, 2, 2, 2, 3, 3, 3, 1, 0],
        trident: [-4, -3, -3, -2, -1, -1, 0, 0, 1, 0, 1],
        voulge: [-2, -2, -1, -1, 0, 1, 1, 1, 0, 0, 0],
        whip: [-14, -12, -10, -8, -6, -4, -2, -1, 1, 0, 3],

        // ranged weapon
        'aklys (hurled)': [-8, -7, -6, -5, -4, -3, -2, -1, 0, 0, 0],
        'atlatl (javelin)': [-6, -5, -4, -3, -2, -1, 0, 0, 1, 1, 2],
        'axe, hand': [-6, -5, -4, -3, -2, -1, -1, 0, 0, 0, 1],
        'blowgun needle': [-14, -12, -10, -8, -6, -4, -2, -1, -1, 1, 2],
        'bow, composite, long': [-4, -3, -2, -1, 0, 0, 1, 2, 2, 3, 3],
        'bow, composite, short': [-4, -4, -3, -3, -1, 0, 1, 2, 2, 2, 3],
        'bow, long': [-2, -1, -1, 0, 0, 1, 2, 3, 3, 3, 3],
        'bow, short': [-7, -6, -5, -4, -1, 0, 0, 1, 2, 2, 2],
        club: [-9, -8, -7, -5, -3, -2, -1, -1, -1, 0, 0],
        'crossbow, hand': [-6, -4, -2, -1, 0, 0, 0, 1, 2, 2, 3],
        'crossbow, heavy': [-2, -1, -1, 0, 1, 2, 3, 3, 4, 4, 4],
        'crossbow, light': [-3, -2, -2, -1, 0, 0, 1, 2, 3, 3, 3],
        dagger: [-7, -6, -5, -4, -3, -2, -1, -1, 0, 0, 1],
        dart: [-7, -6, -5, -4, -3, -2, -1, 0, 1, 0, 1],
        hammer: [-4, -3, -2, -1, 0, 0, 0, 0, 0, 0, 1],
        harpoon: [-6, -5, -4, -3, -2, -1, 0, 0, 0, 0, 1],
        javelin: [-7, -6, -5, -4, -3, -2, -1, 0, 1, 0, 1],
        knife: [-8, -7, -6, -5, -4, -3, -2, -1, 0, 0, 1],
        lasso: [9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
        'sling (bullet)': [-3, -3, -2, -2, -1, 0, 0, 0, 2, 1, 3],
        'sling (stone)': [-7, -6, -5, -4, -2, -1, 0, 0, 2, 1, 3],
        spear: [-4, -4, -3, -3, -2, -2, -1, 0, 0, 0, 0],
        'staff sling (bullet)': [-5, -4, -3, -2, -1, 0, 0, 0, 0, 0, 0],
        'staff sling (stone)': [-6, -5, -4, -3, -2, -1, 0, 0, 0, 0, 0],
    },
};

// variant 2 weapon damage type versus armor
ARS.variant2 = {
    // modifier applied to attack against this type of armor with this type of weapon damage
    weaponVarmor: {
        'banded mail': { slashing: -2, piercing: 0, bludgeoning: -1 },
        brigandine: { slashing: -1, piercing: -1, bludgeoning: 0 },
        'chain mail': { slashing: -2, piercing: 0, bludgeoning: 2 },
        'field plate': { slashing: -3, piercing: -1, bludgeoning: 0 },
        'full plate': { slashing: -4, piercing: -3, bludgeoning: 0 },
        'leather armor': { slashing: 0, piercing: 2, bludgeoning: 0 },
        'plate mail': { slashing: -3, piercing: 0, bludgeoning: 0 },
        'ring mail': { slashing: -1, piercing: -1, bludgeoning: 0 },
        'scale mail': { slashing: 0, piercing: -1, bludgeoning: 0 },
        'splint mail': { slashing: 0, piercing: -1, bludgeoning: -2 },
        'studded leather': { slashing: -2, piercing: -1, bludgeoning: 0 },
    },
};

ARS.weaponVarmor = {
    0: {},
    // AC [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    1: {
        aklys: [-7, -6, -5, -4, -3, -2, -1, -1, 0, 0, 1],
        atlatl: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'axe, battle': [-5, -4, -3, -2, -1, -1, 0, 0, 1, 1, 2],
        'axe, hand': [-5, -4, -3, -2, -2, -1, 0, 0, 1, 1, 1],
        bardiche: [-3, -2, -2, -1, 0, 0, 1, 1, 2, 2, 3],
        'bec de corbin': [2, 2, 2, 2, 2, 0, 0, 0, 0, 0, -1],
        'bill-guisarme': [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
        blowgun: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'bo stick': [-13, -11, -9, -7, -5, -3, -1, 0, 1, 0, 3],
        caltrop: [-8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2],
        club: [-7, -6, -5, -4, -3, -2, -1, -1, 0, 0, 1],
        dagger: [-4, -4, -3, -3, -2, -2, 0, 0, 1, 1, 3],
        fauchard: [-3, -3, -2, -2, -1, -1, 0, 0, 0, -1, -1],
        'fauchard-fork': [-2, -2, -1, -1, -1, 0, 0, 0, 1, 0, 1],
        'fist or open hand': [-9, -8, -7, -5, -3, -1, 0, 0, 2, 0, 4],
        'flail, footman’s': [3, 3, 2, 2, 1, 2, 1, 1, 1, 1, -1],
        'flail, horseman’s': [0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0],
        'fork, military': [-3, -3, -2, -2, -1, 0, 0, 1, 1, 0, 1],
        garrot: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        glaive: [-2, -2, -1, -1, 0, 0, 0, 0, 0, 0, 0],
        'glaive-guisarme': [-2, -2, -1, -1, 0, 0, 0, 0, 0, 0, 0],
        guisarme: [-3, -3, -2, -2, -1, -1, 0, 0, 0, -1, -1],
        'guisarme-voulge': [-2, -2, -1, -1, 0, 1, 1, 1, 0, 0, 0],
        halberd: [0, 1, 1, 1, 1, 2, 2, 2, 1, 1, 0],
        harpoon: [-3, -2, -2, -1, -1, -1, 0, 0, 0, 0, 0],
        'hammer, lucern': [0, 1, 1, 1, 2, 2, 2, 1, 1, 0, 0],
        hammer: [0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0],
        'hook fauchard': [-3, -3, -2, -2, -1, -1, 0, 0, 0, 0, -1],
        'jo stick': [-10, -9, -8, -6, -4, -2, -1, 0, 1, 0, 2],
        knife: [-6, -5, -5, -4, -3, -2, -1, 0, 1, 1, 3],
        'lance (light horse)': [-3, -3, -2, -2, -1, 0, 0, 0, 0, 0, 0],
        'lance (medium horse)': [-1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0],
        'lance (heavy horse)': [4, 4, 3, 3, 2, 2, 2, 1, 1, 0, 0],
        lasso: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'mace, footman’s': [2, 2, 1, 1, 0, 0, 0, 0, 0, 1, -1],
        'mace, horseman’s': [2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0],
        'man catcher': [0, 0, 0, 0, 0, 0, 0, 0, -1, -2, -3],
        'morning star': [0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2],
        partisan: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'pick, military, footman’s': [3, 3, 2, 2, 1, 1, 0, -1, -1, -1, -2],
        'pick, military, horseman’s': [2, 2, 1, 1, 1, 1, 0, 0, -1, -1, -1],
        'pike, awl': [-1, -1, -1, 0, 0, 0, 0, 0, 0, -1, -2],
        ranseur: [-3, -3, -2, -1, -1, 0, 0, 0, 0, 0, 1],
        sap: [-14, -13, -12, -10, -8, -6, -5, -4, -3, -2, 0],
        scimitar: [-4, -3, -3, -2, -2, -1, 0, 0, 1, 1, 3],
        spear: [-2, -2, -2, -1, -1, -1, 0, 0, 0, 0, 0],
        spetum: [-2, -2, -2, -1, 0, 0, 0, 0, 0, 1, 2],
        'spiked buckler': [-7, -6, -5, -4, -3, -2, -1, 0, 0, 0, 2],
        'staff, quarter': [-9, -8, -7, -5, -3, -1, 0, 0, 1, 1, 1],
        'staff sling': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'sword, bastard': [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0],
        'sword, broad': [-5, -4, -3, -2, -1, 0, 0, 1, 1, 1, 2],
        'sword, falchion': [-3, -2, -2, -1, 0, 1, 1, 1, 1, 0, 0],
        'sword, khopesh': [-7, -6, -5, -4, -2, -1, 0, 0, 1, 1, 2],
        'sword, long': [-4, -3, -2, -1, 0, 0, 0, 0, 0, 1, 2],
        'sword, short': [-5, -4, -3, -2, -1, 0, 0, 0, 1, 0, 2],
        'sword, two-handed': [2, 2, 2, 2, 2, 2, 3, 3, 3, 1, 0],
        trident: [-4, -3, -3, -2, -1, -1, 0, 0, 1, 0, 1],
        voulge: [-2, -2, -1, -1, 0, 1, 1, 1, 0, 0, 0],
        whip: [-14, -12, -10, -8, -6, -4, -2, -1, 1, 0, 3],

        // ranged weapon
        'aklys-ranged': [-8, -7, -6, -5, -4, -3, -2, -1, 0, 0, 0],
        'atlatl (javelin)': [-6, -5, -4, -3, -2, -1, 0, 0, 1, 1, 2],
        'axe, hand-ranged': [-6, -5, -4, -3, -2, -1, -1, 0, 0, 0, 1],
        'blowgun needle': [-14, -12, -10, -8, -6, -4, -2, -1, -1, 1, 2],
        'bow, composite, long': [-4, -3, -2, -1, 0, 0, 1, 2, 2, 3, 3],
        'bow, composite, short': [-4, -4, -3, -3, -1, 0, 1, 2, 2, 2, 3],
        'bow, long': [-2, -1, -1, 0, 0, 1, 2, 3, 3, 3, 3],
        'bow, short': [-7, -6, -5, -4, -1, 0, 0, 1, 2, 2, 2],
        'club-ranged': [-9, -8, -7, -5, -3, -2, -1, -1, -1, 0, 0],
        'crossbow, hand': [-6, -4, -2, -1, 0, 0, 0, 1, 2, 2, 3],
        'crossbow, heavy': [-2, -1, -1, 0, 1, 2, 3, 3, 4, 4, 4],
        'crossbow, light': [-3, -2, -2, -1, 0, 0, 1, 2, 3, 3, 3],
        'dagger-ranged': [-7, -6, -5, -4, -3, -2, -1, -1, 0, 0, 1],
        dart: [-7, -6, -5, -4, -3, -2, -1, 0, 1, 0, 1],
        'hammer-ranged': [-4, -3, -2, -1, 0, 0, 0, 0, 0, 0, 1],
        'harpoon-ranged': [-6, -5, -4, -3, -2, -1, 0, 0, 0, 0, 1],
        'javelin-ranged': [-7, -6, -5, -4, -3, -2, -1, 0, 1, 0, 1],
        'knife-ranged': [-8, -7, -6, -5, -4, -3, -2, -1, 0, 0, 1],
        lasso: [9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1],
        'sling (bullet)': [-3, -3, -2, -2, -1, 0, 0, 0, 2, 1, 3],
        'sling (stone)': [-7, -6, -5, -4, -2, -1, 0, 0, 2, 1, 3],
        'spear-ranged': [-4, -4, -3, -3, -2, -2, -1, 0, 0, 0, 0],
        'staff sling (bullet)': [-5, -4, -3, -2, -1, 0, 0, 0, 0, 0, 0],
        'staff sling (stone)': [-6, -5, -4, -3, -2, -1, 0, 0, 0, 0, 0],
    },
    2: {
        // modifier applied to attack against this type of armor with this type of weapon damage
        'banded mail': { slashing: -2, piercing: 0, bludgeoning: -1 },
        brigandine: { slashing: -1, piercing: -1, bludgeoning: 0 },
        'chain mail': { slashing: -2, piercing: 0, bludgeoning: 2 },
        'field plate': { slashing: -3, piercing: -1, bludgeoning: 0 },
        'full plate': { slashing: -4, piercing: -3, bludgeoning: 0 },
        'leather armor': { slashing: 0, piercing: 2, bludgeoning: 0 },
        'plate mail': { slashing: -3, piercing: 0, bludgeoning: 0 },
        'ring mail': { slashing: -1, piercing: -1, bludgeoning: 0 },
        'scale mail': { slashing: 0, piercing: -1, bludgeoning: 0 },
        'splint mail': { slashing: 0, piercing: -1, bludgeoning: -2 },
        'studded leather': { slashing: -2, piercing: -1, bludgeoning: 0 },
    },
};

ARS.weaponVarmorIds = {
    0: {},
    1: {
        aklys: 'aklys',
        atlatl: 'atlatl',
        'axe, battle': 'axe, battle',
        'axe, hand': 'axe, hand',
        bardiche: 'bardiche',
        'bec de corbin': 'bec de corbin',
        'bill-guisarme': 'bill-guisarme',
        blowgun: 'blowgun',
        'bo stick': 'bo stick',
        caltrop: 'caltrop',
        club: 'club',
        dagger: 'dagger',
        fauchard: 'fauchard',
        'fauchard-fork': 'fauchard-fork',
        'fist or open hand': 'fist or open hand',
        'flail, footman’s': 'flail, footman’s',
        'flail, horseman’s': 'flail, horseman’s',
        'fork, military': 'fork, military',
        garrot: 'garrot',
        glaive: 'glaive',
        'glaive-guisarme': 'glaive-guisarme',
        guisarme: 'guisarme',
        'guisarme-voulge': 'guisarme-voulge',
        halberd: 'halberd',
        harpoon: 'harpoon',
        'hammer, lucern': 'hammer, lucern',
        hammer: 'hammer',
        'hook fauchard': 'hook fauchard',
        'jo stick': 'jo stick',
        knife: 'knife',
        'lance (light horse)': 'lance (light horse)',
        'lance (medium horse)': 'lance (medium horse)',
        'lance (heavy horse)': 'lance (heavy horse)',
        lasso: 'lasso',
        'mace, footman’s': 'mace, footman’s',
        'mace, horseman’s': 'mace, horseman’s',
        'man catcher': 'man catcher',
        'morning star': 'morning star',
        partisan: 'partisan',
        'pick, military, footman’s': 'pick, military, footman’s',
        'pick, military, horseman’s': 'pick, military, horseman’s',
        'pike, awl': 'pike, awl',
        ranseur: 'ranseur',
        sap: 'sap',
        scimitar: 'scimitar',
        spear: 'spear',
        spetum: 'spetum',
        'spiked buckler': 'spiked buckler',
        'staff, quarter': 'staff, quarter',
        'staff sling': 'staff sling',
        'sword, bastard': 'sword, bastard',
        'sword, broad': 'sword, broad',
        'sword, falchion': 'sword, falchion',
        'sword, khopesh': 'sword, khopesh',
        'sword, long': 'sword, long',
        'sword, short': 'sword, short',
        'sword, two-handed': 'sword, two-handed',
        trident: 'trident',
        voulge: 'voulge',
        whip: 'whip',
        'aklys (hurled)': 'aklys (hurled)',
        'atlatl (javelin)': 'atlatl (javelin)',
        'blowgun needle': 'blowgun needle',
        'bow, composite, long': 'bow, composite, long',
        'bow, composite, short': 'bow, composite, short',
        'bow, long': 'bow, long',
        'bow, short': 'bow, short',
        'crossbow, hand': 'crossbow, hand',
        'crossbow, heavy': 'crossbow, heavy',
        'crossbow, light': 'crossbow, light',
        dart: 'dart',
        javelin: 'javelin',
        'sling (bullet)': 'sling (bullet)',
        'sling (stone)': 'sling (stone)',
        'staff sling (bullet)': 'staff sling (bullet)',
        'staff sling (stone)': 'staff sling (stone)',

        'aklys-ranged': 'aklys-ranged',
        'atlatl (javelin)': 'atlatl (javelin)',
        'axe, hand-ranged': 'axe, hand-ranged',
        'blowgun needle': 'blowgun needle',
        'bow, composite, long': 'bow, composite, long',
        'bow, composite, short': 'bow, composite, short',
        'bow, long': 'bow, long',
        'bow, short': 'bow, short',
        'club-ranged': 'club-ranged',
        'crossbow, hand': 'crossbow, hand',
        'crossbody, heavy': 'crossbow, heavy',
        'crossbow, light': 'crossbow, light',
        'dagger-ranged': 'dagger-ranged',
        dart: 'dart',
        'hammer-ranged': 'hammer-ranged',
        'harpoon-ranged': 'harpoon-ranged',
        'javelin-ranged': 'javelin-ranged',
        'knife-ranged': 'knife-ranged',
        lasso: 'lasso',
        'sling (bullet)': 'sling (bullet)',
        'sling (stone)': 'sling (stone)',
        'spear-ranged': 'spear-ranged',
        'staff sling (bullet)': 'staff sling (bullet)',
        'staff sling (stone)': 'staff sling (stone)',
    },
    2: {
        'banded mail': 'banded mail',
        brigandine: 'brigandine',
        'chain mail': 'chain mail',
        'field plate': 'field plate',
        'full plate': 'full plate',
        'leather armor': 'leather armor',
        'plate mail': 'plate mail',
        'ring mail': 'ring mail',
        'scale mail': 'scale mail',
        'splint mail': 'splint mail',
        'studded leather': 'studded leather',
    },
};

// status effects, variant specific
ARS.statusEncumbranceEffects = {
    0: [
        {
            id: 'encumbrance-light',
            name: 'STATUSEFFECT.encumbrance-light',
            img: 'systems/ars/icons/general/encumbrance-light.png',
        },
        {
            id: 'encumbrance-moderate',
            name: 'STATUSEFFECT.encumbrance-moderate',
            img: 'systems/ars/icons/general/encumbrance-moderate.png',
        },
        {
            id: 'encumbrance-heavy',
            name: 'STATUSEFFECT.encumbrance-heavy',
            img: 'systems/ars/icons/general/encumbrance-heavy.png',
        },
        {
            id: 'encumbrance-severe',
            name: 'STATUSEFFECT.encumbrance-severe',
            img: 'systems/ars/icons/general/encumbrance-severe.png',
        },
        {
            id: 'encumbrance-max',
            name: 'STATUSEFFECT.encumbrance-severe',
            img: 'systems/ars/icons/general/encumbrance-severe.png',
        },
    ],
    1: [
        {
            id: 'encumbrance-light',
            name: 'STATUSEFFECT.encumbrance-light',
            img: 'systems/ars/icons/general/encumbrance-light.png',
        },
        {
            id: 'encumbrance-moderate',
            name: 'STATUSEFFECT.encumbrance-moderate',
            img: 'systems/ars/icons/general/encumbrance-moderate.png',
        },
        {
            id: 'encumbrance-heavy',
            name: 'STATUSEFFECT.encumbrance-heavy',
            img: 'systems/ars/icons/general/encumbrance-heavy.png',
        },
        {
            id: 'encumbrance-severe',
            name: 'STATUSEFFECT.encumbrance-severe',
            img: 'systems/ars/icons/general/encumbrance-severe.png',
        },
        {
            id: 'encumbrance-max',
            name: 'STATUSEFFECT.encumbrance-severe',
            img: 'systems/ars/icons/general/encumbrance-severe.png',
        },
    ],
    2: [
        {
            id: 'encumbrance-light',
            name: 'STATUSEFFECT.encumbrance-light',
            img: 'systems/ars/icons/general/encumbrance-light.png',
        },
        {
            id: 'encumbrance-moderate',
            name: 'STATUSEFFECT.encumbrance-moderate',
            img: 'systems/ars/icons/general/encumbrance-moderate.png',
            changes: [
                {
                    key: 'system.mods.attack.value',
                    mode: CONST.ACTIVE_EFFECT_MODES.ADD,
                    value: -1,
                },
            ],
            duration: {},
            flags: {},
        },
        {
            id: 'encumbrance-heavy',
            name: 'STATUSEFFECT.encumbrance-heavy',
            img: 'systems/ars/icons/general/encumbrance-heavy.png',
            changes: [
                {
                    key: 'system.mods.attack.value',
                    mode: CONST.ACTIVE_EFFECT_MODES.ADD,
                    value: -2,
                },
                {
                    key: 'system.mods.ac.value',
                    mode: CONST.ACTIVE_EFFECT_MODES.ADD,
                    value: -1,
                },
            ],
        },
        {
            id: 'encumbrance-severe',
            name: 'STATUSEFFECT.encumbrance-severe',
            img: 'systems/ars/icons/general/encumbrance-severe.png',
            changes: [
                {
                    key: 'system.mods.attack.value',
                    mode: CONST.ACTIVE_EFFECT_MODES.ADD,
                    value: -4,
                },
                {
                    key: 'system.mods.ac.value',
                    mode: CONST.ACTIVE_EFFECT_MODES.ADD,
                    value: -3,
                },
            ],
        },
        {
            id: 'encumbrance-max',
            name: 'STATUSEFFECT.encumbrance-severe',
            img: 'systems/ars/icons/general/encumbrance-severe.png',
            changes: [
                {
                    key: 'system.mods.attack.value',
                    mode: CONST.ACTIVE_EFFECT_MODES.ADD,
                    value: -4,
                },
                {
                    key: 'system.mods.ac.value',
                    mode: CONST.ACTIVE_EFFECT_MODES.ADD,
                    value: -3,
                },
            ],
        },
    ],
};

// variant wide status effects
ARS.defaultStatusEffects = [
    {
        id: 'cover-25%',
        name: 'STATUSEFFECT.cover25',
        img: 'systems/ars/icons/svg/shield25.svg',
    },
    {
        id: 'cover-50%',
        name: 'STATUSEFFECT.cover50',
        img: 'systems/ars/icons/svg/shield50.svg',
    },
    {
        id: 'cover-75%',
        name: 'STATUSEFFECT.cover75',
        img: 'systems/ars/icons/svg/shield75.svg',
    },
    {
        id: 'cover-90%',
        name: 'STATUSEFFECT.cover90',
        img: 'systems/ars/icons/svg/shield90.svg',
    },
    {
        id: 'concealed-25%',
        name: 'STATUSEFFECT.concealed25',
        tint: '#67F13F',
        img: 'icons/consumables/plants/dried-leaf-stem-herb-brown.webp',
    },
    {
        id: 'concealed-50%',
        name: 'STATUSEFFECT.concealed50',
        tint: '#E59EEC',
        img: 'icons/consumables/plants/dried-pointy-stems-brown.webp',
    },
    {
        id: 'concealed-75%',
        name: 'STATUSEFFECT.concealed75',
        tint: '#3F72F1',
        img: 'icons/consumables/plants/grass-dried-bundle-brown.webp',
    },
    {
        id: 'concealed-90%',
        name: 'STATUSEFFECT.concealed90',
        tint: '#F1523F',
        img: 'icons/magic/nature/root-vine-barrier-wall-brown.webp',
    },
    {
        id: 'charge',
        name: 'STATUSEFFECT.charge',
        img: 'icons/creatures/mammals/ox-bull-horned-glowing-orange.webp',
        /**
         * we manage this ourselves in actor.js getStatusFormula()
         * so that the value consistantly works using just the status id
         *
         */
        // changes: [
        //     {
        //         key: 'system.mods.acstatus',
        //         mode: CONST.ACTIVE_EFFECT_MODES.ADD,
        //         value: 'nodex ',
        //     },
        //     {
        //         key: 'system.mods.ac.value',
        //         mode: CONST.ACTIVE_EFFECT_MODES.ADD,
        //         value: -1,
        //     },
        //     {
        //         key: 'system.mods.attack.melee',
        //         mode: CONST.ACTIVE_EFFECT_MODES.ADD,
        //         value: 2,
        //     },
        // ],
    },
    {
        id: 'charm',
        name: 'STATUSEFFECT.charm',
        img: 'icons/magic/control/hypnosis-mesmerism-swirl.webp',
    },
    {
        id: 'hold',
        name: 'STATUSEFFECT.hold',
        img: 'icons/magic/control/debuff-energy-hold-pink.webp',
        /**
         * we manage this ourselves in actor.js getStatusFormula()
         * so that the value consistantly works using just the status id
         *
         */
        // changes: [
        //     {
        //         key: 'system.mods.acstatus',
        //         mode: CONST.ACTIVE_EFFECT_MODES.ADD,
        //         value: 'nodex noshield,',
        //     },
        //     {
        //         key: 'attacker.always',
        //         mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
        //         value: '{"properties": "", "type": "attack", "formula": "2"}',
        //     },
        // ],
    },
    {
        id: 'mind',
        name: 'STATUSEFFECT.mind',
        img: 'icons/magic/perception/third-eye-blue-red.webp',
    },
    {
        id: 'dying',
        name: 'STATUSEFFECT.dying',
        img: 'icons/svg/unconscious.svg',
        changes: [
            {
                key: 'special.ongoing',
                mode: CONST.ACTIVE_EFFECT_MODES.CUSTOM,
                value: '{"type": "damage","rate": "1","cycle": "round","dmgType": "bleeding",  "formula": "1"}',
            },
        ],
    },
];

// #region advanced_automation: encapsulate all of these extended features behind an 'advanced automation' series of options

// thief skill modifier automation for dexterity and no-armor
ARS.thiefSkillMods = {
    dexMod: {
        0: {
            'find traps': [-15, -15, -15, -15, -15, -15, -15, -15, -15, -10, -5, 0, 0, 0, 0, 0, 5, 10, 15],
            'hide in shadows': [-10, -10, -10, -10, -10, -10, -10, -10, -10, -5, 0, 0, 0, 0, 0, 0, 5, 10, 15],
            'move quietly': [-20, -20, -20, -20, -20, -20, -20, -20, -20, -15, -10, -5, 0, 0, 0, 0, 5, 10, 15],
            'open locks/disarm traps': [-10, -10, -10, -10, -10, -10, -10, -10, -10, -5, 0, 0, 0, 0, 0, 5, 10, 15, 20],
            'pick pockets': [-15, -15, -15, -15, -15, -15, -15, -15, -15, -10, -5, 0, 0, 0, 0, 0, 0, 5, 15],
        },
        1: {
            'pick pockets': [-15, -15, -15, -15, -15, -15, -15, -15, -15, -10, -5, 0, 0, 0, 0, 0, 5, 10, 15],
            'open locks': [-10, -10, -10, -10, -10, -10, -10, -10, -10, -5, 0, 0, 0, 0, 0, 5, 10, 15, 20],
            'find/remove traps': [-10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -5, 0, 0, 0, 0, 0, 0, 5, 10],
            'move silently': [-20, -20, -20, -20, -20, -20, -20, -20, -20, -15, -10, -5, 0, 0, 0, 0, 5, 10, 15],
            'hide in shadows': [-10, -10, -10, -10, -10, -10, -10, -10, -10, -5, 0, 0, 0, 0, 0, 0, 5, 10, 15],
        },
    },
    noArmorMod: {
        'pick pockets': [5, 5, 5],
        'open locks': [0, 0, 0],
        'find traps': [0, 0, 0],
        'find/remove traps': [0, 0, 0],
        'move quietly': [10, 10, 0],
        'move silently': [0, 0, 10],
        'hide in shadows': [5, 5, 5],
        'detect noise': [0, 0, 0],
        'climb walls': [10, 10, 10],
        'read languages': [0, 0, 0],
    }, // // variant 1 and
};

// punching, wrestling, martial arts, overbear and various other modifiers
ARS.martialCombat = {
    2: {
        punching: {
            20: { move: 'Haymaker', damage: '2', KO: 10 },
            19: { move: 'Wild swing', damage: '0', KO: 1 },
            18: { move: 'Rabbit punch', damage: '1', KO: 3 },
            17: { move: 'Kidney punch', damage: '1', KO: 5 },
            16: { move: 'Glancing blow', damage: '1', KO: 2 },
            15: { move: 'Jab', damage: '2', KO: 6 },
            14: { move: 'Uppercut', damage: '1', KO: 8 },
            13: { move: 'Hook', damage: '2', KO: 9 },
            12: { move: 'Kidney punch', damage: '1', KO: 5 },
            11: { move: 'Hook', damage: '2', KO: 10 },
            10: { move: 'Glancing blow', damage: '1', KO: 3 },
            9: { move: 'Combination', damage: '1', KO: 10 },
            8: { move: 'Uppercut', damage: '1', KO: 9 },
            7: { move: 'Combination', damage: '2', KO: 10 },
            6: { move: 'Jab', damage: '2', KO: 8 },
            5: { move: 'Glancing blow', damage: '1', KO: 3 },
            4: { move: 'Rabbit punch', damage: '2', KO: 5 },
            3: { move: 'Hook', damage: '2', KO: 12 },
            2: { move: 'Uppercut', damage: '2', KO: 15 },
            1: { move: 'Wild swing', damage: '0', KO: 2 },
            0: { move: 'Haymaker', damage: '2', KO: 25 },
        },
        martialArts: {
            20: { move: 'Head Punch', damage: '3', KO: 15 },
            19: { move: 'High Kick', damage: '2', KO: 10 },
            18: { move: 'Vitals-Kick', damage: '2', KO: 8 },
            17: { move: 'Vitals-Punch', damage: '2', KO: 5 },
            16: { move: 'Head Bash', damage: '2', KO: 5 },
            15: { move: 'Side Kick', damage: '1', KO: 3 },
            14: { move: 'Elbow Shot', damage: '1', KO: 1 },
            13: { move: 'Body-Punch', damage: '1', KO: 2 },
            12: { move: 'Low Kick', damage: '1', KO: 1 },
            11: { move: 'Graze', damage: '0', KO: 1 },
            10: { move: 'Body-Punch', damage: '1', KO: 2 },
            9: { move: 'Low Kick', damage: '1', KO: 1 },
            8: { move: 'Body-Punch', damage: '1', KO: 2 },
            7: { move: 'Knee-Shot', damage: '1', KO: 3 },
            6: { move: 'Side Kick', damage: '1', KO: 5 },
            5: { move: 'Head Bash', damage: '2', KO: 10 },
            4: { move: 'Vitals-Punch', damage: '2', KO: 10 },
            3: { move: 'Vitals-Kick', damage: '2', KO: 15 },
            2: { move: 'High Kick', damage: '2', KO: 20 },
            1: { move: 'Head Punch', damage: '3', KO: 30 },
            0: { move: 'Head Punch', damage: '3', KO: 30 },
        },
        wrestling: {
            20: { move: 'Bear hug', damage: '2', KO: 10, effect: 'Restrained' },
            19: { move: 'Arm twist', damage: '0', KO: 1, effect: '' },
            18: { move: 'Kick', damage: '1', KO: 3, effect: '' },
            17: { move: 'Trip', damage: '1', KO: 5, effect: '' },
            16: { move: 'Elbow smash', damage: '1', KO: 2, effect: '' },
            15: { move: 'Arm lock', damage: '2', KO: 6, effect: 'Restrained' },
            14: { move: 'Leg twist', damage: '1', KO: 8, effect: '' },
            13: { move: 'Leg lock', damage: '2', KO: 9, effect: 'Restrained' },
            12: { move: 'Throw', damage: '1', KO: 5, effect: 'Break' },
            11: { move: 'Gouge', damage: '2', KO: 10, effect: 'Break' },
            10: { move: 'Elbow smash', damage: '1', KO: 3, effect: '' },
            9: { move: 'Leg lock', damage: '1', KO: 10, effect: 'Restrained' },
            8: { move: 'Headlock', damage: '1', KO: 9, effect: 'Restrained' },
            7: { move: 'Throw', damage: '2', KO: 10, effect: 'Break' },
            6: { move: 'Gouge', damage: '2', KO: 8, effect: 'Break' },
            5: { move: 'Kick', damage: '1', KO: 3, effect: '' },
            4: { move: 'Arm lock', damage: '2', KO: 5, effect: 'Restrained' },
            3: { move: 'Gouge', damage: '2', KO: 12, effect: 'Break' },
            2: { move: 'Headlock', damage: '2', KO: 15, effect: '' },
            1: { move: 'Leg twist', damage: '0', KO: 2, effect: '' },
            0: { move: 'Bearhug', damage: '2', KO: 25, effect: 'Restrained' },
        },
        wrestleInArmorPenalties: {
            studdedleather: -1,
            ringmail: -2,
            scalemail: -2,
            brigandine: -2,
            chainmail: -2,
            bronzeplatemail: -5,
            bandedmail: -5,
            splintmail: -5,
            halfplate: -5,
            fieldplate: -8,
            fullplate: -10,
            platemail: -5,
        },
    },
};

// todo: start by putting these type of things behind a 'advanced automation wall'
ARS.optionalRules = {
    2: {
        // cfh - modifier applied to all DEX based checks, whether skill or check, while wearing armor/gear
        dexPenalitiesForArmor: {
            robes: 0,
            garments: 0,
            studdedleather: -1,
            leatherarmor: 0,
            paddedarmor: 0,
            ringmail: -1,
            scalemail: -2,
            hidearmor: -3,
            brigandine: -2,
            chainmail: -2,
            bronzeplatemail: -3,
            bandedmail: -2,
            splintmail: -2,
            halfplate: -2,
            fieldplate: -3,
            fullplate: -3,
            platemail: -3,
            buckler: 0,
            smallshield: -1,
            mediumshield: -2,
            bodyshield: -3,
            towershield: -4,
            shield: -1,
        },
    },
};

// attacks per round automation and helper data
ARS.warriorAttacksPerRound = {
    // tier 1
    1: '1/round',
    // tier 2
    2: '3/2 rounds',
    // tier 3
    3: '2/round',
};

// specialization display
ARS.specialistAttacksPerRound = {
    // tier 1
    1: {
        'Melee Weapon': '3/2',
        'Light X-bow': '1/1',
        'Heavy X-bow': '1/2',
        'Thrown Dagger': '3/1',
        'Thrown Dart': '4/1',
        'Other (non bow) Missiles': '3/2',
    },
    // tier 2
    2: {
        'Melee Weapon': '2/1',
        'Light X-bow': '3/2',
        'Heavy X-bow': '1/1',
        'Thrown Dagger': '4/1',
        'Thrown Dart': '5/1',
        'Other (non bow) Missiles': '2/1',
    },
    // tier 3
    3: {
        'Melee Weapon': '5/2',
        'Light X-bow': '2/1',
        'Heavy X-bow': '3/2',
        'Thrown Dagger': '5/1',
        'Thrown Dart': '6/1',
        'Other (non bow) Missiles': '5/2',
    },
};

// #endregion

// #region #psionics system

// #psionic
ARS.psionics = {
    // discipline category
    disciplines: {
        generic: 'Generic',
        discipline: 'Discipline',
        attack: 'Attack',
        defense: 'Defense',
        clairsentience: 'Clairsentience',
        psychokinesis: 'Psychokinesis',
        psychometabolism: 'Psychometabolism',
        psychoportation: 'Psychoportation',
        telepathy: 'Telepathy',
        metapsionics: 'Metapsionics',
    },

    // power category
    powerCategory: {
        science: 'Science',
        devotion: 'Devotion',
    },

    // psionic attack/defense types - used in automation of the more complex mechanics of psionics, like psi vs. psi
    atkDefType: {
        none: 'None',
        mindthrust: 'Mind Thrust',
        egowhip: 'Ego Whip',
        idinsinuation: 'Id Insinuation',
        psychiccrush: 'Psychic Crush',
        psionicblast: 'Psionic Blast',
        mindblank: 'Mind Blank',
        thoughtshield: 'Thought Shield',
        mentalbarrier: 'Mental Barriers',
        intellectfortress: 'Intellect Fortress',
        towerofironwill: 'Tower of Iron Will',
    },

    // 2e progression table - unused currently
    psionicProgression: {
        1: { disciplines: 1, sciences: 1, devotions: 3, defenseModes: 1 },
        2: { disciplines: 2, sciences: 1, devotions: 5, defenseModes: 1 },
        3: { disciplines: 2, sciences: 2, devotions: 7, defenseModes: 2 },
        4: { disciplines: 2, sciences: 2, devotions: 9, defenseModes: 2 },
        5: { disciplines: 2, sciences: 3, devotions: 10, defenseModes: 3 },
        6: { disciplines: 3, sciences: 3, devotions: 11, defenseModes: 3 },
        7: { disciplines: 3, sciences: 4, devotions: 12, defenseModes: 4 },
        8: { disciplines: 3, sciences: 4, devotions: 13, defenseModes: 4 },
        9: { disciplines: 3, sciences: 5, devotions: 14, defenseModes: 5 },
        10: { disciplines: 4, sciences: 5, devotions: 15, defenseModes: 5 },
        11: { disciplines: 4, sciences: 6, devotions: 16, defenseModes: 5 },
        12: { disciplines: 4, sciences: 6, devotions: 17, defenseModes: 5 },
        13: { disciplines: 5, sciences: 7, devotions: 18, defenseModes: 5 },
        14: { disciplines: 5, sciences: 7, devotions: 19, defenseModes: 5 },
        15: { disciplines: 5, sciences: 8, devotions: 20, defenseModes: 5 },
        16: { disciplines: 5, sciences: 8, devotions: 21, defenseModes: 5 },
        17: { disciplines: 5, sciences: 9, devotions: 22, defenseModes: 5 },
        18: { disciplines: 6, sciences: 9, devotions: 23, defenseModes: 5 },
        19: { disciplines: 6, sciences: 10, devotions: 24, defenseModes: 5 },
        20: { disciplines: 6, sciences: 10, devotions: 25, defenseModes: 5 },
    },

    // IV.A. PSIONIC VS. PSIONIC IN MENTAL COMBAT, dmg pg. 76
    psionicCombatTable: [
        {
            range: [1, 25],
            result: {
                psionicblast: { mindblank: 3, thoughtshield: 7, mentalbarrier: 4, intellectfortress: 1, towerofironwill: 0 },
                mindthrust: { mindblank: 12, thoughtshield: 4, mentalbarrier: 0, intellectfortress: 0, towerofironwill: 1 },
                egowhip: { mindblank: 8, thoughtshield: 3, mentalbarrier: 0, intellectfortress: 0, towerofironwill: 0 },
                idinsinuation: { mindblank: 1, thoughtshield: 6, mentalbarrier: 8, intellectfortress: 1, towerofironwill: 1 },
                psychiccrush: {
                    mindblank: 2,
                    thoughtshield: 0,
                    mentalbarrier: 0,
                    intellectfortress: 0,
                    towerofironwill: 0,
                },
            },
        },
        {
            range: [26, 50],
            result: {
                psionicblast: { mindblank: 6, thoughtshield: 9, mentalbarrier: 6, intellectfortress: 2, towerofironwill: 0 },
                mindthrust: { mindblank: 15, thoughtshield: 6, mentalbarrier: 1, intellectfortress: 0, towerofironwill: 2 },
                egowhip: { mindblank: 12, thoughtshield: 4, mentalbarrier: 0, intellectfortress: 0, towerofironwill: 0 },
                idinsinuation: { mindblank: 2, thoughtshield: 8, mentalbarrier: 10, intellectfortress: 3, towerofironwill: 3 },
                psychiccrush: {
                    mindblank: 5,
                    thoughtshield: 2,
                    mentalbarrier: 1,
                    intellectfortress: 0,
                    towerofironwill: 0,
                },
            },
        },
        {
            range: [51, 75],
            result: {
                psionicblast: { mindblank: 10, thoughtshield: 12, mentalbarrier: 9, intellectfortress: 4, towerofironwill: 1 },
                mindthrust: { mindblank: 18, thoughtshield: 9, mentalbarrier: 2, intellectfortress: 2, towerofironwill: 3 },
                egowhip: { mindblank: 17, thoughtshield: 6, mentalbarrier: 1, intellectfortress: 1, towerofironwill: 1 },
                idinsinuation: {
                    mindblank: 4,
                    thoughtshield: 11,
                    mentalbarrier: 13,
                    intellectfortress: 7,
                    towerofironwill: 6,
                },
                psychiccrush: {
                    mindblank: 9,
                    thoughtshield: 4,
                    mentalbarrier: 2,
                    intellectfortress: 1,
                    towerofironwill: 0,
                },
            },
        },
        {
            range: [76, 100],
            result: {
                psionicblast: {
                    mindblank: 15,
                    thoughtshield: 16,
                    mentalbarrier: 13,
                    intellectfortress: 7,
                    towerofironwill: 2,
                },
                mindthrust: { mindblank: 22, thoughtshield: 13, mentalbarrier: 5, intellectfortress: 4, towerofironwill: 5 },
                egowhip: { mindblank: 23, thoughtshield: 9, mentalbarrier: 3, intellectfortress: 2, towerofironwill: 3 },
                idinsinuation: {
                    mindblank: 7,
                    thoughtshield: 15,
                    mentalbarrier: 17,
                    intellectfortress: 12,
                    towerofironwill: 10,
                },
                psychiccrush: {
                    mindblank: 14,
                    thoughtshield: 7,
                    mentalbarrier: 5,
                    intellectfortress: 3,
                    towerofironwill: 2,
                },
            },
        },
        {
            range: [101, 125],
            result: {
                psionicblast: {
                    mindblank: 21,
                    thoughtshield: 21,
                    mentalbarrier: 18,
                    intellectfortress: 11,
                    towerofironwill: 4,
                },
                mindthrust: { mindblank: 26, thoughtshield: 18, mentalbarrier: 9, intellectfortress: 7, towerofironwill: 8 },
                egowhip: { mindblank: 30, thoughtshield: 13, mentalbarrier: 6, intellectfortress: 4, towerofironwill: 6 },
                idinsinuation: {
                    mindblank: 11,
                    thoughtshield: 20,
                    mentalbarrier: 22,
                    intellectfortress: 18,
                    towerofironwill: 15,
                },
                psychiccrush: {
                    mindblank: 20,
                    thoughtshield: 11,
                    mentalbarrier: 9,
                    intellectfortress: 6,
                    towerofironwill: 4,
                },
            },
        },
        {
            range: [126, Infinity],
            result: {
                psionicblast: {
                    mindblank: 28,
                    thoughtshield: 27,
                    mentalbarrier: 24,
                    intellectfortress: 16,
                    towerofironwill: 7,
                },
                mindthrust: {
                    mindblank: 30,
                    thoughtshield: 24,
                    mentalbarrier: 16,
                    intellectfortress: 11,
                    towerofironwill: 12,
                },
                egowhip: { mindblank: 38, thoughtshield: 18, mentalbarrier: 10, intellectfortress: 7, towerofironwill: 10 },
                idinsinuation: {
                    mindblank: 16,
                    thoughtshield: 26,
                    mentalbarrier: 28,
                    intellectfortress: 25,
                    towerofironwill: 21,
                },
                psychiccrush: {
                    mindblank: 27,
                    thoughtshield: 16,
                    mentalbarrier: 14,
                    intellectfortress: 10,
                    towerofironwill: 7,
                },
            },
        },
    ],

    // IV.B. PSIONIC ATTACK UPON DEFENSELESS PSIONIC, dmg pg. 77
    psionicDefenselessTable: [
        {
            range: [1, 25],
            result: {
                psionicblast: [
                    { range: [10, 59], result: 'D', description: 'Dazed for 1-4 turns, no psionic or other activity' },
                    { range: [60, 109], result: 'C', description: 'Confused for 2-8 rounds, no psionic activity possible' },
                    { range: [110, 159], result: 'C', description: 'Confused for 2-8 rounds, no psionic activity possible' },
                    { range: [160, 209], result: 15 },
                    { range: [210, 259], result: 10 },
                    { range: [260, 309], result: 5 },
                    { range: [310, Infinity], result: 5 },
                ],
                mindthrust: [
                    {
                        range: [10, 59],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    {
                        range: [60, 109],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    { range: [110, 159], result: 40 },
                    { range: [160, 209], result: 35 },
                    { range: [210, 259], result: 30 },
                    { range: [260, 309], result: 25 },
                    { range: [310, Infinity], result: 20 },
                ],
                egowhip: [
                    { range: [10, 59], result: 30 },
                    { range: [60, 109], result: 25 },
                    { range: [110, 159], result: 20 },
                    { range: [160, 209], result: 15 },
                    { range: [210, 259], result: 10 },
                    { range: [260, 309], result: 5 },
                    { range: [310, Infinity], result: 5 },
                ],
                idinsinuation: [
                    { range: [10, 59], result: 40 },
                    { range: [60, 109], result: 35 },
                    { range: [110, 159], result: 30 },
                    { range: [160, 209], result: 25 },
                    { range: [210, 259], result: 20 },
                    { range: [260, 309], result: 15 },
                    { range: [310, Infinity], result: 10 },
                ],
                psychiccrush: [
                    { range: [10, 59], result: 72 },
                    { range: [60, 109], result: 60 },
                    { range: [110, 159], result: 50 },
                    { range: [160, 209], result: 40 },
                    { range: [210, 259], result: 30 },
                    { range: [260, 309], result: 20 },
                    { range: [310, Infinity], result: 10 },
                ],
            },
        },
        {
            range: [26, 50],
            result: {
                psionicblast: [
                    { range: [10, 59], result: 'S', description: 'Sleeping in a coma for 1-4 weeks, catatonic state' },
                    { range: [60, 109], result: 'D', description: 'Dazed for 1-4 turns, no psionic or other activity' },
                    { range: [110, 159], result: 'C', description: 'Confused for 2-8 rounds, no psionic activity possible' },
                    { range: [160, 209], result: 'C', description: 'Confused for 2-8 rounds, no psionic activity possible' },
                    { range: [210, 259], result: 15 },
                    { range: [260, 309], result: 10 },
                    { range: [310, Infinity], result: 5 },
                ],
                mindthrust: [
                    {
                        range: [10, 59],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    {
                        range: [60, 109],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    {
                        range: [110, 159],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    { range: [160, 209], result: 40 },
                    { range: [210, 259], result: 35 },
                    { range: [260, 309], result: 30 },
                    { range: [310, Infinity], result: 25 },
                ],
                egowhip: [
                    { range: [10, 59], result: 35 },
                    { range: [60, 109], result: 30 },
                    { range: [110, 159], result: 25 },
                    { range: [160, 209], result: 20 },
                    { range: [210, 259], result: 15 },
                    { range: [260, 309], result: 10 },
                    { range: [310, Infinity], result: 5 },
                ],
                idinsinuation: [
                    {
                        range: [10, 59],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    { range: [60, 109], result: 40 },
                    { range: [110, 159], result: 35 },
                    { range: [160, 209], result: 30 },
                    { range: [210, 259], result: 25 },
                    { range: [260, 309], result: 20 },
                    { range: [310, Infinity], result: 15 },
                ],
                psychiccrush: [
                    { range: [10, 59], result: 75 },
                    { range: [60, 109], result: 62 },
                    { range: [110, 159], result: 52 },
                    { range: [160, 209], result: 42 },
                    { range: [210, 259], result: 32 },
                    { range: [260, 309], result: 22 },
                    { range: [310, Infinity], result: 12 },
                ],
            },
        },
        {
            range: [51, 75],
            result: {
                psionicblast: [
                    {
                        range: [10, 59],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    { range: [60, 109], result: 'S', description: 'Sleeping in a coma for 1-4 weeks, catatonic state' },
                    { range: [110, 159], result: 'D', description: 'Dazed for 1-4 turns, no psionic or other activity' },
                    { range: [160, 209], result: 'C', description: 'Confused for 2-8 rounds, no psionic activity possible' },
                    { range: [210, 259], result: 'C', description: 'Confused for 2-8 rounds, no psionic activity possible' },
                    { range: [260, 309], result: 15 },
                    { range: [310, Infinity], result: 10 },
                ],
                mindthrust: [
                    {
                        range: [10, 59],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [60, 109],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    {
                        range: [110, 159],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    {
                        range: [160, 209],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    { range: [210, 259], result: 40 },
                    { range: [260, 309], result: 35 },
                    { range: [310, Infinity], result: 30 },
                ],
                egowhip: [
                    { range: [10, 59], result: 40 },
                    { range: [60, 109], result: 35 },
                    { range: [110, 159], result: 30 },
                    { range: [160, 209], result: 25 },
                    { range: [210, 259], result: 20 },
                    { range: [260, 309], result: 15 },
                    { range: [310, Infinity], result: 10 },
                ],
                idinsinuation: [
                    {
                        range: [10, 59],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    {
                        range: [60, 109],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    { range: [110, 159], result: 40 },
                    { range: [160, 209], result: 35 },
                    { range: [210, 259], result: 30 },
                    { range: [260, 309], result: 25 },
                    { range: [310, Infinity], result: 20 },
                ],
                psychiccrush: [
                    { range: [10, 59], result: 79 },
                    { range: [60, 109], result: 65 },
                    { range: [110, 159], result: 55 },
                    { range: [160, 209], result: 45 },
                    { range: [210, 259], result: 35 },
                    { range: [260, 309], result: 25 },
                    { range: [310, Infinity], result: 15 },
                ],
            },
        },
        {
            range: [76, 100],
            result: {
                psionicblast: [
                    {
                        range: [10, 59],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [60, 109],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    { range: [110, 159], result: 'S', description: 'Sleeping in a coma for 1-4 weeks, catatonic state' },
                    { range: [160, 209], result: 'D', description: 'Dazed for 1-4 turns, no psionic or other activity' },
                    { range: [210, 259], result: 'C', description: 'Confused for 2-8 rounds, no psionic activity possible' },
                    { range: [260, 309], result: 'C', description: 'Confused for 2-8 rounds, no psionic activity possible' },
                    { range: [310, Infinity], result: 15 },
                ],
                mindthrust: [
                    {
                        range: [10, 59],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [60, 109],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [110, 159],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    {
                        range: [160, 209],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    {
                        range: [210, 259],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    { range: [260, 309], result: 40 },
                    { range: [310, Infinity], result: 35 },
                ],
                egowhip: [
                    {
                        range: [10, 59],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    { range: [60, 109], result: 40 },
                    { range: [110, 159], result: 35 },
                    { range: [160, 209], result: 30 },
                    { range: [210, 259], result: 25 },
                    { range: [260, 309], result: 20 },
                    { range: [310, Infinity], result: 15 },
                ],
                idinsinuation: [
                    {
                        range: [10, 59],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    {
                        range: [60, 109],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    {
                        range: [110, 159],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    { range: [160, 209], result: 40 },
                    { range: [210, 259], result: 35 },
                    { range: [260, 309], result: 30 },
                    { range: [310, Infinity], result: 25 },
                ],
                psychiccrush: [
                    { range: [10, 59], result: 84 },
                    { range: [60, 109], result: 69 },
                    { range: [110, 159], result: 59 },
                    { range: [160, 209], result: 49 },
                    { range: [210, 259], result: 39 },
                    { range: [260, 309], result: 29 },
                    { range: [310, Infinity], result: 19 },
                ],
            },
        },
        {
            range: [101, 125],
            result: {
                psionicblast: [
                    {
                        range: [10, 59],
                        result: 'K',
                        description: 'Killed, raising/resurrection is possible, but psionic ability is lost',
                    },
                    {
                        range: [60, 109],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [110, 159],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    { range: [160, 209], result: 'S', description: 'Sleeping in a coma for 1-4 weeks, catatonic state' },
                    { range: [210, 259], result: 'D', description: 'Dazed for 1-4 turns, no psionic or other activity' },
                    { range: [260, 309], result: 'C', description: 'Confused for 2-8 rounds, no psionic activity possible' },
                    {
                        range: [310, Infinity],
                        result: 'C',
                        description: 'Confused for 2-8 rounds, no psionic activity possible',
                    },
                ],
                mindthrust: [
                    {
                        range: [10, 59],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [60, 109],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [110, 159],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [160, 209],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    {
                        range: [210, 259],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    {
                        range: [260, 309],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    { range: [310, Infinity], result: 40 },
                ],
                egowhip: [
                    {
                        range: [10, 59],
                        result: 'I',
                        description: 'Idiocy, psionic ability lost forever, though idiocy is curable by a heal spell',
                    },
                    {
                        range: [60, 109],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    { range: [110, 159], result: 40 },
                    { range: [160, 209], result: 35 },
                    { range: [210, 259], result: 30 },
                    { range: [260, 309], result: 25 },
                    { range: [310, Infinity], result: 20 },
                ],
                idinsinuation: [
                    {
                        range: [10, 59],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    {
                        range: [60, 109],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    {
                        range: [110, 159],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    {
                        range: [160, 209],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    { range: [210, 259], result: 40 },
                    { range: [260, 309], result: 35 },
                    { range: [310, Infinity], result: 30 },
                ],
                psychiccrush: [
                    { range: [10, 59], result: 90 },
                    { range: [60, 109], result: 74 },
                    { range: [110, 159], result: 64 },
                    { range: [160, 209], result: 54 },
                    { range: [210, 259], result: 44 },
                    { range: [260, 309], result: 34 },
                    { range: [310, Infinity], result: 24 },
                ],
            },
        },
        {
            range: [126, Infinity],
            result: {
                psionicblast: [
                    {
                        range: [10, 59],
                        result: 'K',
                        description: 'Killed, raising/resurrection is possible, but psionic ability is lost',
                    },
                    {
                        range: [60, 109],
                        result: 'K',
                        description: 'Killed, raising/resurrection is possible, but psionic ability is lost',
                    },
                    {
                        range: [110, 159],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [160, 209],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    { range: [210, 259], result: 'S', description: 'Sleeping in a coma for 1-4 weeks, catatonic state' },
                    { range: [260, 309], result: 'D', description: 'Dazed for 1-4 turns, no psionic or other activity' },
                    {
                        range: [310, Infinity],
                        result: 'C',
                        description: 'Confused for 2-8 rounds, no psionic activity possible',
                    },
                ],
                mindthrust: [
                    {
                        range: [10, 59],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [60, 109],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [110, 159],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [160, 209],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    {
                        range: [210, 259],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    {
                        range: [260, 309],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                    {
                        range: [310, Infinity],
                        result: 'W',
                        description:
                            'Wounded psionically, one attack or defense mode or psionic discipline unusable for 2-8 weeks',
                    },
                ],
                egowhip: [
                    {
                        range: [10, 59],
                        result: 'I',
                        description: 'Idiocy, psionic ability lost forever, though idiocy is curable by a heal spell',
                    },
                    {
                        range: [60, 109],
                        result: 'I',
                        description: 'Idiocy, psionic ability lost forever, though idiocy is curable by a heal spell',
                    },
                    {
                        range: [110, 159],
                        result: 'P',
                        description:
                            'Permanent loss of one attack or defense mode or psionic discipline, and dazed for 1-4 turns',
                    },
                    { range: [160, 209], result: 40 },
                    { range: [210, 259], result: 35 },
                    { range: [260, 309], result: 30 },
                    { range: [310, Infinity], result: 25 },
                ],
                idinsinuation: [
                    {
                        range: [10, 59],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    {
                        range: [60, 109],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    {
                        range: [110, 159],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    {
                        range: [160, 209],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    {
                        range: [210, 259],
                        result: 'R',
                        description: 'Robot, meaning mind is under control of the victor until released or 2-8 weeks pass',
                    },
                    { range: [260, 309], result: 40 },
                    { range: [310, Infinity], result: 35 },
                ],
                psychiccrush: [
                    { range: [10, 59], result: 97 },
                    { range: [60, 109], result: 80 },
                    { range: [110, 159], result: 70 },
                    { range: [160, 209], result: 60 },
                    { range: [210, 259], result: 50 },
                    { range: [260, 309], result: 40 },
                    { range: [310, Infinity], result: 30 },
                ],
            },
        },
    ],

    // IV.C. SAVES - PSIONIC BLAST ATTACK UPON NON-PSIONIC CREATURE, dmg pg. 78
    psionicBlastNonPsionicTable: [
        { range: [0, 5], result: { short: 20, medium: 19, long: 18 } },
        { range: [6, 9], result: { short: 18, medium: 17, long: 16 } },
        { range: [10, 13], result: { short: 16, medium: 15, long: 14 } },
        { range: [14, 17], result: { short: 14, medium: 13, long: 12 } },
        { range: [18, 21], result: { short: 12, medium: 11, long: 10 } },
        { range: [22, 25], result: { short: 10, medium: 9, long: 8 } },
        { range: [26, 29], result: { short: 8, medium: 7, long: 6 } },
        { range: [30, 33], result: { short: 6, medium: 5, long: 4 } },
        { range: [34, 35], result: { short: 4, medium: 3, long: 2 } },
        { range: [36, 37], result: { short: 2, medium: 1, long: 0 } },
        { range: [38, Infinity], result: { short: 0, medium: -1, long: -2 } },
    ],

    // IV.C. RESULTS - PSIONIC BLAST ATTACK UPON NON-PSIONIC CREATURE, dmg pg. 78 - horrible organization as per usual
    psionicAttackPercentageTable: [
        {
            range: [0, 5],
            result: [
                { range: [1, 85], result: 'death' },
                { range: [86, 99], result: 'coma' },
                { range: [100, 100], result: 'sleep' },
            ],
        },
        {
            range: [6, 9],
            result: [
                { range: [1, 10], result: 'death' },
                { range: [11, 90], result: 'coma' },
                { range: [91, 99], result: 'sleep' },
                { range: [100, 100], result: 'stun' },
            ],
        },
        {
            range: [10, 13],
            result: [
                { range: [1, 1], result: 'death' },
                { range: [2, 15], result: 'coma' },
                { range: [16, 90], result: 'sleep' },
                { range: [91, 99], result: 'stun' },
                { range: [100, 100], result: 'confuse' },
            ],
        },
        {
            range: [14, 17],
            result: [
                { range: [1, 1], result: 'coma' },
                { range: [2, 10], result: 'sleep' },
                { range: [11, 90], result: 'stun' },
                { range: [91, 99], result: 'confuse' },
                { range: [100, 100], result: 'enrage' },
            ],
        },
        {
            range: [18, 21],
            result: [
                { range: [1, 1], result: 'sleep' },
                { range: [2, 15], result: 'stun' },
                { range: [16, 90], result: 'confuse' },
                { range: [91, 99], result: 'enrage' },
                { range: [100, 100], result: 'panic' },
            ],
        },
        {
            range: [22, 25],
            result: [
                { range: [1, 1], result: 'stun' },
                { range: [2, 15], result: 'confuse' },
                { range: [16, 90], result: 'enrage' },
                { range: [91, 99], result: 'panic' },
                { range: [100, 100], result: 'feeblemind' },
            ],
        },
        {
            range: [26, 29],
            result: [
                { range: [1, 1], result: 'confuse' },
                { range: [2, 15], result: 'enrage' },
                { range: [16, 90], result: 'panic' },
                { range: [91, 99], result: 'feeblemind' },
                { range: [100, 100], result: 'permanentInsanity' },
            ],
        },
        {
            range: [30, 33],
            result: [
                { range: [1, 1], result: 'enrage' },
                { range: [2, 15], result: 'panic' },
                { range: [16, 90], result: 'feeblemind' },
                { range: [91, 99], result: 'permanentInsanity' },
                { range: [100, 100], result: 'temporaryInsanity' },
            ],
        },
        {
            range: [34, 35],
            result: [
                { range: [1, 1], result: 'panic' },
                { range: [2, 20], result: 'feeblemind' },
                { range: [21, 85], result: 'permanentInsanity' },
                { range: [86, 99], result: 'temporaryInsanity' },
                { range: [100, 100], result: 'mildInsanity' },
            ],
        },
        {
            range: [36, 37],
            result: [
                { range: [1, 1], result: 'feeblemind' },
                { range: [2, 15], result: 'permanentInsanity' },
                { range: [16, 90], result: 'temporaryInsanity' },
                { range: [91, 100], result: 'mildInsanity' },
            ],
        },
        {
            range: [38, Infinity],
            result: [
                { range: [1, 1], result: 'permanentInsanity' },
                { range: [2, 15], result: 'temporaryInsanity' },
                { range: [16, 100], result: 'mildInsanity' },
            ],
        },
    ],
};

// #endregion

import { ARS } from '../config.js';
import * as debug from '../debug.js';
import * as utilitiesManager from '../utilities.js';

/**
 *
 * Action Management
 *
 * Actions are objects on Item or Actors that are a
 * flexible system used to cast/melee/range/damage/heal/effects
 *
 *
 */
import { ActionSheet } from '../apps/action-sheet.js';

/**
 *
 * This really isnt a prepareDerivedData but the idea works
 *
 * @param {*} object
 */
export function prepareDerivedData(object) {
    new Promise((resolve, reject) => {
        buildActionGroups(object, (object.system.actionList = {}));
        resolve();
    }).then(() => {
        // this counts how many inventory actions we have across all items for
        // the combat-hud layout
        if (['character', 'npc'].includes(object.type)) {
            const inventoryActions = (items) => {
                let itemCount = 0;
                items.forEach((item) => {
                    // if (item.system.actionCount) {
                    //     console.log(`action.js prepareDerivedData ${object.name}: item ${item.name} has ${item.system.actionCount}`)
                    // }
                    itemCount += item.system.actionCount;
                });
                return itemCount;
            };
            // object.system.itemActionCount = inventoryActions(object.items.filter(function (item) {
            //     return item.system?.location?.state === 'equipped' || item.system?.location?.state === 'carried'
            // }));
            // object.system.itemActionCount = inventoryActions(object.items);
            object.system.itemActionCount = inventoryActions(object.actionInventory);
        }

        object.system?.actions?.forEach((action) => {
            action.parentuuid = object.uuid;
            // add in a escaped tooltip to display
            if (action?.effect?.changes) {
                // action.effect.toolTip = encodeURIComponent(action.effect.changes.map(change => `[${change.key}/${change.value}]`).join(', '));
                let tooltip = action.effect.changes.map((change) => `(${change.key}/${change.value})`).join(', ');
                if (tooltip) {
                    // these because foundry tries to parse our a dice roll so we stop it in tooltip
                    // tooltip = tooltip.replace(/(\[\[)/, '[');
                    // tooltip = tooltip.replace(/(\]\])/, ']');
                    tooltip = tooltip.replace(/[\[\[\]\]]/g, '');
                }
                action.effect.toolTip = tooltip;
            }
        });
    });

    // console.log("action.js prepareDerivedData", { object })
    // console.log("action.js prepareDerivedData", object.system.actionList)
}

/**
 *
 *
 * This allows us to have have the actions in groups that are by name.
 * So I can then reference them by the group when pulling them into dice/chatCards.
 *
 * Right now this requires a lot of "index" reorganizing. test out using object/key instead at somepoint?
 *
 * @param {*} object
 * @param {*} data
 */
export function buildActionGroups(object, data) {
    // console.log("action.js buildActionGroups", { object, game });
    let actor = object.actor;
    if (!game.user.isDM && object.documentName === 'Item' && !object.isIdentified) {
        object.system.actionCount = 0;
        return data;
    }
    if (object.documentName === 'Actor') {
        actor = object;
    }

    const groupList = new Array();
    if (object.system.actions?.length) {
        object.system.actions.forEach((action) => {
            let hasUses = -1;
            if (actor) {
                if (action.resource.type !== 'none') {
                    hasUses = utilitiesManager.getActionCharges(actor, object.documentName === 'Item' ? object : actor, action);
                }
            }
            if (!groupList[action.name]) {
                groupList[action.name] = {
                    name: action.name,
                    hasMelee: false,
                    hasCast: false,
                    hasDamage: false,
                    hasResource: action.resource?.type !== 'none',
                    hasUses: hasUses,
                };
            }

            if (groupList[action.name]) {
                if (action.type === 'cast' && !groupList[action.name].hasCast) groupList[action.name].hasCast = true;
                if (action.type === 'melee' && !groupList[action.name].hasMelee) groupList[action.name].hasMelee = true;
                if (['damage', 'heal'].includes(action.type) && !groupList[action.name].hasDamage)
                    groupList[action.name].hasDamage = true;
            }
        });

        Object.values(groupList).forEach((entry) => {
            const actionList = object.system.actions.filter((action) => {
                return action.name === entry.name;
            });

            const tag = entry.name ? entry.name.slugify({ strict: true }) : undefined;

            const collapsedState = object.getFlag('ars', `actions.${entry.name}.display.collapsedState`) || 'none';

            data[entry.name] = {
                // id: foundry.utils.randomID(16),
                tag: tag,
                img: actionList[0]?.img ?? 'icons/svg/d20-grey.svg',
                source: object,
                collapsedState: collapsedState ? collapsedState : 'none',
                actions: actionList,
                description: actionList
                    .filter((action) => {
                        return action.description ? action.description : false;
                    })
                    .map((c) => c.description)
                    .join('<p/>'),
                data: entry,
            };
        });
    }

    // console.log("action.js buildActionGroups", { object, groupList }, object?.name, Object.values(groupList).length)
    object.system.actionCount = Object.values(groupList).length;
    return data;
}

/**
 * Get the .actions objects on this object and return them
 *
 * @param {Object} object
 */
export function getActions(object) {
    // console.log("action.js getActions", { object });
    let actionBundle = foundry.utils.deepClone(foundry.utils.getProperty(object, 'system.actions') || []);
    return Object.values(actionBundle);
}

/**
 *
 * Get a single action in object at index actionId
 *
 * @param {Object} object  Actor/Item
 * @param {Number} actionId Index of action to retreive
 */
export function getAction(object, actionId) {
    // console.log("action.js getAction", { object, actionId });
    return getActions(object)[actionId];
}
/**
 *
 * Set the .actions objects to new value using actionBundle as source on object
 *
 * @param {Object} object
 * @param {Object} actionBundle
 */
export async function setActions(object, actionBundle) {
    // console.log("action.js setActions", { object, actionBundle });
    return await object.update({ 'system.actions': actionBundle });
}

/**
 *
 * This reindexes the actionBundle to take into account moves/removals/etc to maintain ordering
 *
 * @param {*} actionBundle
 */
export function reIndexActions(actionBundle) {
    let index = 0;
    actionBundle.forEach((action) => {
        action.index = index;
        index++;
    });
}
/**
 *
 * Manage action entries for Item or Actor
 *
 * @param {Object} object Item or Actor
 * @param {Number} index  The index number of the action to manipulate
 * @param {String} actionToPerform The action to be performed, create, moveup (action order), movedown, edit or delete.
 */
export async function onManage_action(object, actionToPerform = 'create', { index, actionId = '', actionGroup = '' }) {
    console.log('action.js onManage_action', {
        object,
        index,
        actionToPerform,
        actionId,
        actionGroup,
    });

    let updatedActions = false;
    if (actionToPerform === 'edit') {
        const actionSheet = new ActionSheet(object, { actionId: index }).render(true);
    } else {
        let actionBundle = getActions(object);
        switch (actionToPerform) {
            case 'view-source':
                if (object.sheet) object.sheet.render(true);
                break;

            case 'create':
                let action = createActionEntry(object, actionBundle.length, actionGroup);
                actionBundle.push(action);
                updatedActions = true;
                break;

            case 'moveup':
                if (index > 0) {
                    const sourceAction = actionBundle.find((action) => action.id === actionId);
                    for (let i = index - 1; i >= 0; i--) {
                        if (actionBundle[i].name === sourceAction.name && actionBundle[i].id !== sourceAction.id) {
                            const moveThis = actionBundle[i];
                            actionBundle[i] = sourceAction;
                            actionBundle[index] = moveThis;
                            reIndexActions(actionBundle);
                            updatedActions = true;
                            break;
                        }
                    }
                }
                break;

            case 'movedown':
                if (index < actionBundle.length - 1) {
                    //
                    const sourceAction = actionBundle.find((action) => action.id === actionId);
                    for (let i = parseInt(index) + 1; i < actionBundle.length; i++) {
                        if (actionBundle[i].name === sourceAction.name && actionBundle[i].id !== sourceAction.id) {
                            const moveThis = actionBundle[i];
                            actionBundle[i] = sourceAction;
                            actionBundle[index] = moveThis;
                            reIndexActions(actionBundle);
                            updatedActions = true;
                            break;
                        }
                    }
                }
                break;

            case 'edit':
                // should never get here.
                break;

            case 'delete':
                actionBundle.splice(index, 1);
                reIndexActions(actionBundle);
                updatedActions = true;
                break;
        }
        if (updatedActions) {
            return await setActions(object, actionBundle);
        }
        return null;
    }
}

/**
 *
 * Create action at index
 *
 * @param {Object} object Actor/Token
 * @param {Number} index  Max size of the current actionBundle array for indexing
 * @param {String} actionGroup ActionGroup name for display grouping
 * @returns
 */
export function createActionEntry(object, index, actionGroup = '') {
    let action = foundry.utils.duplicate(game.ars.templates['action']);
    // if (action.templates instanceof Array) {
    //     action.templates.forEach((t) => {
    //         action = foundry.utils.mergeObject(action, game.ars.templates.templates[t]);
    //     });
    // }

    // add save and ability check templates into action as well, will be action[x].save/action[x].abilityCheck
    action = foundry.utils.mergeObject(action, game.ars.templates['saveCheck']);
    action = foundry.utils.mergeObject(action, game.ars.templates['castShapeProperties']);
    action = foundry.utils.mergeObject(action, game.ars.templates['abilityCheck']);
    if (!action.id) {
        action.id = foundry.utils.randomID(16);
    }
    delete action.templates;
    let actionName = 'unknown';
    if (actionGroup) {
        actionName = actionGroup;
    } else if (object && object.name) {
        actionName = object.name;
    }
    action.index = index;
    action.name = actionName;
    // set the default image on action if object unset, to "cast" as it's the default new action type.
    let actionImg = ARS.icons.general.combat.cast;
    if (object && object.img) {
        actionImg = object.img;
    }
    action.img = actionImg;

    return action;
}

/**
 *
 * Create actions for token from damageList
 *
 * @param {Object} token  token object
 * @param {Array} damageList Array of damage strings ['1d6','1d4+2']
 *
 */
export async function createActionForNPCToken(token, damageList, actionName = 'Attack') {
    // console.log("createActionForNPCToken", { token, damageList, actionName });
    if (damageList && damageList.length) {
        // console.log("createActionForNPCToken:START");
        let actionBundle = Object.values(
            foundry.utils.deepClone(foundry.utils.getProperty(token.actor, 'system.actions') || [])
        );

        createActionFromDamage(token.actor, damageList, actionBundle, actionName);

        // token.update({ "actorData.system.actions": actionBundle });
        token.actor.update({ 'system.actions': actionBundle });
    }
}
/**
 *
 * Create actions for actor from damageList
 *
 * @param {Object} actor
 * @param {Array/object} damageList
 * @param {String} actionName
 */
export async function createActionForActor(actor, damageList, actionName = 'Attack') {
    // console.log("createActionForActor", { actor, damageList, actionName });
    if (damageList && damageList.length) {
        let actionBundle = Object.values(foundry.utils.deepClone(foundry.utils.getProperty(actor, 'system.actions') || []));

        createActionFromDamage(actor, damageList, actionBundle, actionName);

        await actor.update({ 'system.actions': actionBundle });
    }
}

/**
 *
 * Create a actions array for a imports npc only using a bundle.
 *
 * @param {Array} actionBundle
 * @param {Array/Object} damageList
 * @param {String} actionName
 * @returns
 */
export async function createActionForActionBundle(actionBundle, damageList, actionName = 'Attack', actionSpeed = 0) {
    // console.log("createActionForActionBundle", { actionBundle, damageList, actionName });
    if (damageList && damageList.length) {
        createActionFromDamage(null, damageList, actionBundle, actionName, actionSpeed);
        return actionBundle;
    }
}
/**
 *
 * Helper to create actions for simple damagelist/name and dmgType
 *
 * @param {Actor|Token} object
 * @param {Array} damageList
 * @param {DataBundle} actionBundle
 * @param {String} actionName
 * @returns
 */
function createActionFromDamage(object, damageList, actionBundle, actionName = 'Attack', actionSpeed = 0) {
    // console.log("createActionFromDamage", { object, damageList, actionBundle, actionName });
    // create "attack" action first, default to melee/str based
    let action = createActionEntry(object, actionBundle.length);
    action.name = actionName;
    action.speed = actionSpeed;
    action.type = 'melee';
    action.ability = 'none';
    action.abilityCheck.type = 'none';
    action.saveCheck.type = 'none';
    action.img = ARS.icons.general.combat[action.type];
    actionBundle.push(action);

    const _actionDamage = (dmg, dmgType = 'slashing') => {
        let actionDamage;
        // console.log("createActionFromDamage", { object, dmg, actionBundle });
        // console.log("createActionFromDamage:dmg", dmg);
        if (dmg) {
            actionDamage = createActionEntry(object, actionBundle.length);
            let diceString = '';
            try {
                const match = dmg?.match(/^(\d+[\-]\d+$)/) || null;
                if (match && match[1]) diceString = match[1];
            } catch (err) {}

            if (diceString) {
                // diceString = utilitiesManager.diceFixer(diceString[0]);
                diceString = utilitiesManager.diceFixer(diceString);
            } else {
                diceString = dmg;
            }

            actionDamage.name = actionName;
            actionDamage.damagetype = dmgType;
            actionDamage.type = 'damage';
            actionDamage.ability = 'none';
            actionDamage.formula = diceString;
            actionDamage.abilityCheck.type = 'none';
            actionDamage.saveCheck.type = 'none';
            actionDamage.img = ARS.icons.general.combat[action.type];
        } else {
            // console.log("createActionFromDamage", { object, dmg, actionBundle });
        }
        return actionDamage;
    };

    // create damage entries for each valid damage dice we find in string
    damageList.forEach((entry) => {
        if (entry.dmg) {
            actionBundle.push(_actionDamage(entry.dmg, entry.dmgType));
        } else {
            actionBundle.push(_actionDamage(entry));
        }
    });

    return actionBundle;
}

/**
 *
 * pre-calculate formulas for tooltips/visual information
 *
 * @param {*} object
 * @param {*} actions
 */
export async function populateFormulaEvals(object, actions) {
    // console.log("action.js populateFormulaEvals", { object, actions }, object.documentName);
    if (actions) {
        let rollData = object.getRollData();
        if (object.documentName === 'Item' && object.isOwned) {
            rollData = object.actor.getRollData();
        }
        for (const action of actions) {
            if (action.formula) {
                try {
                    let roll = new Roll(action.formula, rollData);
                    await roll.evaluate();
                    action.formulaEvaluated = roll.formula;
                } catch (err) {
                    console.error(`action.js populateFormulaEvals error ${err}`, {
                        object,
                        action,
                        rollData,
                    });
                    action.formulaEvaluated = action.formula;
                }
            }
        }
    }
}

/**
 * Copies actions from a source object to a target object.
 * @param {Object} object - The target object to copy actions to.
 * @param {Object} sourceObject - The source object to copy actions from.
 */
export async function copyActionsToObject(object, sourceObject, actionGroup = undefined) {
    // console.log("action.js copyActionsToObject", { object, sourceObject });

    // Check if the source object has actions
    if (sourceObject.system.actions) {
        const actionBundle = getActions(object);

        // Iterate through each action in the source object
        sourceObject.system.actions.forEach((action, index) => {
            if (!actionGroup || (actionGroup && action.name === actionGroup)) {
                const copiedAction = foundry.utils.deepClone(action);

                // If this is the first action or a charged action, add extra information from the source object
                if (index == 0 || ARS.chargedActions.includes(action.type)) {
                    // Add extra spell notes for objects of type 'spell'
                    let preDescriptionText = '';
                    if (sourceObject.type === 'spell') {
                        function createLine(property, label) {
                            return property ? `${label}: ${property}<p />` : '';
                        }

                        const lines = [
                            createLine(sourceObject.system.type, 'Type'),
                            createLine(sourceObject.system.school, 'School'),
                            createLine(sourceObject.system.sphere, 'Sphere'),
                            createLine(sourceObject.system.level, 'Level'),
                            createLine(sourceObject.system.castingTime, 'Cast Time'),
                            createLine(sourceObject.system.range, 'Range'),
                            createLine(sourceObject.system.durationText, 'Duration'),
                            createLine(sourceObject.system.save, 'Save'),
                            createLine(sourceObject.system.areaOfEffect, 'AOE'),
                        ];

                        // Add components information if any of the components exist
                        if (
                            sourceObject.system.components.verbal ||
                            sourceObject.system.components.somatic ||
                            sourceObject.system.components.material
                        ) {
                            lines.push(
                                `Components: ${sourceObject.system.components.verbal ? 'V' : ''}${
                                    sourceObject.system.components.somatic ? 'S' : ''
                                }${sourceObject.system.components.material ? 'M' : ''}<p />`
                            );
                        }

                        preDescriptionText = lines.join('');
                    } // end spell type

                    // Combine preDescriptionText, source object description, and action description
                    copiedAction.description =
                        (preDescriptionText ? preDescriptionText : '') +
                        sourceObject.system.description +
                        (action.description ? action.description : '');
                    copiedAction.img = sourceObject.img || '';
                }
                actionBundle.push(copiedAction);
            }
        });

        // Re-index actions and set the actions for the target object
        reIndexActions(actionBundle);
        await setActions(object, actionBundle);
    }
}

/**
 *
 * Toggle action group view state collapsed or full
 *
 * The is a set/getFlag setting stored on the object with actions and as map it to the name of the action group
 *
 * @param {*} event
 */
export async function toggleActionView(event) {
    // console.log("action.js toggleActionView", { event })

    const element = event.currentTarget;
    // const dataset = element.dataset;
    const li = element.closest('li');
    // const actionGroup = li.dataset.actionGroup;
    const sourceUuid = li.getAttribute('data-source-uuid');
    const sourceObject = await fromUuid(sourceUuid);

    const actionGroup = li.getAttribute('data-action-group');

    const source = sourceObject.documentName === 'Token' ? sourceObject.actor : sourceObject;

    const dataKey = `viewState.${source.id}.collapsedState`;
    const collapsedState = source.getFlag('ars', `actions.${actionGroup}.display.collapsedState`) || 'none';
    // const collapsedState = game.user.getFlag('ars', dataKey) || 'none';
    const newState = collapsedState === 'none' ? 'block' : 'none';
    source.setFlag('ars', `actions.${actionGroup}.display.collapsedState`, newState);
    game.user.setFlag('ars', dataKey, newState);

    // console.log("action.js toggleActionView", { element, dataset, li, sourceUuid, sourceObject, source, collapsedState, newState })
}

/**
 *
 * Common function used when starting to drag an action.
 *
 * @param {*} event
 */
export function onDragStart(event) {
    if (!event || !event.target || !event.dataTransfer) {
        console.error('onDragStart: Invalid event or missing event properties.');
        return;
    }
    console.log('action.js _onDragStart', { event });
    event.stopPropagation();
    const element = event.target;
    const listItem = element.closest('li');
    if (!listItem) {
        console.error('onDragStart: Failed to find the closest list item.');
        return;
    }
    const sourceUuid = listItem.getAttribute('data-source-uuid');
    const actionGroup = listItem.getAttribute('data-action-group');
    if (!sourceUuid || !actionGroup) {
        console.error('onDragStart: Missing necessary data attributes.');
        return;
    }
    console.log('action.js _onDragStart', { element, actionGroup, sourceUuid });
    const dragData = {
        type: 'Action',
        uuid: sourceUuid,
        actionGroup,
    };
    console.log('action.js _onDragStart', { dragData });
    event.dataTransfer.setData('text/plain', JSON.stringify(dragData));
    // const img = ARS.icons.general.actions.default;
    // const preview = DragDrop.createDragImage(img, 20, 20);
    // event.dataTransfer.setDragImage(preview, 10, 10);
}

/**
 * Handles drop events for adding spells or actions to an actor.
 * Validates inputs and parses drag data safely, supporting extensibility and error management.
 *
 * @param {DragEvent} event The drop event.
 * @param {Object} object The target object to copy actions to.
 */
export async function onDropAction(event, object) {
    // Abstracted action types for better maintainability and readability.
    const ActionType = {
        ITEM: 'Item',
        ACTION: 'Action',
    };

    // Handles dropping of 'Item' type data.
    async function handleItemDrop(data, object) {
        const item = await fromUuid(data.uuid);
        if (item && item.type === 'spell') {
            copyActionsToObject(object, item);
        } else {
            console.warn('handleItemDrop: Dropped item is not a spell or failed to fetch.');
        }
    }

    // Handles dropping of 'Action' type data.
    async function handleActionDrop(data, object) {
        const actionGroup = data.actionGroup;
        const item = await fromUuid(data.uuid);
        if (item) {
            copyActionsToObject(object, item, actionGroup);
        } else {
            console.warn('handleActionDrop: Failed to fetch item for action.');
        }
    }

    if (!event || !object) {
        console.error('onDropAction: Invalid event or target object.');
        return;
    }

    event.preventDefault();
    let data;

    try {
        const dataTransfer = event.originalEvent.dataTransfer;
        const jsonData = dataTransfer.getData('text/plain');
        data = JSON.parse(jsonData);
    } catch (error) {
        console.error('onDropAction: Error parsing drag data.', error);
        return;
    }

    if (!data || !data.type || !data.uuid) {
        console.error('onDropAction: Drag data is missing required fields.');
        return;
    }

    event.stopPropagation();

    try {
        switch (data.type) {
            case ActionType.ITEM:
                await handleItemDrop(data, object);
                break;
            case ActionType.ACTION:
                await handleActionDrop(data, object);
                break;
            default:
                console.warn(`onDropAction: Unsupported data type '${data.type}'.`);
        }
    } catch (error) {
        console.error(`onDropAction: Error handling drop action for type '${data.type}'.`, error);
    }
}

// export class ARSActionData {
//     static defineSchema() {
//         const fields = foundry.data.fields;
//         return {
//             img: new fields.StringField({ default: 'icons/weapons/staves/staff-ornate-red.webp' }),
//             ability: new fields.StringField({ default: 'none' }),
//             castShapeAngle: new fields.ObjectField({
//                 formula: new fields.StringField({ default: '' }),
//             }),
//             castShapeLength: new fields.ObjectField({
//                 formula: new fields.StringField({ default: '' }),
//             }),
//             castShapeRadius: new fields.ObjectField({
//                 formula: new fields.StringField({ default: '' }),
//             }),
//             castShapeWidth: new fields.ObjectField({
//                 formula: new fields.StringField({ default: '' }),
//             }),
//             castShapeProperties: new fields.ObjectField({
//                 structure: {
//                     castShapeRadius: new fields.ObjectField({
//                         formula: new fields.StringField({ default: '' }),
//                     }),
//                     range: new fields.ObjectField({
//                         formula: new fields.StringField({ default: '' }),
//                     }),
//                     inRangeColor: new fields.StringField({ default: '#f2ed69' }),
//                     outOfRangeColor: new fields.StringField({ default: '#a80000' }),
//                 },
//             }),
//             type: new fields.StringField({ default: 'cast' }),
//             targeting: new fields.StringField({ default: '' }),
//             targetShape: new fields.ObjectField({
//                 type: new fields.StringField({ default: 'circle' }),
//             }),
//             targetShapeSelection: new fields.ObjectField({
//                 type: new fields.StringField({ default: 'all' }),
//             }),
//             successAction: new fields.StringField({ default: '' }),
//             formula: new fields.StringField({ default: '' }),
//             otherdmg: new fields.ArrayField({ elementType: new fields.StringField() }),
//             effectList: new fields.ArrayField({ elementType: new fields.StringField() }),
//             effect: new fields.ObjectField({
//                 duration: new fields.ObjectField({
//                     formula: new fields.StringField({ default: '' }),
//                     type: new fields.StringField({ default: 'round' }),
//                 }),
//                 changes: new fields.ArrayField({ elementType: new fields.StringField() }),
//             }),
//             // itemList: new fields.ArrayField({ elementType: new fields.StringField() }),
//             speed: new fields.IntegerField({ default: 0 }),
//             damagetype: new fields.StringField({ default: 'slashing' }),
//             dmonlytext: new fields.StringField({ default: '' }),
//             resource: new fields.ObjectField({
//                 type: new fields.StringField({ default: 'none' }),
//                 itemId: new fields.StringField({ default: '' }),
//                 reusetime: new fields.StringField({ default: '' }),
//                 count: new fields.ObjectField({
//                     cost: new fields.IntegerField({ default: 1 }),
//                     min: new fields.IntegerField({ default: 0 }),
//                     max: new fields.IntegerField({ default: 1 }),
//                     value: new fields.IntegerField({ default: 0 }),
//                 }),
//             }),
//             parentuuid: new fields.StringField({ default: '' }),
//             magicpotency: new fields.IntegerField({ default: 0 }),
//             misc: new fields.StringField({ default: '' }),
//             properties: new fields.ArrayField( new fields.StringField() ),
//             saveCheck: new fields.ObjectField({
//                 formula: new fields.StringField({ default: '' }),
//                 type: new fields.StringField({ default: 'spell' }),
//             }),
//         };
//     }
// }

import * as debug from '../debug.js';

/**
 * Class for token-hud
 *
 */

export class ARSCombatHUD extends Application {
    constructor(token, options = {}) {
        super(options);
        this.token = token;
        this.actor = token.actor;
        token.actor.apps[this.appId] = this;

        console.log('token-hud-class.js CREATED');
    } // end constructor

    /** @override */
    // static documentName = 'ARSCombatHUD';

    /** @override */
    static get defaultOptions() {
        return foundry.utils.mergeObject(super.defaultOptions, {
            // id: randomID(16),
            classes: ['ars'],
            template: 'systems/ars/templates/apps/combat-hud-mini.hbs',
            title: 'Combat HUD',
            height: 'auto',
            width: 600,
            resizable: true,
        });
    } // end defaultOptions

    get id() {
        return `ars-combat-hud-${this.token.id}`;
    }
    get title() {
        const move =
            this.actor.type === 'npc'
                ? this.actor.system.movement
                : `${this.actor.system.attributes.movement.value} ${this.actor.system.attributes.movement.unit}`;

        return `${this.actor.name}, AC:${this.actor.system.armorClass.normal} / HP:${this.actor.system.attributes.hp.value} / MV:${move}`;
    }

    getData() {
        const context = {
            token: this.token,
            actor: this.actor,
            system: this.actor.system,
            actions: this.actor.system.actions,
            actionList: this.actor.system.actionList,
            actionCount: Object.keys(this.actor.system.actionList).length,
        };

        return context;
    } // end getData

    activateListeners(html) {
        super.activateListeners(html);

        //listeners for button clicks
        // weapon/skills
        // Attach click event listeners to elements with the 'chatCard-roll' class
        const chatCardRoll = html.find('.chatCard-roll');
        chatCardRoll.each((i, chatCard) => {
            chatCard.addEventListener('click', (event) => {
                // Assuming `_itemChatRoll` is a method on this.actor.sheet that handles the event
                this.actor.sheet._itemChatRoll.bind(this.actor.sheet)(event);
            });
        });

        // Attach click event listeners to elements with the 'spellCard-roll' class
        const spellCardRoll = html.find('.spellCard-roll');
        spellCardRoll.each((i, spellCard) => {
            $(spellCard).on('click', (event) => {
                this.actor.sheet._itemChatRoll.bind(this.actor.sheet)(event);
            });
        });

        // Attach click event listeners to elements with the 'actionCard-roll' class
        const actionCardRoll = html.find('.actionCard-roll');
        actionCardRoll.each((i, actionCard) => {
            $(actionCard).on('click', (event) => {
                this.actor.sheet._actionChatRoll.bind(this.actor.sheet)(event);
            });
        });
    } // end activateListeners

    createHud() {
        const token = this.token;
        const actor = this.actor;
        if (!actor || (!actor.isOwner && !game.user.isGM)) return;

        // position the hud below the selected token
        const viewportWidth = document.documentElement.clientWidth;
        const viewportHeight = document.documentElement.clientHeight;

        let hudTopPosition,
            hudLeftPostion,
            hudWidth = this?.position?.width || 600;
        if (game.settings.get('ars', 'floatingHudStaticPosition')) {
            const hudBottomOffset = 100;
            const element = document.getElementById('ui-bottom');
            const position = element.getBoundingClientRect();

            hudTopPosition = position.top - hudBottomOffset;
            hudLeftPostion = position.left;
            let hudTop = undefined,
                hudLeft = undefined;
            const saveKey = `${game.user.id}-token-hud-location`;
            try {
                [hudTop, hudLeft, hudWidth] = JSON.parse(localStorage.getItem(saveKey));
            } catch (err) {}

            if (!hudWidth) hudWidth = this?.position?.width || 600;
            // console.log('OPENING.....localStorage', { hudTop, hudLeft });

            if (hudTop || hudLeft) {
                // if previous setting is good, we use it, otherwise we use default
                if (hudLeft > 0 && hudLeft < viewportWidth && hudTop < viewportHeight) {
                    hudTopPosition = hudTop;
                    hudLeftPostion = hudLeft;
                }
            }
        } else {
            const tokenWidth = Math.round(token.w * canvas.stage.scale.x),
                tokenHeight = Math.round(token.h * canvas.stage.scale.y),
                left = Math.round(token.worldTransform.tx),
                top = Math.round(token.worldTransform.ty),
                right = left + tokenWidth,
                bottom = top + tokenHeight;

            const tokenHudOffset = 35;
            hudTopPosition = bottom + tokenHudOffset;
            hudLeftPostion = left;

            //to far down
            if (bottom + tokenHudOffset > viewportHeight) {
                hudTopPosition = top + tokenHudOffset;
            }
            //to far left
            if (left < 0) {
                hudLeftPostion = right;
            }
            //to far right
            if (left + 100 > viewportWidth) {
                hudLeftPostion = Math.round(viewportWidth / 2);
            }
        }
        // console.log('OPENING.....WINDOW', { hudLeftPostion, hudTopPosition });
        this.element.css({ left: hudLeftPostion, top: hudTopPosition });
        // this.setPosition({ left: hudLeftPostion, top: hudTopPosition, height: 'auto', width: 600, zIndex: 100, scale: 1 });
        this.position.left = hudLeftPostion;
        this.position.top = hudTopPosition;
        this.position.width = hudWidth;

        this.render(true);
        return this;
    } // end createHud

    #saveWindowPosition() {
        if (this.rendered) {
            const windowX = this.position.left;
            const windowY = this.position.top;
            const windowW = this.position.width;

            // console.log('Saving Window Position...', { windowX, windowY }, this.position);
            const saveKey = `${game.user.id}-token-hud-location`;
            localStorage.setItem(saveKey, JSON.stringify([windowY, windowX, windowW]));
        }
    }

    close() {
        this.#saveWindowPosition();
        super.close();
    }

    closeHud() {
        delete this.token.actor.apps[this.appId];
        this.close();
    }
}

import * as debug from '../debug.js';
import { prepareActiveEffectCategories } from '../effect/effects.js';
import * as utilitiesManager from '../utilities.js';
import { isControlActive, isAltActive, isShiftActive } from '../utilities.js';

/**
 * Class for Combat Hud
 *
 */

export class ARSCombatHUD extends Application {
    constructor(token, options = {}) {
        super(options);
        this.token = token;
        this.actor = token.actor;
        this.combatant = this?.actor?.combatant;
        this.combat = this?.actor?.combat;
        token.actor.apps[this.appId] = this;
        if (token.combatHud) this.#closepopoutCards();
        token.combatHud = this;
        token.popoutCards = [];
        this.autoClose = game.settings.get('ars', 'floatingHudAutoClose');
        this.options.id = `ars-combat-hud-${this.token.id}`;
        if (game.user.combatHuds == null) game.user.combatHuds = [];
        game.user.combatHuds.push(this);
    } // end constructor

    /** @override */
    // static documentName = 'ARSCombatHUD';

    /** @override */
    static get defaultOptions() {
        return foundry.utils.mergeObject(super.defaultOptions, {
            // id: foundry.utils.randomID(16),
            classes: ['ars', 'ars-combat-hud'],
            template: 'systems/ars/templates/apps/combat-hud-mini.hbs',
            title: 'Combat HUD',
            height: 'auto',
            width: 600,
            resizable: true,
            // id: `ars-combat-hud-${this.token.id}`,
            // scollY: ['ars-combat-hud'],
            dragDrop: [
                {
                    dragSelector: '.mini-weapon-list .mini-action-button',
                    dropSelector: null,
                },
                // { dragSelector: '.memorization-slot' },
                // { dragSelector: '.actionCard-roll .rollable', dropSelector: null },
            ],
            // dragDrop: [{ dropSelector: 'action-block' }],
        });
    } // end defaultOptions  d

    get id() {
        // const defaultId = game.user.isGM ? game.user.id : `ars-combat-hud-${this.token.id}`;
        return `ars-combat-hud-${this.token.id}`;
    }

    get title() {
        const move = this.actor.type === 'npc' ? this.actor.system.movement : `${this.actor.system.attributes.movement?.value}`;
        // : `${this.actor.system.attributes.movement.value} ${this.actor.system.attributes.movement.unit}`;

        return `${this.actor.name}, AC:${this.actor.system.armorClass?.normal || 10} / HP:${
            this.actor.system.attributes?.hp?.value
        } / MV:${move}`;
    }

    getData() {
        const effects = this.actor.getActiveEffects().filter((eff) => eff.isTemporary && eff.canSee);
        const context = {
            isGM: game.user.isGM,
            isDM: game.user.isDM,
            token: this.token,
            actor: this.actor,
            system: this.actor.system,
            actions: this.actor.system.actions,
            actionList: this.actor.system.actionList,
            actionCount: !foundry.utils.isEmpty(this.actor.system.actionList)
                ? Object.keys(this.actor.system?.actionList).length
                : 0,
            effects: effects,
            hasTempEffects: effects.length,
        };

        return context;
    } // end getData

    /**@override to add auto close toggle */
    _getHeaderButtons() {
        const buttons = super._getHeaderButtons();
        const autoCloseButton = {
            label: 'Auto-Close',
            hint: 'Close hud when token unselected',
            class: 'autoClose',
            icon: this.autoClose ? 'fas fa-check' : 'fas fa-ban',
            onclick: () => this.#toggleAutoClose(),
        };

        // Find the index of the "Close" button
        const closeButtonIndex = buttons.findIndex((button) => button.label === 'Close');

        // Insert the "Auto-Close" button before the "Close" button
        if (closeButtonIndex !== -1) {
            buttons.splice(closeButtonIndex, 0, autoCloseButton);
        } else {
            // If the "Close" button is not found, push the "Auto-Close" button to the end
            buttons.push(autoCloseButton);
        }
        return buttons;
    }

    activateListeners(html) {
        super.activateListeners(html);

        const btnMiniHud = html.find('.chatCard-roll, .spellCard-roll');
        // const btnMiniHudAction = html.find('.actionCard-roll');
        const btnActionCardRollV2 = html.find('.actionCard-rollV2');

        const hudInitiativeControl = html.find('.initiative-control');

        // // Actions...
        // btnMiniHudAction.click((e) => {
        //     this.actor.sheet._actionChatRoll.bind(this.actor.sheet)(e);
        // });

        // weapon/skills/spells...
        btnMiniHud.click((e) => {
            this.actor.sheet._itemChatRoll.bind(this.actor.sheet)(e);
        });

        btnActionCardRollV2.click((e) => {
            this.actor.sheet._actionChatRoll.bind(this.actor.sheet)(e);
        });

        /**
         * We assume these buttons are only visible when they should be.
         */
        hudInitiativeControl.click(async (event) => {
            const control = event.currentTarget;
            const type = control.getAttribute('data-control');
            const c = this?.actor?.combatant;
            const combat = this?.actor?.combat;
            // const turn = combat.turn;
            // const active = combat.turns[turn] == c;
            // console.log(
            //     `${this.token.name} has pressed hud initiative ${type}`,
            //     { control, type, c, combat },
            //     this.actor,
            //     this.token
            // );

            switch (type) {
                case 'nextTurn':
                    return await combat.nextTurn(c);
                // Roll combatant initiative
                case 'rollInitiative':
                    {
                        await utilitiesManager.rollCombatantInitiative(c, combat, isControlActive());
                        // refresh display to drop roll initiative indicator
                        this.render(true);
                    }
                    break;

                // delay turn to end of turn order +1
                case 'delayTurn':
                    const lastInit = combat._getLastInInitiative();
                    console.log('_onCombatantControl', { c, combat, lastInit }, c.id, combat.combatant.id);
                    if (c.id == combat.combatant.id) {
                        // if the combatant and this person are the same, flip to next turn
                        // and reset initiative to last +1
                        await combat.nextTurn(c);
                        return c.update({ initiative: lastInit + 1 });
                    }
                    break;
            }
        });
    } // end activateListeners

    /** toggle auto close option in header */
    #toggleAutoClose() {
        this.autoClose = !this.autoClose;
        const iconElement = this.element.find('.header-button.control.autoClose i');
        if (this.autoClose) {
            iconElement.removeClass('fa-ban').addClass('fa-check');
        } else {
            iconElement.removeClass('fa-check').addClass('fa-ban');
        }
    }

    _onDragStart(event) {
        console.log('combat-hud.js _onDragStart', { event });
        // const rootAttr = event.target.getAttribute('root');
        const itemId = event.target.getAttribute('data-id');
        console.log('combat-hud.js _onDragStart', { itemId });
        const item = this.actor.getEmbeddedDocument('Item', itemId);
        if (item) {
            console.log('combat-hud.js _onDragStart', { item });
            event.dataTransfer.setData(
                'text/plain',
                JSON.stringify({
                    type: 'Item',
                    actorId: this.actor.id,
                    actorUuid: this.actor.uuid,
                    id: item.id,
                    uuid: item.uuid,
                    macroData: {
                        type: item.type,
                        img: item.img,
                        name: item.name,
                    },
                })
            );
        }
    }

    _onDragDrop(event) {
        // console.log('combat-hud.js _onDragDrop', { event });
    }
    _canDragStart(event) {
        // console.log('combat-hud.js _canDragStart', { event });
        // return true;
        return false;
    }
    _canDragDrop(event) {
        // console.log('combat-hud.js _canDragDrop', { event });
        return false;
    }

    createHud() {
        const token = this.token;
        const actor = this.actor;
        if (!actor || (!actor.isOwner && !game.user.isGM)) return;

        // position the hud below the selected token
        const viewportWidth = document.documentElement.clientWidth;
        const viewportHeight = document.documentElement.clientHeight;

        let hudTopPosition,
            hudLeftPostion,
            hudWidth = this?.position?.width || 600;
        if (game.settings.get('ars', 'floatingHudStaticPosition')) {
            const hudBottomOffset = 100;
            const element = document.getElementById('ui-bottom');
            const position = element.getBoundingClientRect();

            hudTopPosition = position.top - hudBottomOffset;
            hudLeftPostion = position.left;
            let hudTop = undefined,
                hudLeft = undefined;
            const saveKey = `${game.user.id}-combat-hud-location`;
            try {
                [hudTop, hudLeft, hudWidth] = JSON.parse(localStorage.getItem(saveKey));
            } catch (err) {}

            if (!hudWidth) hudWidth = this?.position?.width || 600;
            // console.log('OPENING.....localStorage', { hudTop, hudLeft });

            if (hudTop || hudLeft) {
                // if previous setting is good, we use it, otherwise we use default
                if (hudLeft > 0 && hudLeft < viewportWidth && hudTop < viewportHeight) {
                    hudTopPosition = hudTop;
                    hudLeftPostion = hudLeft;
                }
            }
        } else {
            const tokenWidth = Math.round(token.w * canvas.stage.scale.x),
                tokenHeight = Math.round(token.h * canvas.stage.scale.y),
                left = Math.round(token.worldTransform.tx),
                top = Math.round(token.worldTransform.ty),
                right = left + tokenWidth,
                bottom = top + tokenHeight;

            const tokenHudOffset = 35;
            hudTopPosition = bottom + tokenHudOffset;
            hudLeftPostion = left;

            //to far down
            if (bottom + tokenHudOffset > viewportHeight) {
                hudTopPosition = top + tokenHudOffset;
            }
            //to far left
            if (left < 0) {
                hudLeftPostion = right;
            }
            //to far right
            if (left + 100 > viewportWidth) {
                hudLeftPostion = Math.round(viewportWidth / 2);
            }
        }
        // console.log('OPENING.....WINDOW', { hudLeftPostion, hudTopPosition });
        this.element.css({ left: hudLeftPostion, top: hudTopPosition });
        // this.setPosition({ left: hudLeftPostion, top: hudTopPosition, height: 'auto', width: 600, zIndex: 100, scale: 1 });
        this.position.left = hudLeftPostion;
        this.position.top = hudTopPosition;
        this.position.width = hudWidth;

        this.render(true);
        return this;
    } // end createHud

    #saveWindowPosition() {
        if (this.rendered) {
            const windowX = this.position.left;
            const windowY = this.position.top;
            const windowW = this.position.width;

            // console.log('Saving Window Position...', { windowX, windowY }, this.position);
            const saveKey = `${game.user.id}-combat-hud-location`;

            localStorage.setItem(saveKey, JSON.stringify([windowY, windowX, windowW]));
        }
    }

    #closepopoutCards() {
        // this will close any actions still opened from this hud that was opened when the hud was up.
        if (this?.token?.popoutCards?.length) {
            const removePopouts = foundry.utils.deepClone(this.token.popoutCards);
            for (let i = 0; i < removePopouts.length; i++) {
                const popout = removePopouts[i];
                popout.close();
            }
        }
    }

    async close() {
        const index = game.user.combatHuds.indexOf(this);
        if (index !== -1) {
            game.user.combatHuds.splice(index, 1);
        }

        this.#saveWindowPosition();

        // tweak to keep the card OPEN when placing a castshape template
        if (!window.preventCardClose) this.#closepopoutCards();

        // destroy temp variable from memory if it exists
        delete window.preventCardClose;

        delete this?.token?.actor?.apps?.[this.appId];
        delete this?.token?.combatHud;
        delete this?.token?.popoutCards;

        return super.close();
        //for some reason super.close() doesn't seem to shut it down
        // entirely when the automated initiative target goes to next
        // actor for GM. This fixed that tho im sure there is a reason to not do this.
        // delete this;
    }

    /**
     *
     * Open up a combat hud if it's activated for thie player connected
     *
     * @param {*} token
     * @param {*} selected
     */
    static async activateCombatHud(token, selected) {
        // console.log('activateCombatHud', { token, selected });
        if (game.settings.get('ars', 'floatingHudAllowPlayer')) {
            if (!['lootable', 'merchant'].includes(token?.actor?.type)) {
                // if (token?.actor?.type !== 'lootable') {
                const floatingHudAutoClose = game.settings.get('ars', 'floatingHudAutoClose');
                // handle closing huds here
                const controlled = canvas.tokens.controlled;
                if (game.user.combatHuds?.length) {
                    for (const hud of game.user.combatHuds) {
                        // if not a currently controlled token, remove hud if autoclose
                        if (!controlled.includes(token))
                            if (hud.autoClose && floatingHudAutoClose) {
                                await hud.close();
                            }
                    }
                }

                if (selected) {
                    // if selected and token hud doesnt exist, make one
                    if (!token.combatHud) {
                        const cHud = new ARSCombatHUD(token);
                        cHud.createHud();
                    } else {
                        // otherwise force re-render it
                        token.combatHud.render(true);
                    }
                }
                // else if (!selected) {
                //     if (token.combatHud) {
                //         if (token.combatHud.autoClose && floatingHudAutoClose) token.combatHud.close();
                //     }
                // }
            }
        }
    }
}

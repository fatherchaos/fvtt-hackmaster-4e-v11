const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
import { ARSActionGroup } from './action.js';

/**
 * ActionSheetV2 using v2 Sheets.
 */
export class ActionSheetV2 extends HandlebarsApplicationMixin(ApplicationV2) {
    constructor(object = {}, options = {}) {
        super(object, options);
        this.action = object;
    }

    //appV2 specific
    static DEFAULT_OPTIONS = {
        tag: 'popoutcard',
        classes: ['sheet-ars', 'app-action-sheet'],
        window: {
            title: 'Action',
            resizable: true,
            icon: 'fas fa-dragon',
            // contentTag: 'contentTagwhatgoesthis',
            contentClasses: ['ars', 'action-sheet'],
        },
        position: {
            width: 'auto',
            height: 'auto',
            // zIndex: number
        },
    }; // end DEFAULT_OPTIONS

    //appV2 specific
    static PARTS = {
        //     header: { template: '' },
        //     tabs: { template: '' },
        //     description: { template: '' },
        //     foo: { template: '' },
        //     bar: { template: '' },

        body: { template: 'systems/ars/templates/apps/actionV2/action-sheet.hbs' },
        submit: { template: 'systems/ars/templates/apps/actionV2/action-submit.hbs' },
    };

    get title() {
        return `Action: ${this.action?.name}`;
    }
    // //appV2 get template... ish
    // _configureRenderOptions(options) {
    //     super._configureRenderOptions(options);
    //     // set the parts to only the proper card
    //     options.parts = [this.properCard.type];
    // }

    //appV2 "getData()"
    async _prepareContext(options) {
        let context = {
            isGM: game.user.isGM,
            isDM: game.user.isDM,
            action: this.action,
            item: this.action,
            config: CONFIG.ARS,
            const: CONST,
        };

        return context;
    }
}

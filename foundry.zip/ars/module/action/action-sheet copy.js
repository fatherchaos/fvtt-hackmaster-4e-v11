// import { onManageAction_ActiveEffect } from "../effects.js";
// import * as actionManager from '../apps/action.js';
import { ARSActionGroup } from './action.js';

/**
 * A specialized form used to select from a checklist of attributes, traits, or properties
 * @implements {FormApplication}
 */
export class ActionSheet extends FormApplication {
    constructor(object = {}, options = {}) {
        super(object, options);
        this.action = object;
    }
    /** @override */
    static get defaultOptions() {
        return foundry.utils.mergeObject(super.defaultOptions, {
            classes: ['ars', 'action-sheet'],
            closeOnSubmit: false,
            height: 400,
            // id: 'action-sheet',
            resizable: true,
            submitOnChange: true,
            submitOnClose: true,
            template: 'systems/ars/templates/apps/action-sheet.hbs',
            title: 'Item Action',
            width: 500,
        });
    }

    get id() {
        return `${this.object.id}_${this.object.system?.id}`;
    }
    /** @override */
    activateListeners(html) {
        super.activateListeners(html);

        // Everything below here is only needed if the sheet is editable
        if (!this.options.editable) return;

        //manage the "other" damage on actions (add/remove)
        html.find('.action-control').click(this._onActionDamageOtherControl.bind(this));

        html.find('.action-image').click((ev) => {
            this.onEditImage(ev);
        });

        html.find('.effect-control').click(this._onEffectControl.bind(this));

        html.find('.general-properties-controls').click(this._manageProperties.bind(this));

        html.find('.changes-list .effect-change .effect-change-key').change((event) => this._updateKeyValue(event));
    }

    /** @override */
    async getData() {
        const item = this.object;
        const data = item;
        data.config = CONFIG.ARS;
        data.const = CONST;
        // ARSActionGroup.loadAll(this.action.source);
        const action = this.action;

        const actionData = {
            data: data,
            owner: item.isOwner,
            actor: item.actor,
            editable: this.isEditable,
            isEditable: this.isEditable,
            enrichedDesc: await TextEditor.enrichHTML(action?.description, { async: true }), //secrets: this?.actor?.isOwner,rollData: this.object.getRollData(),
            enrichedMisc: await TextEditor.enrichHTML(action?.misc, { async: true }),
            item: this.object,
            config: data.config,
            action: action,
            actionId: this.action.id,
            selectEffectKeys: game.ars.config.selectEffectKeys,
        };

        // console.log('action-sheet.js getData ', { actionData });
        return actionData;
    }

    /* -------------------------------------------- */

    /** @override */
    async _updateObject(event, formData) {
        for (const [key, value] of Object.entries(formData)) {
            console.log('_updateObject=', { key, value }, this.action);
            foundry.utils.setProperty(this.action, key, value);
        }
        // const action = this.action.parentGroup.actions.get(this.action.id);
        await this.action.save();
        // await ARSActionGroup.saveAll(this.action.source);
        this.render(true);
    }

    /**
     *
     * updates sheet when a key is selected that we know about and set defaults.
     *
     * This automates some prepopulated values to show some presetup value that are probably json
     *
     * @param {*} event
     */
    async _updateKeyValue(event) {
        // console.log("action-sheet.js _updateKeyValue-------------->", { event }, this);
        const element = event.currentTarget;
        const value = element.value;
        const li = element.closest('li');
        const index = li.dataset.index;
        console.log('action-sheet.js _updateKeyValue', { element, value, li, index });
        if (value) {
            const findObjectByName = (arr, name) => {
                return arr.find((obj) => obj.name === name);
            };
            // block submitOnChange for this
            // event.stopPropagation();
            // const details = game.ars.config.selectEffectKeys.find((a) => a.name === value);
            const details = findObjectByName(game.ars.config.selectEffectKeys, value);
            if (details) {
                console.log('action-sheet.js _updateKeyValue', { details }, this);
                this.action.effect.changes[index] = {
                    key: details.name,
                    mode: details.mode,
                    value: details.value,
                };

                //BUG: for some reason the action isnt the same and this fixes it as a hack. look at this later
                // const action = this.action.parentGroup.actions.get(this.action.id);

                await this.action.save();
                // this.action.parentGroup.load();
                // this.render();
            }
        }
    }

    /**
     * Manage other damage objects on action
     *
     * @param {*} event
     */
    async _onActionDamageOtherControl(event) {
        // console.log("action-sheet.js _onActionDamageOtherControl event", event);
        event.preventDefault();
        const element = event.currentTarget;
        const dataset = element.dataset;
        const item = this.object;
        const actionId = this.options.actionId;
        const index = Number(dataset.index);

        console.log('action-sheet.js _onActionDamageOtherControl', { dataset, index });

        if (element.classList.contains('add-damage')) {
            // console.log("_onActionDamageOtherControl", "add-damage otherdmg", otherdmg);
            let newDMG = {};
            newDMG.type = 'slashing';
            newDMG.formula = '1d4';
            newDMG.id = foundry.utils.randomID(16);
            this.action.otherdmg.push(newDMG);
        }

        if (element.classList.contains('delete-damage')) {
            this.action.otherdmg.splice(index, 1);
        }
        await this.action.save();
    }

    /**
     * Manage effects on action objects
     *
     *
     * @param {*} event
     */
    async onManage_ActionEffects(event) {
        event.preventDefault();
        const element = event.currentTarget;
        const dataset = element.dataset;
        const li = element.closest('li');
        const actionToPerform = dataset.action;
        const effectId = li.dataset.effectId;

        console.log('action-sheet.js onManage_ActionEffects', { dataset, li, actionToPerform, effectId });
        switch (actionToPerform) {
            case 'create':
                let newActionEffect = foundry.utils.duplicate(game.ars.templates['actionEffect']);

                if (!newActionEffect.id) {
                    newActionEffect.id = foundry.utils.randomID(16);
                }

                this.action.effectList.push(newActionEffect);
                await this.action.save();
                break;

            case 'delete':
                this.action.effectList.splice(effectId, 1);
                await this.action.save();
                break;

            default:
                console.log('action-sheet.js', 'onManage_ActionEffects', 'Unknown actionToPerform type=', actionToPerform);
                break;
        }
    }

    /**
     * edit image/icon for action
     *
     * @param {*} event
     */
    onEditImage(event) {
        // console.log("action-sheet.js", "onEditImage", { event });
        if (event.currentTarget.dataset.edit === 'img') {
            const fp = new FilePicker({
                type: 'image',
                current: this.img,
                callback: (path) => {
                    event.currentTarget.src = path;
                    return this._onSubmit(event);
                },
                top: this.position.top + 40,
                left: this.position.left + 10,
            });
            // console.log("action-sheet.js", "onEditImage", { fp });
            return fp.browse();
        }
    }

    /**
     *
     * Add/Delete effect.changes on an effect for an action
     *
     * @param {MouseEvent} event      The originating click event
     * @private
     */
    async _onEffectControl(event) {
        event.preventDefault();
        console.log('action-sheet.js _onEffectControl event', event);
        const element = event.currentTarget;
        const index = element.closest('li')?.dataset?.index;

        console.log('action-sheet.js _onEffectControl', { element, index });

        switch (element.dataset.action) {
            case 'add':
                this.action.effect.changes.push({ mode: 0, key: '', value: '' });
                await this.action.save();
                break;
            case 'delete':
                this.action.effect.changes.splice(index, 1);
                await this.action.save();
                break;
        }
        this.render();
    }

    /**
     *
     * Add/remove properties
     *
     * @param {*} event
     */
    async _manageProperties(event) {
        event.preventDefault();
        const element = event.currentTarget;
        const dataset = element.dataset;
        const li = element.closest('li');
        const index = li?.dataset?.index || undefined;
        const actionCommand = dataset.action;
        const actionId = this.options.actionId;

        // console.log("action-sheet.js _manageProperties", this.object);

        switch (actionCommand) {
            case 'create':
                await this._onSubmit(event); // do this first as we don't save items onchange (it's onclose)
                this.action.properties.push('');
                await this.action.save();
                break;

            case 'remove':
                if (index) {
                    await this._onSubmit(event);
                    this.action.properties.splice(index, 1);
                    await this.action.save();
                }
                break;
        }
    }
    /* ----------------------------------------- */
}

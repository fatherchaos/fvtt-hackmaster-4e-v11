// import { arsBaseDataModel } from '../schema.js';
// const fields = foundry.data.fields;
// export default class activeEffectData extends arsBaseDataModel {
//     static defineSchema() {
//         return {
//             ...ActiveEffect.defineSchema(),
//             ...super.defineSchema(),
//             test: new fields.StringField({ required: true, initial: 'Just some data', default: '' }),

//             concentration: new fields.SchemaField({
//                 spell: new fields.SchemaField({}),
//                 psionic: new fields.SchemaField({}),
//             }),
//             aura: new fields.SchemaField({
//                 originUuid: new fields.StringField({ required: true }),
//                 effectUuid: new fields.StringField({ required: true }),
//                 isAura: new fields.BooleanField({ required: true, default: false }),
//             }),
//         };
//     }
// }

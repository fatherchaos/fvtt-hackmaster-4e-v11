import { itemDataSchema } from './item.js';
export default class ARSItemAbility extends itemDataSchema {
    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {});
    }
}

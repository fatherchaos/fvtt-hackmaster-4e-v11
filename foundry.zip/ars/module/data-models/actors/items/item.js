import { itemDataSchema, itemCostSchema } from './schema.js';
import { ARSItem } from '../item.js';
import { ARS } from '../../config.js';
export default class ARSItemData extends itemDataSchema {
    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {
            ...itemCostSchema.defineSchema(),
        });
    }
}

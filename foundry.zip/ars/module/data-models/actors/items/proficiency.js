import { itemDataSchema } from '../schema.js';
import { ARSItem } from '../../item.js';
import { ARS } from '../../../config.js';
export default class ARSItemProficiency extends itemDataSchema {
    /** @inheritdoc */
    static migrateData(source) {
        // console.log(
        //     'ARSItemProficiency migrateData',
        //     { source },
        //     source.proficiencies?.cost,
        //     foundry.utils.deepClone(source)
        // );
        // if ('cost' in source && (source.proficiencies?.cost == undefined || source.proficiencies?.cost == null)) {
        if ('proficiencies' in source && source.cost && source.proficiencies?.cost == null) {
            if (source?.cost) {
                console.log('ARSItemProficiency migrateData==>', source.description, {
                    source,
                });
                source.proficiencies.cost = Number(source.cost) || 0;
                delete source.cost;
            }
        }
    }

    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {
            proficiencies: new fields.SchemaField({
                cost: new fields.NumberField({ required: true, nullable: true, initial: null, min: 0, default: 1 }),
            }),
            // name: new fields.StringField(),
            // type: new fields.StringField(),

            appliedto: new fields.ArrayField(new fields.SchemaField({ id: new fields.StringField({ required: false }) })),
            hit: new fields.StringField({ default: '' }),
            damage: new fields.StringField({ default: '' }),
            speed: new fields.NumberField({ default: 0 }),
            attacks: new fields.StringField({ default: '' }),
            // this can be removed someday, moved to proficiencies.cost to not collide with item.cost
            // cost: new fields.StringField({ nullable: true, required: false }),
        });
    }
}

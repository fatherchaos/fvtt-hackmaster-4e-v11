import { itemDescriptionSchema, itemDetailsSchema, itemSoundSchema, itemListSchema } from './schema.js';
import { ARSItem } from './item.js';
import { ARS } from '../config.js';
export default class ARSItemRace extends ARSItem {
    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {
            ...itemDescriptionSchema.defineSchema(),
            ...itemDetailsSchema.defineSchema(),
            proficiencies: new fields.SchemaField({
                weapon: new fields.StringField({ required: true }),
                skill: new fields.StringField({ required: true }),
            }),
            name: new fields.StringField(),
            type: new fields.StringField(),
        });
    }
}

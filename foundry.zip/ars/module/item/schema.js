import { ARS } from '../config.js';

export class itemListSchema {
    static defineSchema() {
        const fields = foundry.data.fields;
        return {
            uuid: new fields.StringField({ required: true }),
            sourceuuid: new fields.StringField({ required: true }),
            type: new fields.StringField({ required: true }),
            name: new fields.StringField({ required: true }),
            img: new fields.StringField({ required: true }),
            id: new fields.StringField({ required: true }),
            count: new fields.NumberField({ initial: 0, integer: true, default: 0 }),
            level: new fields.NumberField({ initial: 0, integer: true, default: 0 }),
        };
    }
}
export class itemDescriptionSchema {
    static defineSchema() {
        const fields = foundry.data.fields;
        return {
            description: new fields.StringField({ required: true, default: '' }),
            dmonlytext: new fields.StringField({ required: true, default: '' }),
        };
    }
}

export class itemDetailsSchema {
    static defineSchema() {
        const fields = foundry.data.fields;
        return {
            // alias: new fields.StringField({ required: true, default: '' }),
            attributes: new fields.SchemaField({
                rarity: new fields.StringField({ required: true, default: '' }),
                type: new fields.StringField({ required: true, default: '' }),
                subtype: new fields.StringField({ required: true, default: '' }),
                magic: new fields.BooleanField({ required: true, default: false }),
                properties: new fields.ArrayField(new fields.StringField()),
                skillmods: new fields.ArrayField(
                    new fields.SchemaField({
                        name: new fields.StringField({ required: true }),
                        value: new fields.NumberField({ required: true, integer: true }),
                    })
                ),
                conditionals: new fields.ArrayField(
                    new fields.SchemaField({
                        key: new fields.StringField({ required: true }),
                        value: new fields.StringField({ required: true }),
                    })
                ),
                identified: new fields.BooleanField({ default: true }),
                infiniteammo: new fields.BooleanField({ required: true, default: false }),
            }),
            charges: new fields.SchemaField({
                value: new fields.NumberField({ required: true, initial: 0, default: 0 }),
                min: new fields.NumberField({ required: true, initial: 0, default: 0 }),
                max: new fields.NumberField({ required: true, initial: 0, default: 0 }),
                reuse: new fields.StringField({ required: true, initial: 'none', default: 'none' }),
            }),
            location: new fields.SchemaField({
                state: new fields.StringField({ required: true, default: 'carried' }),
                parent: new fields.StringField({ required: true, default: '' }),
            }),
            resource: new fields.SchemaField({
                itemId: new fields.StringField({ required: true, default: '' }),
            }),
            actions: new fields.ArrayField(new fields.ObjectField()),
            quantity: new fields.NumberField({ required: true, initial: 0, default: 0 }),
            weight: new fields.NumberField({ required: true, initial: 0, default: 0 }),
            cost: new fields.SchemaField({
                value: new fields.NumberField({ required: true, initial: 0, default: 0 }),
                currency: new fields.StringField({ required: true, default: 'gp' }),
            }),
            itemList: new fields.ArrayField(new fields.SchemaField({ ...itemListSchema.defineSchema() })),
            source: new fields.StringField({ required: true, default: '' }),
            xp: new fields.NumberField({ required: true, initial: 0, default: 0 }),
        };
    }
}

export class itemSoundSchema {
    static defineSchema() {
        const fields = foundry.data.fields;
        return {
            audio: new fields.SchemaField({
                file: new fields.StringField({ required: true, default: '' }),
                volume: new fields.NumberField({ required: true, default: 0.5 }),
                effect: new fields.StringField({ required: true, default: '' }),
                success: new fields.StringField({ required: true, default: '' }),
                failure: new fields.StringField({ required: true, default: '' }),
            }),
        };
    }
}

export class itemDataSchema extends foundry.abstract.TypeDataModel {
    static defineSchema() {
        const fields = foundry.data.fields;
        return {
            ...itemDescriptionSchema.defineSchema(),
            ...itemDetailsSchema.defineSchema(),
        };
    }
}

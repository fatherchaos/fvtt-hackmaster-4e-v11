import * as effectManager from '../effect/effects.js';
import * as chatManager from '../chat.js';
import * as utilitiesManager from '../utilities.js';
import * as debug from '../debug.js';
import * as macrosManager from '../macros.js';
import * as actionManager from '../apps/action.js';

/**
 *
 * When encounter dropped on scene add contents
 *
 * @param {*} item item object (encounter item)
 * @param {*} dropData drop data that includes x/y
 */
export async function encounterDrop(item, dropData) {
    console.log('encounter.js encounterDrop', { item, dropData });

    const usedLocations = [];

    function findUnoccupiedPosition(startX, startY, tokenWidth, tokenHeight) {
        let dx = 0,
            dy = 0;
        let direction = 0; // 0: right, 1: down, 2: left, 3: up
        let steps = 1,
            stepCount = 0;

        const gridWidth = tokenWidth * canvas.grid.w;
        const gridHeight = tokenHeight * canvas.grid.h;
        while (true) {
            // Infinite loop, will break when an unoccupied position is found
            let checkX = startX + dx * canvas.grid.size;
            let checkY = startY + dy * canvas.grid.size;

            const snappedPosition = canvas.grid.getSnappedPosition(checkX, checkY);
            const newLocation = {
                x: snappedPosition.x + canvas.grid.w / 2 - gridWidth / 2,
                y: snappedPosition.y + canvas.grid.h / 2 - gridHeight / 2,
            };

            if (isPositionUnoccupied(newLocation.x, newLocation.y, tokenWidth, tokenHeight)) {
                // console.log(`encounter.js isPositionUnoccupied() SET:`, { newLocation });
                usedLocations.push(`${newLocation.x}:${newLocation.y}`);
                return { x: newLocation.x, y: newLocation.y };
            }

            // Update dx, dy based on direction
            // switch (direction) {
            //     case 0:
            //         dx++;
            //         break; // Move right
            //     case 1:
            //         dy++;
            //         break; // Move down
            //     case 2:
            //         dx--;
            //         break; // Move left
            //     case 3:
            //         dy--;
            //         break; // Move up
            // }

            switch (direction) {
                case 0: // Move right
                    dx++;
                    break;
                case 1: // Move down
                    dy++;
                    break;
                case 2: // Move left
                    dx--;
                    break;
                case 3: // Move up
                    dy--;
                    break;

                case 4: // Move up right
                    dx++;
                    dy--;
                    break;

                case 5: // Move up left
                    dx--;
                    dy--;
                    break;

                case 6: // Move down left
                    dx--;
                    dy++;
                    break;

                case 7: // Move down right
                    dx++;
                    dy++;
                    break;
            }

            stepCount++;
            if (stepCount === steps) {
                stepCount = 0;
                direction = (direction + 1) % 4; // Change direction
                if (direction === 0 || direction === 2) steps++; // Increase step size every full cycle
                // if (direction === 0) steps++; // Increase step size every full cycle
            }
            // console.log(
            //     `encounter.js isPositionUnoccupied() x${checkX} y${checkY} w${canvas.grid.width} h${canvas.grid.height}`
            // );
            if (checkX > canvas.grid.width || checkY > canvas.grid.height || checkX < 0 || checkY < 0) {
                ui.notifications.error(`Reached edge of canvas and did not find clear location x${checkX} y${checkY}`);
                return undefined;
            }
        }
    }

    function isPositionUnoccupied(x, y, tokenWidth, tokenHeight) {
        // Check if the position is outside the canvas boundaries
        if (
            x < 0 ||
            y < 0 ||
            x + tokenWidth * canvas.grid.w > canvas.dimensions.width ||
            y + tokenHeight * canvas.grid.h > canvas.dimensions.height ||
            usedLocations.includes(`${x}:${y}`)
        ) {
            // console.log(`encounter.js isPositionUnoccupied DUMP OUT`, { x, y, tokenWidth, tokenHeight });
            return false;
        }

        // Check for overlap with existing tokens
        return !canvas.tokens.placeables.some((token) => {
            const overlapsX = x < token.x + token.width * canvas.grid.w && x + tokenWidth * canvas.grid.w > token.x;
            const overlapsY = y < token.y + token.height * canvas.grid.h && y + tokenHeight * canvas.grid.h > token.y;
            return overlapsX && overlapsY;
        });
    }

    // function getNextSpiralPosition(startX, startY, tokenWidth, tokenHeight, step, gridSize) {
    //     let thisStep = step;
    //     const startDirection = step % 8;
    //     // let first = true;
    //     let distanceMultiplier = 1;
    //     let x = startX,
    //         y = startY;

    //     while (x > 0 && y > 0 && x < canvas.grid.width && y < canvas.grid.height) {
    //         // Directions: 0 = right, 1 = down, 2 = left, 3 = up
    //         let direction = thisStep % 8;
    //         let distance = Math.floor((thisStep + 2) / 8);

    //         switch (direction) {
    //             case 0: // Move right
    //                 x += distance * gridSize;
    //                 break;
    //             case 1: // Move down
    //                 y += distance * gridSize;
    //                 break;
    //             case 2: // Move left
    //                 x -= distance * gridSize;
    //                 break;
    //             case 3: // Move up
    //                 y -= distance * gridSize;
    //                 break;

    //             case 4: // Move up right
    //                 x += distance * gridSize;
    //                 y -= distance * gridSize;
    //                 break;

    //             case 5: // Move up left
    //                 x -= distance * gridSize;
    //                 y -= distance * gridSize;
    //                 break;

    //             case 6: // Move down left
    //                 x -= distance * gridSize;
    //                 y += distance * gridSize;
    //                 break;

    //             case 7: // Move down right
    //                 x += distance * gridSize;
    //                 y += distance * gridSize;
    //                 break;
    //         }

    //         const gridWidth = tokenWidth * canvas.grid.w;
    //         const gridHeight = tokenHeight * canvas.grid.h;
    //         const snappedPosition = canvas.grid.getSnappedPosition(x, y);
    //         const newLocation = {
    //             x: snappedPosition.x + canvas.grid.w / 2 - gridWidth / 2,
    //             y: snappedPosition.y + canvas.grid.h / 2 - gridHeight / 2,
    //         };

    //         // if (isPositionUnoccupied(newLocation.x, newLocation.y, tokenWidth, tokenHeight)) {
    //         // console.log(`encounter.js isPositionUnoccupied() SET:`, { newLocation });
    //         // usedLocations.push(`${newLocation.x}:${newLocation.y}`);
    //         return newLocation;
    //         // }
    //         // if (!first && startDirection == direction) distanceMultiplier = distanceMultiplier * 2;
    //         // thisStep++;
    //         // first = false;
    //     }
    //     console.log(`encounter.js getNextSpiralPosition() NO EMPTY SPACE`);
    //     return undefined;
    // }

    if (item) {
        for await (const npcr of item.system.npcList) {
            let actor = npcr.uuid ? await fromUuid(npcr.uuid) : await game.actors.get(npcr.id);
            if (!actor && npcr.pack) {
                actor = await game.packs.get(npcr.pack).getDocument(npcr.id);
            }
            if (actor) {
                if (actor.compendium) {
                    const actorData = game.actors.fromCompendium(actor);
                    // create local actor, use same id so we can use it instead if we drop this again
                    actor = await Actor.implementation.create({ ...actorData, id: npcr.id, _id: npcr.id }, { keepId: true });

                    // place this actor into a dump folder
                    const dumpfolder = await utilitiesManager.getFolder('Encounter Drops', 'Actor');
                    actor.update({ folder: dumpfolder.id });
                }

                const countFor = utilitiesManager.evaluateFormulaValue(npcr.count) || 1;
                console.log(`encounter.js EncounterDrop() spawning ${countFor} ${actor.name}`);
                for (let i = 0; i < countFor; i++) {
                    // Prepare the Token data
                    const td = await actor.getTokenDocument({ x: dropData.x, y: dropData.y, hidden: event.altKey });

                    // console.log(`encounter.js ...START EncounterDrop() getTokenDocument`, { td });

                    // const tokenPosision = getNextSpiralPosition(
                    //     dropData.x,
                    //     dropData.y,
                    //     td.width,
                    //     td.height,
                    //     i,
                    //     canvas.grid.size
                    // );
                    // await td.updateSource({
                    //     x: tokenPosision.x,
                    //     y: tokenPosision.y,
                    // });
                    // console.log(`encounter.js EncounterDrop() updateSource`, { td, tokenPosision });

                    // Find an unoccupied position
                    const unoccupiedPosition = findUnoccupiedPosition(td.x, td.y, td.width, td.height);
                    if (!unoccupiedPosition) {
                        // ui.notifications.warn(`No unoccupied space found for the ${actor.name} Token.`);
                        console.warn(`No unoccupied space found for the ${actor.name} Token.`);
                        continue;
                    }
                    await td.updateSource({
                        x: unoccupiedPosition.x,
                        y: unoccupiedPosition.y,
                    });

                    console.log(`encounter.js EncounterDrop() updateSource`, { td, unoccupiedPosition });

                    // Validate the final position
                    if (!canvas.dimensions.rect.contains(td.x, td.y)) continue;
                    // console.log(`encounter.js EncounterDrop() canvas.dimensions.rect`, { td });

                    await td.constructor.create(td, { parent: canvas.scene });
                    // console.log(`encounter.js ...END EncounterDrop() td.constructor`, { td });
                }
            }
        }
    }
}

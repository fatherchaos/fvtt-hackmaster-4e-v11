import { itemDataSchema } from './schema.js';
import { ARSItem } from './item.js';
import { ARS } from '../config.js';
export default class ARSItemProficiency extends itemDataSchema {
    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {
            proficiencies: new fields.SchemaField({
                weapon: new fields.StringField({ required: true }),
                skill: new fields.StringField({ required: true }),
            }),
            // name: new fields.StringField(),
            // type: new fields.StringField(),
            
            appliedto: new fields.ArrayField(new fields.StringField({ required: false })),
            cost: new fields.NumberField({ default: 1 }),
            hit: new fields.StringField({ default: '' }),
            damage: new fields.StringField({ default: '' }),
            speed: new fields.NumberField({ default: 0 }),
            attacks: new fields.StringField({ default: '' }),
        });
    }
}

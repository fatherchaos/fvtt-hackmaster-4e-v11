import { actorDataSchema } from './schema.js';
import { ARS } from '../../config.js';
export default class ARSActorData extends actorDataSchema {
    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {});
    }
}

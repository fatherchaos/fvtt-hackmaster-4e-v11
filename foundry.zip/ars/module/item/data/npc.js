import { actorDataSchema } from './schema.js';
import { ARS } from '../../config.js';
export default class ARSActorNPC extends actorDataSchema {
    /** @inheritdoc */
    static migrateData(source) {
        // console.log('ARSActorNPC migrateData', { source });
    }

    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {
            climate: new fields.StringField({ default: '' }),
            frequency: new fields.StringField({ default: '' }),
            organization: new fields.StringField({ default: '' }),
            diet: new fields.StringField({ default: '' }),
            activity: new fields.StringField({ default: '' }),
            intelligence: new fields.StringField({ default: '' }),
            inlair: new fields.StringField({ default: '' }),
            treasureType: new fields.StringField({ default: '' }),
            numberAppearing: new fields.StringField({ default: '' }),
            movement: new fields.StringField({ default: '' }),
            hitdice: new fields.StringField({ default: '1' }),
            hitediceNotes: new fields.StringField({ default: '' }),
            hpCalculation: new fields.StringField({ default: '' }),
            numberAttacks: new fields.StringField({ default: '' }),
            damage: new fields.StringField({ default: '1d6' }),
            specialAttacks: new fields.StringField({ default: '' }),
            specialDefenses: new fields.StringField({ default: '' }),
            sizenote: new fields.StringField({ default: '' }),
            acNote: new fields.StringField({ default: '' }),
            magicresist: new fields.StringField({ default: '' }),
            abilityNotes: new fields.ArrayField(new fields.ObjectField()),
            resistances: new fields.SchemaField({
                weapon: new fields.SchemaField({
                    magicpotency: new fields.NumberField({ default: 0 }),
                    metals: new fields.ArrayField(new fields.StringField({ default: '' })),
                }),
            }),
            xp: new fields.SchemaField({
                value: new fields.NumberField({ default: 0 }),
            }),
            details: new fields.SchemaField({
                type: new fields.StringField({ default: '' }),
                source: new fields.StringField({ default: '' }),
            }),
            morale: new fields.StringField({ default: '' }),
            disablelooting: new fields.BooleanField({ default: false }),
        });
    }
}

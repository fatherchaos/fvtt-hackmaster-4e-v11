import { actorDataSchema } from '../schema.js';
import { ARS } from '../../../config.js';
export default class ARSActorData extends actorDataSchema {
    /** @inheritdoc */
    static migrateData(source) {
        // console.log('ARSActorData migrateData', { source });
    }

    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {});
    }
}

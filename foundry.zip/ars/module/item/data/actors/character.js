import { actorDataSchema } from '../schema.js';
import { ARS } from '../../../config.js';
export default class ARSActorCharacter extends actorDataSchema {
    /** @inheritdoc */
    static migrateData(source) {
        // console.log('ARSActorCharacter migrateData', { source });
    }
    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {
            details: new fields.SchemaField({
                player: new fields.StringField({ default: '' }),
                age: new fields.StringField({ default: '' }),
                height: new fields.StringField({ default: '' }),
                weight: new fields.StringField({ default: '' }),
                deity: new fields.StringField({ default: '' }),
                background: new fields.StringField({ default: '' }),
                notes: new fields.StringField({ default: '' }),
                xp: new fields.NumberField({ default: 0 }),
                applyxp: new fields.NumberField({ default: 0 }),
            }),
        });
    }
}

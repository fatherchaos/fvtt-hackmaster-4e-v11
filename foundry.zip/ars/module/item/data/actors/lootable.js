import { actorDataSchema } from '../schema.js';
import { ARS } from '../../../config.js';
export default class ARSActorLootable extends actorDataSchema {
    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {
            lootable: new fields.BooleanField({ default: false }),
        });
    }
}

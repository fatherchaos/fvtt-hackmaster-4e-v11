import { itemDataSchema } from './schema.js';
import { ARSItem } from '../item.js';
import { ARS } from '../../config.js';
export default class ARSItemBundle extends itemDataSchema {
    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {
            // name: new fields.StringField(),
            // type: new fields.StringField(),
            currency: new fields.SchemaField({
                pp: new fields.NumberField({ required: true, integer: true, default: 0 }),
                gp: new fields.NumberField({ required: true, integer: true, default: 0 }),
                ep: new fields.NumberField({ required: true, integer: true, default: 0 }),
                sp: new fields.NumberField({ required: true, integer: true, default: 0 }),
                cp: new fields.NumberField({ required: true, integer: true, default: 0 }),
            }),
            newValueTest: new fields.NumberField({ required: true, integer: true, initial: 0 }),
        });
    }
}

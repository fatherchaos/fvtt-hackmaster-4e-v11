import { itemDataSchema, itemSoundSchema } from './schema.js';
import { ARSItem } from '../item.js';
import { ARS } from '../../config.js';
export default class ARSItemClass extends itemDataSchema {
    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {
            active: new fields.BooleanField({ required: true, default: true }),
            xp: new fields.NumberField({ required: true, default: 0 }),
            xpbonus: new fields.NumberField({ required: true, default: 0 }),
            advancement: new fields.ArrayField(new fields.ObjectField({ default: '' })),
            features: new fields.SchemaField({
                acDexFormula: new fields.StringField({ required: true, default: '@abilities.dex.defensive' }),
                hpConFormula: new fields.StringField({ default: '' }),
                lasthitdice: new fields.NumberField({ required: true, default: 9 }),
                bonuscon: new fields.BooleanField({ required: true, default: false }),
                // spellFreecast: new fields.BooleanField({ required: true, default: false }),
                focus: new fields.SchemaField({
                    major: new fields.StringField({ default: '' }),
                    minor: new fields.StringField({ default: '' }),
                }),
            }),
            proficiencies: new fields.SchemaField({
                penalty: new fields.NumberField({ required: true, default: -4 }),
                weapon: new fields.SchemaField({
                    starting: new fields.NumberField({ required: true, default: 0 }),
                    earnLevel: new fields.NumberField({ required: true, default: 3 }),
                }),
                skill: new fields.SchemaField({
                    starting: new fields.NumberField({ required: true, default: 0 }),
                    earnLevel: new fields.NumberField({ required: true, default: 3 }),
                }),
            }),
            matrixTable: new fields.StringField({ default: '' }),
            ranks: new fields.ArrayField(new fields.ObjectField()),
        });
    }
}

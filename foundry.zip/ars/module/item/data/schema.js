import { ARS } from '../../config.js';

export class itemListSchema {
    static defineSchema() {
        const fields = foundry.data.fields;
        return {
            uuid: new fields.StringField({ required: true }),
            sourceuuid: new fields.StringField({ required: true }),
            type: new fields.StringField({ required: true }),
            name: new fields.StringField({ required: true }),
            img: new fields.StringField({ required: true }),
            id: new fields.StringField({ required: true }),
            count: new fields.NumberField({ initial: 0, integer: true, default: 0 }),
            level: new fields.NumberField({ initial: 0, integer: true, default: 0 }),
        };
    }
}
export class itemDescriptionSchema {
    static defineSchema() {
        const fields = foundry.data.fields;
        return {
            description: new fields.StringField({ required: true, default: '' }),
            dmonlytext: new fields.StringField({ required: true, default: '' }),
        };
    }
}

export class itemDetailsSchema {
    static defineSchema() {
        const fields = foundry.data.fields;
        return {
            // alias: new fields.StringField({ required: true, default: '' }),
            attributes: new fields.SchemaField({
                rarity: new fields.StringField({ required: true, default: '' }),
                type: new fields.StringField({ required: true, default: '' }),
                subtype: new fields.StringField({ required: true, default: '' }),
                magic: new fields.BooleanField({ required: true, default: false }),
                properties: new fields.ArrayField(new fields.StringField()),
                skillmods: new fields.ArrayField(
                    new fields.SchemaField({
                        name: new fields.StringField({ required: true }),
                        value: new fields.NumberField({ required: true, integer: true }),
                    })
                ),
                conditionals: new fields.ArrayField(
                    new fields.SchemaField({
                        key: new fields.StringField({ required: true }),
                        value: new fields.StringField({ required: true }),
                    })
                ),
                identified: new fields.BooleanField({ default: true }),
                infiniteammo: new fields.BooleanField({ required: true, default: false }),
            }),
            charges: new fields.SchemaField({
                value: new fields.NumberField({ required: true, initial: 0, default: 0 }),
                min: new fields.NumberField({ required: true, initial: 0, default: 0 }),
                max: new fields.NumberField({ required: true, initial: 0, default: 0 }),
                reuse: new fields.StringField({ required: true, initial: 'none', default: 'none' }),
            }),
            location: new fields.SchemaField({
                state: new fields.StringField({ required: true, default: 'carried' }),
                parent: new fields.StringField({ required: true, default: '' }),
            }),
            resource: new fields.SchemaField({
                itemId: new fields.StringField({ required: true, default: '' }),
            }),
            actions: new fields.ArrayField(new fields.ObjectField()),
            quantity: new fields.NumberField({ required: true, initial: 0, default: 0 }),
            weight: new fields.NumberField({ required: true, initial: 0, default: 0 }),
            itemList: new fields.ArrayField(new fields.SchemaField({ ...itemListSchema.defineSchema() })),
            source: new fields.StringField({ required: true, default: '' }),
            xp: new fields.NumberField({ required: true, initial: 0, default: 0 }),
        };
    }
}

export class itemSoundSchema {
    static defineSchema() {
        const fields = foundry.data.fields;
        return {
            audio: new fields.SchemaField({
                file: new fields.StringField({ required: true, default: '' }),
                volume: new fields.NumberField({ required: true, default: 0.5 }),
                effect: new fields.StringField({ required: true, default: '' }),
                success: new fields.StringField({ required: true, default: '' }),
                failure: new fields.StringField({ required: true, default: '' }),
            }),
        };
    }
}

export class itemCostSchema {
    static defineSchema() {
        const fields = foundry.data.fields;
        return {
            cost: new fields.SchemaField({
                value: new fields.NumberField({ required: true, initial: 0, default: 0 }),
                currency: new fields.StringField({ required: true, default: 'gp' }),
            }),
        };
    }
}

export class itemDataSchema extends foundry.abstract.TypeDataModel {
    static defineSchema() {
        const fields = foundry.data.fields;
        return {
            ...itemDescriptionSchema.defineSchema(),
            ...itemDetailsSchema.defineSchema(),
        };
    }
}

export class actorDataSchema extends foundry.abstract.TypeDataModel {
    // /** @inheritdoc */
    static migrateData(source) {
        // console.log('actorDataSchema migrateData', { source });
    }

    static defineSchema() {
        const fields = foundry.data.fields;
        return {
            power: new fields.ObjectField({
                value: new fields.NumberField({ default: 5 }),
                min: new fields.NumberField({ default: 0 }),
                max: new fields.NumberField({ default: 5 }),
            }),
            abilities: new fields.ObjectField({
                str: new fields.ObjectField({
                    value: new fields.NumberField({ default: 10 }),
                    percent: new fields.NumberField({ default: 0 }),
                }),
                dex: new fields.ObjectField({
                    value: new fields.NumberField({ default: 10 }),
                    percent: new fields.NumberField({ default: 0 }),
                }),
                con: new fields.ObjectField({
                    value: new fields.NumberField({ default: 10 }),
                    percent: new fields.NumberField({ default: 0 }),
                }),
                int: new fields.ObjectField({
                    value: new fields.NumberField({ default: 10 }),
                    percent: new fields.NumberField({ default: 0 }),
                }),
                wis: new fields.ObjectField({
                    value: new fields.NumberField({ default: 10 }),
                    percent: new fields.NumberField({ default: 0 }),
                }),
                cha: new fields.ObjectField({
                    value: new fields.NumberField({ default: 10 }),
                    percent: new fields.NumberField({ default: 0 }),
                }),
            }),
            saves: new fields.ObjectField({
                paralyzation: new fields.NumberField({ default: 20 }),
                poison: new fields.NumberField({ default: 20 }),
                death: new fields.NumberField({ default: 20 }),
                rod: new fields.NumberField({ default: 20 }),
                staff: new fields.NumberField({ default: 20 }),
                wand: new fields.NumberField({ default: 20 }),
                petrification: new fields.NumberField({ default: 20 }),
                polymorph: new fields.NumberField({ default: 20 }),
                breath: new fields.NumberField({ default: 20 }),
                spell: new fields.NumberField({ default: 20 }),
            }),
            spellInfo: new fields.SchemaField({
                level: new fields.ObjectField(),
                memorization: new fields.ObjectField(),
                slots: new fields.ObjectField(),
            }),
            attributes: new fields.ObjectField({
                ac: new fields.ObjectField({ value: new fields.NumberField({ default: 10 }) }),
                thaco: new fields.ObjectField({ value: new fields.NumberField({ default: 20 }) }),
                hp: new fields.ObjectField({
                    base: new fields.NumberField({ default: 0 }),
                    value: new fields.NumberField({ default: 0 }),
                    min: new fields.NumberField({ default: -10 }),
                    max: new fields.NumberField({ default: 0 }),
                    temp: new fields.NumberField({ default: 0 }),
                    tempmax: new fields.NumberField({ default: 0 }),
                }),
                init: new fields.ObjectField({
                    value: new fields.NumberField({ default: 0 }),
                    modifier: new fields.NumberField({ default: 0 }),
                }),
                movement: new fields.ObjectField({
                    value: new fields.NumberField({ default: 0 }),
                    unit: new fields.StringField({ default: 'ft' }),
                }),
                size: new fields.StringField({ default: 'medium' }),
                identified: new fields.BooleanField({ default: false }),
            }),
            details: new fields.SchemaField({
                biography: new fields.ObjectField({
                    value: new fields.StringField({ default: '' }),
                    public: new fields.StringField({ default: '' }),
                    alignment: new fields.StringField({ default: '' }),
                }),
                provisions: new fields.ObjectField({
                    food: new fields.StringField({ default: '' }),
                    water: new fields.StringField({ default: '' }),
                }),
            }),
            currency: new fields.ObjectField({
                pp: new fields.NumberField({ default: 0 }),
                gp: new fields.NumberField({ default: 0 }),
                ep: new fields.NumberField({ default: 0 }),
                sp: new fields.NumberField({ default: 0 }),
                cp: new fields.NumberField({ default: 0 }),
            }),
            properties: new fields.ArrayField(new fields.StringField()),
            mods: new fields.ObjectField(),
            matrix: new fields.ArrayField(new fields.ObjectField()),
            rank: new fields.ObjectField(),
            actions: new fields.ArrayField(new fields.ObjectField()),
            alias: new fields.StringField({ default: '' }),
        };
    }
}

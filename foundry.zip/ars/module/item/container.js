import { itemDataSchema} from './schema.js';
import { ARSItem } from './item.js';
import { ARS } from '../config.js';
export default class ARSItemContainer extends itemDataSchema {
    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {
            // name: new fields.StringField(),
            // type: new fields.StringField(),
            capacity: new fields.SchemaField({
                weightreduction: new fields.NumberField({ initial: 0, integer: true, default: 0 }),
                value: new fields.NumberField({ initial: 0, integer: true, default: 0 }),
            }),
        });
    }
}

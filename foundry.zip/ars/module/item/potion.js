import {itemDataSchema} from './schema.js';
import { ARSItem } from './item.js';
import { ARS } from '../config.js';
export default class ARSItemPotion extends itemDataSchema {
    /** @inheritDoc */
    static defineSchema() {
        const fields = foundry.data.fields;
        return foundry.utils.mergeObject(super.defineSchema(), {

            // name: new fields.StringField(),
            // type: new fields.StringField(),
        });
    }
}

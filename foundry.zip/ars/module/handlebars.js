/**
 *
 * Handlebars helpers
 *
 */
export default function () {
    /**
     * Example use if handlebars #if
     *
     * {{#if (or (eq data.type "potion") (eq data.type "decoction"))}}
     *
     */

    // If you need to add Handlebars helpers, here are a few useful examples:
    Handlebars.registerHelper('or', (a, b) => {
        return a || b;
    });

    Handlebars.registerHelper('getDmgIcon', (dmgType) => {
        let idx = Object.keys(CONFIG.ARS.dmgTypeIcons).find((k) => k === dmgType);
        return CONFIG.ARS.dmgTypeIcons[idx];
    });

    Handlebars.registerHelper('concat', function () {
        var outStr = '';
        for (var arg in arguments) {
            if (typeof arguments[arg] != 'object') {
                outStr += arguments[arg];
            }
        }
        return outStr;
    });

    Handlebars.registerHelper('toLowerCase', function (str) {
        return str.toLowerCase();
    });

    Handlebars.registerHelper('checklength', function (v1, v2, options) {
        'use strict';

        if (typeof v1 === 'object') {
            const vTest = Object.values(v1);
            if (vTest.length > v2) {
                return options.fn(this);
            }
        } else {
            if (v1.length > v2) {
                return options.fn(this);
            }
        }

        return options.inverse(this);
    });

    /**
     * Does the object contain any of these items.
     */
    Handlebars.registerHelper('includes', function (data, content, options) {
        let contents = undefined;

        if (content.match('(||)')) {
            contents = content.split('||');
        } else {
            contents = [content];
        }
        for (let word of contents) {
            if (data === word) {
                // console.log("includes", "FOUND IN CONTENTS", contents);
                return options.fn(this);
            }
        }
        // console.log("includes", "NOT FOUND IN CONTENTS", contents);
        return options.inverse(this);
    });

    Handlebars.registerHelper('math', function (lvalue, operator, rvalue) {
        lvalue = parseFloat(lvalue);
        rvalue = parseFloat(rvalue);

        switch (operator) {
            case '+':
                return lvalue + rvalue;
            case '-':
                return lvalue - rvalue;
            case '*':
                return lvalue * rvalue;
            case '/':
                return lvalue / rvalue;
            default:
                return null;
        }
    });

    Handlebars.registerHelper('sum', function () {
        return Array.prototype.slice.call(arguments, 0, -1).reduce((acc, num) => (acc += num));
    });

    Handlebars.registerHelper('ifGreater', function (v1, v2, options) {
        if (v1 > v2) {
            return options.fn(this);
        }
        return options.inverse(this);
    });

    Handlebars.registerHelper('ifLess', function (v1, v2, options) {
        if (v1 < v2) {
            return options.fn(this);
        }
        return options.inverse(this);
    });

    /**
     * A very basic <extendable> helper for rendering a color coded gauge/meter and/or progress bar
     */
    Handlebars.registerHelper('progressBar', function (num1, num2) {
        if (isNaN(num1)) {
            num1 = 0;
        }
        if (isNaN(num2)) {
            num2 = 0;
        }

        let percentage = Math.floor((num1 / num2) * 100);

        // Ensure percentage doesn't exceed 100%
        if (percentage > 100) {
            percentage = 100;
        }

        // Safety net if percentage is NaN
        if (isNaN(percentage)) return '';

        // Extend here for more granular colors
        let backgroundColor = '';
        if (percentage >= 75) {
            backgroundColor = '#7e9f86'; // green
        } else if (percentage >= 50) {
            backgroundColor = '#daa520'; // yellow
        } else if (percentage >= 25) {
            backgroundColor = '#d17b26'; // orange
        } else {
            backgroundColor = '#864c4c'; // red
        }

        const progressBarStyle = `width: ${percentage}%; background-color: ${backgroundColor}`;
        return progressBarStyle;
    });

    Handlebars.registerHelper('percentage', function (value, total) {
        if (isNaN(value)) {
            value = 0;
        }
        if (isNaN(total)) {
            total = 0;
        }

        if (total > 0) {
            let percentage = Math.floor((value / total) * 100);

            // Ensure percentage doesn't exceed 100%
            if (percentage > 100) {
                percentage = 100;
            }

            return percentage;
        } else {
            return 0;
        }
    });

    Handlebars.registerHelper('displayDuration', function (effect) {
        if (effect.duration && effect.duration.type === 'seconds') {
            return (effect.duration.seconds / 60).toFixed(0) + ' Rounds';
        } else {
            return effect.duration.label || '';
        }
    });

    Handlebars.registerHelper('displayMvBreakdown', function (value) {
        const v2 = game.settings.get('ars', 'systemVariant') === '2';
        const mv = Number(value);
        if (!v2) return mv;

        if (typeof mv === 'number') {
            return `(${mv * 10}ft / ${mv * 3 * 10}yrds)`;
        }
    });

    Handlebars.registerHelper('localizekey', function (data, content, options) {
        // console.log("localizekey", { data, content, options });
        const result = data[content] || '';
        return game.i18n.localize(result);
    });

    Handlebars.registerHelper('for', function (from, to, incr, block) {
        var accum = '';
        for (var i = from; i < to; i += incr) {
            block.data.forindex = i;
            accum += block.fn(i);
        }
        return accum;
    });

    // Handlebars.registerHelper('length', function (aList) {
    //     return (aList.length || 0);
    // });

    /**
     * Does the object contains ALL of these list of objects
     *
     */
    Handlebars.registerHelper('contains', function (data, content, options) {
        let bFound = false;
        let contents = undefined;

        if (content.match('(&&)')) {
            contents = content.split('&&');
        } else {
            contents = [content];
        }
        for (let word of contents) {
            if (data === word) {
                bFound = true;
            } else {
                // missing a word, end and false
                bFound = false;
                break;
            }
        }

        if (bFound) {
            // console.log("includes", "FOUND ALL CONTENTS", contents);
            return options.fn(this);
        } else {
            // console.log("includes", "NOT FOUND IN CONTENTS", contents);
            return options.inverse(this);
        }
    });

    /**
     * Capitalize the first letter handlebars helper
     */
    Handlebars.registerHelper('capfirst', function (str) {
        if (typeof str !== 'string') return '';
        return str.charAt(0).toUpperCase() + str.slice(1);
    });

    Handlebars.registerHelper('allcaps', function (str) {
        if (typeof str !== 'string') return str;
        return str.toUpperCase();
    });

    /** used to cleanup vars used in class="" entries */
    Handlebars.registerHelper('removedots', function (str) {
        if (typeof str !== 'string') return str;

        try {
            const result = str.replace(/\./g, '_');
            return result;
        } catch (err) {
            return `handlebars.js removedots error: ${err}`;
        }
    });
    /**
     * Concat handlebars helper
     *
     * {{#each system.abilities as |ability key|}}
     * <label>{{localize (concat "systemName.abilities." key)}}</label>
     * {{/each}}
     *
     */
    Handlebars.registerHelper('concat', function () {
        var arg = Array.prototype.slice.call(arguments, 0);
        arg.pop();
        return arg.join('');
    });

    // if equals (ignore case if string)
    Handlebars.registerHelper('ifeq', function (a, b, options) {
        if (typeof a === 'string' && typeof b === 'string') {
            if (a.toLowerCase() == b.toLowerCase()) {
                return options.fn(this);
            }
        } else if (a == b) {
            return options.fn(this);
        }
        return options.inverse(this);
    });

    // if not equals (ignore case if string)
    Handlebars.registerHelper('ifnoteq', function (a, b, options) {
        if (typeof a === 'string' && typeof b === 'string') {
            if (a.toLowerCase() != b.toLowerCase()) {
                return options.fn(this);
            }
        } else if (a != b) {
            return options.fn(this);
        }
        return options.inverse(this);
    });

    // if not equal (support multiple values)
    Handlebars.registerHelper('ifnoteqMulti', function (a, b, c, options) {
        if (
            typeof a === 'string' &&
            a.toLowerCase() != b.toLowerCase() &&
            typeof a === 'string' &&
            a.toLowerCase() != c.toLowerCase()
        ) {
            return options.fn(this);
        }
        return options.inverse(this);
    });

    /** (getproperty item.system. 'protection.ac') */
    Handlebars.registerHelper('getproperty', function (data, varpath) {
        if (data && varpath) {
            try {
                const value = foundry.utils.getProperty(data, varpath);
                return value;
            } catch (err) {
                return `handlebars.js getproperty error: ${err}`;
            }
        }
        return `handlebars.js getproperty error: data or varpath missing`;
    });

    //example: #if (and @root.actor.needsInitiative @root.game.ars.config.settings.initiativeUseSpeed)}}
    Handlebars.registerHelper('and', function (a, b) {
        return a && b;
    });

    //view state helper for collapse states
    Handlebars.registerHelper('getViewState', function (id, tag) {
        // Construct the dynamic path
        return game.user.flags?.ars?.viewState?.[id]?.collapsed?.[tag];
    });

    //{{#times 20}} invokes the times helper to iterate 20 times.
    Handlebars.registerHelper('times', function (n, block) {
        var accum = '';
        for (var i = 0; i < n; ++i) {
            // You can also pass `i` to the block, allowing you to use the index inside your loop
            accum += block.fn(i);
        }
        return accum;
    });

    /**
     *
     * Helper to deal with spell memorization lists
     *
     * actor.spellsByLevel,
     * spellType 'arcane', 'divine'
     * level 1,2,3/etc
     */
    Handlebars.registerHelper('selectSpellOptions', function (spells, spellType, level) {
        //do this so if the system is still loading the character sheet will still open tho empty slots will be blank
        const spellsByLevel = spells?.[spellType]?.[level];
        if (!spellsByLevel || foundry.utils.isEmpty(spellsByLevel)) {
            return new Handlebars.SafeString('<option value="">No spells Available</option>');
        }
        const systemHasSpells = game.items.some((item) => item.type === 'spell' && item.system.type.toLowerCase() == spellType);
        if (!systemHasSpells && foundry.utils.isEmpty(game.ars.library.packs.items)) {
            const emptyDbOption = new Handlebars.SafeString(
                '<option value="">System Spell Data Not Loaded, Close/Re-open sheet once it is.</option>'
            );
            console.error('selectSpellOptions, Spell data not loaded yet? Close and reopen sheet once it is.');
            return emptyDbOption;
        }

        let html = '';

        // Add empty option
        const spellTypeLocal = game.i18n.localize(`ARS.spellTypes.${spellType}`);
        html += `<option value="">${game.i18n.localize('ARS.empty')} ${game.i18n.localize(
            'ARS.level'
        )} ${level} ${spellTypeLocal} Slot</option>`;

        // Conditional groups (learned/not learned, owned/not owned)
        const groups = {
            learned: [],
            notlearned: [],
            owned: [],
            available: [],
        };

        // Assuming spellsByLevel is an object where each key is a spell ID and each value is the spell details
        Object.entries(spellsByLevel).forEach(([id, entry]) => {
            // divine spells dont need to be "learned"
            if (spellType === 'arcane') {
                if (entry.isLearned) {
                    groups.learned.push({ id, info: entry.spellInfo, owned: entry.isOwned });
                } else {
                    groups.notlearned.push({ id, info: entry.spellInfo, owned: entry.isOwned });
                }
            }
            if (entry.isOwned) {
                groups.owned.push({ id, info: entry.spellInfo });
            } else {
                groups.available.push({ id, info: entry.spellInfo });
            }
        });

        // Build options from grouped data
        Object.entries(groups).forEach(([key, entries]) => {
            if (entries.length > 0) {
                const keyLocal = game.i18n.localize(`ARS.${key}`);
                html += `<optgroup label="${keyLocal}">`;
                entries.forEach((entry) => {
                    html += `<option value="${entry.id}">${entry.info}`;
                    // if (entry.owned) {
                    //     html += ` (${game.i18n.localize('ARS.owned')})`;
                    // }
                    html += '</option>';
                });
                html += '</optgroup>';
            }
        });

        // console.log('HTML=', { html });
        // Use Handlebars.SafeString to prevent HTML escaping
        return new Handlebars.SafeString(html);
    });

    // Register a Handlebars helper named 'showPips'
    Handlebars.registerHelper('showPips', function (number) {
        let html = '';
        for (let i = 0; i < number; i++) {
            html += '<span class="pip">•</span>';
        }
        return new Handlebars.SafeString(html);
    });

    // Register the Handlebars helper
    Handlebars.registerHelper('mapToArray', function (map) {
        return Array.from(map.values());
    });

    /**
     * returns true is boolean is false
     */
    Handlebars.registerHelper('isfalse', function (a) {
        if (!a) return true;
        else return false;
    });
} // end default function

import * as debug from '../debug.js';

/**
 * Class for token-hud
 *
 */

export class ARSCombatHUD extends Application {
    constructor(token, options = {}) {
        super(options);
        this.token = token;
        this.actor = token.actor;
        token.actor.apps[this.appId] = this;

        console.log('token-hud-class.js CREATED');
    } // end constructor

    /** @override */
    // static documentName = 'ARSCombatHUD';

    /** @override */
    static get defaultOptions() {
        return foundry.utils.mergeObject(super.defaultOptions, {
            id: 'ars-combathud',
            classes: ['ars'],
            template: 'systems/ars/templates/apps/combat-hud-mini.hbs',
            title: 'CombatHUD',
            height: 'auto',
            width: 'auto',
            resizable: true,
        });
    } // end defaultOptions

    getData() {
        const context = {
            token: this.token,
            actor: this.actor,
            system: this.actor.system,
            actions: this.actor.system.actions,
            actionList: this.actor.system.actionList,
            actionCount: Object.keys(this.actor.system.actionList).length,
        };

        return context;
    } // end getData

    activateListeners(html) {
        super.activateListeners(html);

        //listeners for button clicks
        // weapon/skills
        const chatCardRoll = html[0].querySelectorAll('.chatCard-roll');
        chatCardRoll.forEach((chatCard) => {
            chatCard.addEventListener('click', (event) => {
                this.actor.sheet._itemChatRoll.bind(this.actor.sheet)(event);
            });
            // chatCard.addEventListener("contextmenu", function (event) { actor.sheet.combatItemContext });
        });

        // memslots
        const spellCardRoll = html[0].querySelectorAll('.spellCard-roll');
        spellCardRoll.forEach((spellCard) => {
            spellCard.addEventListener('click', (event) => {
                this.actor.sheet._itemChatRoll.bind(this.actor.sheet)(event);
            });
        });

        // actions
        const actionCardRoll = html[0].querySelectorAll('.actionCard-roll');
        actionCardRoll.forEach((actionCard) => {
            actionCard.addEventListener('click', (event) => {
                this.actor.sheet._actionChatRoll.bind(this.actor.sheet)(event);
            });
        });
    } // end activateListeners

    createHud() {
        const token = this.token;
        const actor = this.actor;
        // console.log('token-hud-class.js createHud()', { token, actor });
        if (!actor || (!actor.isOwner && !game.user.isGM)) return;
        this.render(true);
        return this;
    } // end createHud

    closeHud() {
        delete this.token.actor.apps[this.appId];
        // this.close();
    }
}

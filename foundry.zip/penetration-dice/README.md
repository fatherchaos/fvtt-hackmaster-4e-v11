# fvtt-penetration-dice
Support for Hackmaster-style penetration dice within Foundry VTT.

Stole most of the code needed for this from the Hackmaster 5e package for Foundry: https://foundryvtt.com/packages/hackmaster5e
